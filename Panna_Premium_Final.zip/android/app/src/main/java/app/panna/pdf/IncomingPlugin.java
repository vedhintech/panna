package app.panna.pdf;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

@CapacitorPlugin(name = "Incoming")
public class IncomingPlugin extends Plugin {
    private JSObject pending;

    @Override
    public void load() { handle(getActivity().getIntent()); }

    @Override
    protected void handleOnNewIntent(Intent intent) { super.handleOnNewIntent(intent); handle(intent); }

    private void handle(Intent intent) {
        if (intent == null) return;
        Uri uri = null;
        String action = intent.getAction();
        if (Intent.ACTION_VIEW.equals(action)) uri = intent.getData();
        else if (Intent.ACTION_SEND.equals(action)) uri = intent.getParcelableExtra(Intent.EXTRA_STREAM);
        if (uri == null) return;
        intent.setAction(null);
        try {
            String name = "document.pdf";
            try (Cursor c = getContext().getContentResolver().query(uri, null, null, null, null)) {
                if (c != null && c.moveToFirst()) {
                    int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    if (i >= 0 && c.getString(i) != null) name = c.getString(i);
                }
            } catch (Exception ignored) {}
            if (!name.toLowerCase().endsWith(".pdf")) name = name + ".pdf";
            File dir = new File(getContext().getCacheDir(), "incoming");
            dir.mkdirs();
            File[] old = dir.listFiles();
            if (old != null) for (File f : old) f.delete();
            File out = new File(dir, System.currentTimeMillis() + ".pdf");
            try (InputStream in = getContext().getContentResolver().openInputStream(uri);
                 FileOutputStream fo = new FileOutputStream(out)) {
                byte[] buf = new byte[65536]; int n;
                while ((n = in.read(buf)) > 0) fo.write(buf, 0, n);
            }
            JSObject r = new JSObject();
            r.put("path", out.getAbsolutePath());
            r.put("name", name);
            pending = r;
            notifyListeners("file", r, true);
        } catch (Exception e) {
            JSObject r = new JSObject(); r.put("error", e.getMessage());
            notifyListeners("file", r, true);
        }
    }

    @PluginMethod
    public void take(PluginCall call) {
        JSObject r = pending != null ? pending : new JSObject();
        pending = null;
        call.resolve(r);
    }
}
