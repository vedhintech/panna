import { readdir, readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { spawnSync } from 'node:child_process';

async function walk(dir) {
  const out = [];
  for (const ent of await readdir(dir, { withFileTypes: true })) {
    const p = join(dir, ent.name);
    if (ent.isDirectory()) out.push(...await walk(p));
    else if (p.endsWith('.js')) out.push(p);
  }
  return out;
}
const files = await walk('src');
let failed = false;
for (const file of files) {
  const r = spawnSync(process.execPath, ['--check', file], { encoding: 'utf8' });
  if (r.status !== 0) { failed = true; process.stderr.write(`${file}\n${r.stderr}`); }
}
if (failed) process.exit(1);
console.log(`Syntax check passed for ${files.length} JavaScript source files.`);
