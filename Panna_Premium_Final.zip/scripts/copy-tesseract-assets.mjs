import { access, copyFile, mkdir } from 'node:fs/promises';
import { join } from 'node:path';

// Tesseract.js 5 ships its WebAssembly modules as JavaScript loader files;
// the WASM binary is embedded in each loader, so there are no standalone .wasm files.
const source = join('node_modules', 'tesseract.js-core');
const target = join('public', 'tess');
const assets = [
  'tesseract-core.wasm.js',
  'tesseract-core-simd.wasm.js',
  'tesseract-core-lstm.wasm.js',
  'tesseract-core-simd-lstm.wasm.js',
];

await mkdir(target, { recursive: true });
let copied = 0;
let packageAvailable = true;
try { await access(join(source, assets[0])); } catch { packageAvailable = false; }

if (packageAvailable) {
  for (const asset of assets) {
    const from = join(source, asset);
    try {
      await access(from);
      await copyFile(from, join(target, asset));
      copied++;
    } catch {
      throw new Error(`Missing Tesseract core loader: ${from}. Check the locked tesseract.js-core package.`);
    }
  }
} else {
  // A source archive can still be inspected/tested without installed npm deps.
  // Require the two bundled LSTM variants already shipped with this project.
  for (const asset of ['tesseract-core-lstm.wasm.js', 'tesseract-core-simd-lstm.wasm.js']) {
    try { await access(join(target, asset)); }
    catch { throw new Error(`Missing bundled Tesseract core loader: ${join(target, asset)}. Run npm ci before building.`); }
  }
  console.warn('Tesseract npm package is not installed; retaining bundled local LSTM core loaders.');
}
console.log(`Prepared ${copied || 2} local Tesseract core loader(s) in ${target}.`);
