# Panna Premium 1.2.4 — QA and build status

## Source changes in this delivery
- Serialized shared Tesseract worker use so concurrent OCR requests cannot overwrite worker parameters.
- Released PDF.js page resources and OCR canvases on completion and error paths.
- Made editor page rendering cancelable during close and disconnected its observer.
- Hardened scanner cleanup and image decode error handling.
- Added local Tesseract core-loader preparation for CI builds; corrected the asset model to the JavaScript WebAssembly loader files used by Tesseract.js 5.
- Hardened Aadhaar OCR box detection for malformed OCR data, Devanagari digits, line separation, unrelated groups, and precise first-eight-digit mask width.
- Updated Android/app/package version to 1.2.4 (versionCode 6).

## Checks that passed in this environment
- `npm test`: 14/14 tests passed.
- `npm run check`: syntax check passed for 19 JavaScript source files.
- `node scripts/copy-tesseract-assets.mjs`: passed in source-only fallback mode using the bundled LSTM loaders.

## Checks not completed
- `npm run build`: blocked because the Vite executable is not installed. npm registry access failed with DNS `EAI_AGAIN`, so dependencies could not be installed.
- Android Gradle build: not run; Android SDK is absent (`ANDROID_HOME` is unset and no SDK installation was found).
- No APK/AAB was produced or device-tested. The GitHub connection exposed no accessible repositories, and the connector does not provide repository creation or workflow-dispatch actions in this session.
- Full interactive feature QA on a physical Android device remains outstanding.

## Known product limitation
- PDF OCR text replacement is still a visual cover-and-replace overlay, not semantic editing of arbitrary embedded PDF text objects. Complex fonts, layouts, rotations, and scanned backgrounds require additional work and real-device validation.

This report intentionally distinguishes passing source-level tests from uncompleted production/build/device verification. Do not treat this ZIP as a verified installable APK or Play Store release.
