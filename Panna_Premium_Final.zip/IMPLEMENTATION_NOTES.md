# Panna Premium 1.2.0 – second implementation pass

## Changes in this pass
- Added free-angle rotation for placed image objects, including drawn signatures and stamps. The selected image object exposes a rotate handle; pointer movement rotates around its center.
- Persisted image rotation into the exported PDF overlay using canvas transforms, so the saved PDF matches the editor preview.
- Updated editor guidance to explain move, resize, and rotate gestures.
- Hardened Photo-to-Text canvas cleanup: source and crop canvases are released even when the user cancels a crop or OCR throws.
- Bumped app version to 1.2.0 / Android versionCode 4.
- Added a repeatable JavaScript source syntax check script.

## Validation performed
- `node --check` passed for all source JavaScript modules.
- `node scripts/check-source.mjs` passed.
- Full Vite build, Android Gradle build, and on-device interaction tests have not been run in this environment because dependencies are not installed and package downloads are unavailable.

## Known limitations
- OCR replacement remains a visual cover-and-replace overlay; it is not semantic editing of embedded PDF text objects.
- PDF text editing for arbitrary original fonts, complex layouts, scanned backgrounds, and rotated/cropped pages needs further implementation and device QA.
- Rotation controls and output need real-device testing across screen sizes and touch input.
- Offline AI model integration has not been implemented in this release.
- Do not publish to Google Play until a release build, signing, privacy disclosures, permission audit, and full functional QA are complete.


## v1.2.1 phone-only build support
- Added `npm run build` (Vite production build).
- Added GitHub Actions workflow `.github/workflows/android-debug-apk.yml` to build and publish a downloadable debug APK artifact.
- Added `PHONE_BUILD_GUIDE_HI.md` with Android-only Termux + GitHub instructions.
- Cloud build and real-device installation have not yet been executed; this workflow is a build path, not proof of a successful APK.


## v1.2.2 consistency and QA pass
- Synchronized package, Android version name, Android version code, and GitHub Actions artifact label.
- Replaced the stale About-screen version 1.0/offline privacy claim with the current app version and a neutral feature description.
- Added automated project-configuration tests for version alignment, Android SDK levels, backup policy, and the phone-only APK workflow.
- Source syntax checks and configuration tests are repeatable locally; full dependency install, web build, Gradle build, and device QA remain pending.


## v1.2.3 OCR, editor lifecycle, and CI hardening
- Serialized calls through the shared Tesseract worker so DPI/recognition settings cannot race between concurrent OCR screens.
- Added an explicit `tesseract.js-core` dependency and a prebuild step that copies all four JS/WASM core variants into `public/tess`, keeping OCR self-hosted/offline in the app package.
- Released OCR PDF page canvases and PDF.js page resources in `finally` blocks, including error/cancel paths.
- Made editor page rendering cancelable on close and disconnected its IntersectionObserver to avoid background rendering against a destroyed PDF.
- Cleaned up scanner source canvases, split-book intermediates, page canvases, and Sortable handlers when scanner pages close; added a visible error path if a selected image cannot be decoded.
- PDF text indexing now releases each PDF.js page after extracting its searchable text.
- Extracted Aadhaar OCR box detection into a dependency-free module and added tests for continuous/grouped digits, Devanagari digits, line boundaries, and incomplete matches.
- Fixed a malformed Photo-to-Text string join found during a fresh whole-source syntax pass.
- Hardened GitHub Actions with pull-request builds, Gradle caching, automated tests, and an explicit non-empty APK artifact check.
- Bumped app version to 1.2.3 / Android versionCode 6.

## Validation for v1.2.3
- `node scripts/check-source.mjs`: passed for all 19 JavaScript source files.
- `npm test`: passed, 11 tests.
- `npm ci --no-audit --no-fund --prefer-offline`: timed out in this environment.
- `npm run build`: not run successfully because Vite is unavailable after dependency installation timed out.
- Android SDK is not installed (`ANDROID_HOME` is unset); no APK or device test has been produced here.


## v1.2.4 OCR build and Aadhaar detection hardening
- Corrected the Tesseract.js 5 asset-copy step: core variants are JavaScript WebAssembly loaders (`*.wasm.js`), not separate `.wasm` files. A clean CI install copies all four supported variants; a source-only checkout can retain the bundled LSTM variants while dependencies are unavailable.
- Hardened Aadhaar OCR box detection against null/malformed word records and unrelated digit groups separated by large gaps. Continuous 12-digit masks now use an exact 8/12 width ratio.
- Added regression tests for malformed OCR records, distant digit groups, and exact continuous-number masking.
- Bumped package/About/Android version to 1.2.4; Android versionCode is 6.

## Validation for v1.2.4
- `npm test`: 14 tests passed.
- `npm run check`: passed for 19 JavaScript source files.
- Tesseract asset preparation passes in source-only mode using the two bundled LSTM core loaders.
- Full Vite/Android build remains blocked in this environment because npm registry DNS is unavailable and Android SDK is absent.
