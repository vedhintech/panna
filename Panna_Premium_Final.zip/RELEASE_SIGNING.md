# Panna release signing

Never commit a release keystore or its passwords to source control or share them in a ZIP.
Create and back up a new private release keystore. Store the following values only in your
local `~/.gradle/gradle.properties` or a protected CI secret store:

```properties
PANNA_RELEASE_STORE_FILE=/absolute/path/to/panna-release.jks
PANNA_RELEASE_STORE_PASSWORD=YOUR_PRIVATE_STORE_PASSWORD
PANNA_RELEASE_KEY_ALIAS=YOUR_PRIVATE_ALIAS
PANNA_RELEASE_KEY_PASSWORD=YOUR_PRIVATE_KEY_PASSWORD
```

The project uses the standard Android debug key for debug builds. Release builds are signed
only when all four private values are supplied. Keep the same release key permanently for
updates to the same Play Store application. For Google Play, use Play App Signing and securely
retain the upload key.
