import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const pkg = JSON.parse(await readFile(new URL('../package.json', import.meta.url), 'utf8'));
const lock = JSON.parse(await readFile(new URL('../package-lock.json', import.meta.url), 'utf8'));
const gradle = await readFile(new URL('../android/app/build.gradle', import.meta.url), 'utf8');
const vars = await readFile(new URL('../android/variables.gradle', import.meta.url), 'utf8');
const manifest = await readFile(new URL('../android/app/src/main/AndroidManifest.xml', import.meta.url), 'utf8');
const workflow = await readFile(new URL('../.github/workflows/android-debug-apk.yml', import.meta.url), 'utf8');

test('package and Android app versions stay aligned', () => {
  assert.ok(gradle.includes(`versionName "${pkg.version}"`));
  assert.equal(lock.version, pkg.version);
  assert.equal(lock.packages[''].version, pkg.version);
  const code = Number(gradle.match(/versionCode\s+(\d+)/)?.[1]);
  assert.ok(Number.isInteger(code) && code >= 1, 'Android versionCode must be a positive integer');
});

test('Android SDK levels are explicitly configured', () => {
  assert.match(vars, /minSdkVersion\s*=\s*29/);
  assert.match(vars, /compileSdkVersion\s*=\s*36/);
  assert.match(vars, /targetSdkVersion\s*=\s*36/);
});

test('Android cloud build disables OS auto-backup and produces a debug APK artifact', () => {
  assert.match(manifest, /android:allowBackup="false"/);
  assert.match(workflow, /npm ci/);
  assert.match(workflow, /npx cap sync android/);
  assert.match(workflow, /gradlew assembleDebug/);
  assert.match(workflow, /app-debug\.apk/);
  assert.match(workflow, /Panna-\$\{\{ github\.sha \}\}-debug-apk/);
  assert.match(workflow, /pull_request:/);
  assert.match(workflow, /cache: gradle/);
  assert.match(workflow, /npm test/);
  assert.match(workflow, /test -s android\/app\/build\/outputs\/apk\/debug\/app-debug\.apk/);
});

test('offline OCR build copies every required local WASM core variant', async () => {
  const scripts = await readFile(new URL('../scripts/copy-tesseract-assets.mjs', import.meta.url), 'utf8');
  assert.equal(pkg.dependencies['tesseract.js-core'], '^5.1.1');
  assert.equal(lock.packages[''].dependencies['tesseract.js-core'], pkg.dependencies['tesseract.js-core']);
  assert.equal(lock.packages['node_modules/tesseract.js-core'].version, '5.1.1');
  assert.equal(pkg.scripts.prebuild, 'node scripts/copy-tesseract-assets.mjs');
  for (const name of ['tesseract-core.wasm.js', 'tesseract-core-simd.wasm.js', 'tesseract-core-lstm.wasm.js', 'tesseract-core-simd-lstm.wasm.js']) assert.ok(scripts.includes(name), `missing ${name}`);
});

test('offline OCR runtime has its local worker and Hindi/English traineddata', async () => {
  const { access } = await import('node:fs/promises');
  const runtime = await readFile(new URL('../src/ocr.js', import.meta.url), 'utf8');
  assert.match(runtime, /\.\/tess\/worker\.min\.js/);
  assert.match(runtime, /\.\/tess\/lang/);
  for (const file of ['public/tess/worker.min.js', 'public/tess/tesseract-core-lstm.wasm.js', 'public/tess/tesseract-core-simd-lstm.wasm.js', 'public/tess/lang/hin.traineddata.gz', 'public/tess/lang/eng.traineddata.gz']) {
    await access(new URL(`../${file}`, import.meta.url));
  }
});
