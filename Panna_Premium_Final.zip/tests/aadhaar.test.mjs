import test from 'node:test';
import assert from 'node:assert/strict';
import { aadhaarBoxes } from '../src/aadhaar.js';

const word = (text, x0, y0 = 10, x1 = x0 + 30, y1 = y0 + 12) => ({ text, bbox: { x0, y0, x1, y1 } });

test('detects a continuous 12-digit Aadhaar and masks its first eight digits', () => {
  const [box] = aadhaarBoxes([word('123456789012', 10, 10, 130, 22)]);
  assert.equal(box.x0, 10); assert.equal(box.y0, 10); assert.ok(Math.abs(box.x1 - 90) < 1e-9); assert.equal(box.y1, 22);
});

test('detects grouped 4-4-4 Aadhaar digits on the same line', () => {
  const [box] = aadhaarBoxes([word('1234', 10), word('5678', 50), word('9012', 90)]);
  assert.deepEqual(box, { x0: 10, y0: 10, x1: 80, y1: 22 });
});

test('normalizes Devanagari digits before detecting a continuous number', () => {
  assert.equal(aadhaarBoxes([word('१२३४५६७८९०१२', 5)]).length, 1);
});

test('does not combine digit groups from different lines', () => {
  assert.equal(aadhaarBoxes([word('1234', 10), word('5678', 50, 40), word('9012', 90, 40)]).length, 0);
});

test('ignores incomplete and non-numeric OCR words', () => {
  assert.deepEqual(aadhaarBoxes([word('name', 0), word('123', 30), word('12345678901', 60)]), []);
});

test('does not combine the third digit group from a different line', () => {
  assert.equal(aadhaarBoxes([word('1234', 10), word('5678', 50), word('9012', 90, 40)]).length, 0);
});

test('returns no boxes for missing or malformed OCR words', () => {
  assert.deepEqual(aadhaarBoxes(null), []);
  assert.deepEqual(aadhaarBoxes([null, { text: '1234' }, word('1234', 0)]), []);
});

test('does not combine unrelated digit groups separated by a large gap', () => {
  assert.equal(aadhaarBoxes([word('1234', 0), word('5678', 100), word('9012', 200)]).length, 0);
});

test('masks exactly eight of twelve digits in a continuous OCR word', () => {
  const [box] = aadhaarBoxes([word('123456789012', 0, 10, 120, 22)]);
  assert.equal(box.x1, 80);
});
