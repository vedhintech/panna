# Panna APK — केवल Android फोन से बनाएं (Hindi)

इस प्रोजेक्ट में APK पहले से शामिल नहीं है। यह GitHub Actions के जरिए क्लाउड पर Debug APK बनाने के लिए तैयार है।

## जरूरी चीजें
- GitHub account
- Android पर Termux (F-Droid या Termux की आधिकारिक GitHub Releases से)
- इंटरनेट और लगभग 10 GB खाली जगह की सलाह (Termux, project और build cache के लिए)

## 1. ZIP को फोन में Extract करें
Panna ZIP को Download करें और फोन के File Manager से Extract करें। Extract किए गए `panna` फोल्डर का वास्तविक path नोट करें।

## 2. Termux में Git तैयार करें
Termux खोलें और चलाएं:

```sh
pkg update -y && pkg upgrade -y
pkg install git openssh -y
termux-setup-storage
```

यदि प्रोजेक्ट Download फोल्डर में है, तो आम तौर पर path `/storage/emulated/0/Download/panna` होगा। अपने वास्तविक path के अनुसार नीचे `cd` बदलें।

## 3. GitHub पर खाली repository बनाएं
ब्राउज़र में https://github.com खोलें, sign in करें और `panna-android` नाम से एक **Private** repository बनाएं। README, .gitignore या license initialize न करें।

## 4. प्रोजेक्ट GitHub पर भेजें
Termux में `cd` के बाद ये commands चलाएं (path और GitHub username बदलें):

```sh
cd /storage/emulated/0/Download/panna
git init
git add .
git commit -m "Panna 1.2.4 Android build"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/panna-android.git
git push -u origin main
```

GitHub login मांगे तो password की जगह GitHub Personal Access Token (PAT) इस्तेमाल करें। Token किसी के साथ साझा न करें और chat में न भेजें।

## 5. APK डाउनलोड करें
GitHub repository खोलें → **Actions** → `Build Panna Android APK` → सफल workflow run खोलें → नीचे **Artifacts** में `Panna-<commit-sha>-debug-apk` डाउनलोड करें। ZIP को Extract करें; उसमें `app-debug.apk` मिलेगी।

## 6. फोन में इंस्टॉल करें
`app-debug.apk` पर टैप करें। Android यदि अनुमति मांगे तो केवल उस File Manager/Browser के लिए **Install unknown apps** अनुमति दें जिससे APK खोली है। इंस्टॉल के बाद Panna खोलें।

## ध्यान दें
- यह **debug/test APK** है, Play Store release नहीं।
- Build तभी सफल होगा जब GitHub Actions पूरा हो जाए; build fail हो तो Actions के error logs साझा करें (कभी भी token/password नहीं)।
- GitHub repo Private रखें क्योंकि इसमें आपका app source code है।
- यह workflow cloud build चलाता है; फोन पर Android SDK/Gradle install करने की जरूरत नहीं।
