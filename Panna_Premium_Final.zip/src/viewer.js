import { pdfjs } from './pdf.js';

const GAP = 12, MAX_PX = 4_200_000, KEEP = 10;

export class Viewer {
  constructor(scroller, doc, { startPage = 1, onPage = () => {} } = {}) {
    this.sc = scroller; this.doc = doc; this.onPage = onPage;
    this.n = doc.numPages; this.z = 1; this.cur = 0;
    this.sizes = []; this.pages = []; this.rendered = new Map(); this.hits = new Map();
    this.inner = document.createElement('div'); this.inner.className = 'pages';
    this.sc.replaceChildren(this.inner);
    this.ready = this.init(startPage);
  }

  async init(startPage) {
    const p1 = await this.doc.getPage(1);
    const v = p1.getViewport({ scale: 1 });
    for (let i = 0; i < this.n; i++) this.sizes[i] = { w: v.width, h: v.height };
    for (let i = 0; i < this.n; i++) {
      const d = document.createElement('div'); d.className = 'page'; d.dataset.i = i;
      const ph = document.createElement('span'); ph.className = 'pnum'; ph.textContent = i + 1;
      d.append(ph); this.inner.append(d); this.pages.push(d);
    }
    this.layout();
    this.io = new IntersectionObserver(es => es.forEach(e => {
      const i = +e.target.dataset.i;
      if (e.isIntersecting) this.render(i);
    }), { root: this.sc, rootMargin: '120% 0px' });
    this.pages.forEach(p => this.io.observe(p));
    this.sc.addEventListener('scroll', () => this.track(), { passive: true });
    this.gestures();
    this.ro = new ResizeObserver(() => this.relayout()); this.ro.observe(this.sc);
    if (startPage > 1) this.goto(startPage, false);
    this.track();
    // fetch true page sizes in background (mixed-size PDFs)
    (async () => {
      for (let i = 1; i < this.n && !this.dead; i++) {
        const pg = await this.doc.getPage(i + 1); const vv = pg.getViewport({ scale: 1 });
        if (Math.abs(vv.width - this.sizes[i].w) > 1 || Math.abs(vv.height - this.sizes[i].h) > 1) {
          this.sizes[i] = { w: vv.width, h: vv.height }; this.relayout();
        }
      }
    })();
  }

  get base() { const maxW = Math.max(...this.sizes.map(s => s.w)); return (this.sc.clientWidth - 24) / maxW; }

  layout() {
    const b = this.base * this.z;
    this.pages.forEach((p, i) => {
      p.style.width = Math.floor(this.sizes[i].w * b) + 'px';
      p.style.height = Math.floor(this.sizes[i].h * b) + 'px';
    });
    this.inner.style.gap = GAP + 'px';
  }

  relayout() {
    const page = this.cur, off = this.offsetIn(page);
    this.layout(); this.rerender();
    this.sc.scrollTop = this.pages[page].offsetTop - GAP + off * this.pages[page].offsetHeight;
  }

  offsetIn(i) { const p = this.pages[i]; return p ? (this.sc.scrollTop - p.offsetTop + GAP) / p.offsetHeight : 0; }

  rerender() {
    const vis = [...this.rendered.keys()];
    this.rendered.forEach(r => r.task?.cancel()); this.rendered.clear();
    vis.forEach(i => this.render(i));
  }

  async render(i) {
    if (this.rendered.has(i) || this.dead) return;
    const rec = { z: this.z }; this.rendered.set(i, rec);
    this.evict(i);
    try {
      const page = await this.doc.getPage(i + 1);
      const css = this.base * this.z;
      let res = css * Math.min(window.devicePixelRatio || 1, 2.5);
      const v0 = page.getViewport({ scale: 1 });
      if (v0.width * v0.height * res * res > MAX_PX) res = Math.sqrt(MAX_PX / (v0.width * v0.height));
      const vp = page.getViewport({ scale: res });
      const c = document.createElement('canvas');
      c.width = Math.floor(vp.width); c.height = Math.floor(vp.height);
      rec.task = page.render({ canvasContext: c.getContext('2d', { alpha: false }), viewport: vp });
      await rec.task.promise;
      if (this.rendered.get(i) !== rec) { c.width = c.height = 0; return; }
      const host = this.pages[i];
      host.querySelector('canvas')?.remove();
      host.prepend(c); host.classList.add('done');
      this.drawHits(i);
    } catch (e) {
      if (e?.name !== 'RenderingCancelledException') console.warn(e);
      if (this.rendered.get(i) === rec) this.rendered.delete(i);
    }
  }

  evict(center) {
    if (this.rendered.size <= KEEP) return;
    [...this.rendered.keys()].sort((a, b) => Math.abs(b - center) - Math.abs(a - center))
      .slice(0, this.rendered.size - KEEP).forEach(i => {
        this.rendered.get(i).task?.cancel(); this.rendered.delete(i);
        const c = this.pages[i].querySelector('canvas'); if (c) { c.width = c.height = 0; c.remove(); }
        this.pages[i].classList.remove('done');
      });
  }

  track() {
    const y = this.sc.scrollTop + this.sc.clientHeight * 0.35;
    let lo = 0, hi = this.n - 1;
    while (lo < hi) { const m = (lo + hi + 1) >> 1; if (this.pages[m].offsetTop <= y) lo = m; else hi = m - 1; }
    if (lo !== this.cur || !this._t) { this.cur = lo; this._t = 1; this.onPage(lo + 1, this.n); }
  }

  goto(n, smooth = true) {
    const p = this.pages[Math.max(0, Math.min(this.n - 1, n - 1))];
    this.sc.scrollTo({ top: p.offsetTop - GAP, behavior: smooth ? 'smooth' : 'auto' });
  }

  setZoom(z, fx = this.sc.clientWidth / 2, fy = this.sc.clientHeight / 2) {
    z = Math.max(1, Math.min(4, z)); if (Math.abs(z - this.z) < 0.01) return;
    const k = z / this.z;
    const cx = this.sc.scrollLeft + fx, cy = this.sc.scrollTop + fy;
    this.z = z; this.layout();
    this.sc.scrollLeft = cx * k - fx; this.sc.scrollTop = cy * k - fy;
    clearTimeout(this._rz); this._rz = setTimeout(() => this.rerender(), 60);
  }

  gestures() {
    let d0 = 0, mid = null, s = 1, lastTap = 0;
    const dist = t => Math.hypot(t[0].clientX - t[1].clientX, t[0].clientY - t[1].clientY);
    this.sc.addEventListener('touchstart', e => {
      if (e.touches.length === 2) {
        d0 = dist(e.touches); const r = this.sc.getBoundingClientRect();
        mid = { x: (e.touches[0].clientX + e.touches[1].clientX) / 2 - r.left, y: (e.touches[0].clientY + e.touches[1].clientY) / 2 - r.top };
        this.inner.style.transformOrigin = `${this.sc.scrollLeft + mid.x}px ${this.sc.scrollTop + mid.y}px`;
      } else if (e.touches.length === 1) {
        const now = Date.now();
        if (now - lastTap < 280) {
          const r = this.sc.getBoundingClientRect();
          this.setZoom(this.z > 1.2 ? 1 : 2, e.touches[0].clientX - r.left, e.touches[0].clientY - r.top);
          lastTap = 0; e.preventDefault();
        } else lastTap = now;
      }
    }, { passive: false });
    this.sc.addEventListener('touchmove', e => {
      if (e.touches.length === 2 && d0) {
        e.preventDefault(); s = Math.max(1 / this.z, Math.min(4 / this.z, dist(e.touches) / d0));
        this.inner.style.transform = `scale(${s})`;
      }
    }, { passive: false });
    this.sc.addEventListener('touchend', e => {
      if (d0 && e.touches.length < 2) {
        this.inner.style.transform = ''; d0 = 0;
        this.setZoom(this.z * s, mid.x, mid.y); s = 1;
      }
    });
  }

  async search(q, onProgress) {
    q = q.trim().toLowerCase(); this.clearHits(); if (!q) return [];
    const out = [];
    for (let i = 0; i < this.n && !this.dead; i++) {
      const page = await this.doc.getPage(i + 1);
      const tc = await page.getTextContent(); const vp = page.getViewport({ scale: 1 });
      const boxes = []; let snippet = null;
      for (const it of tc.items) {
        const s = (it.str || '').toLowerCase(); const at = s.indexOf(q);
        if (at < 0) continue;
        const tx = pdfjs.Util.transform(vp.transform, it.transform);
        const h = Math.hypot(tx[2], tx[3]); const w = it.width;
        const fw = w / Math.max(1, s.length);
        boxes.push({ x: (tx[4] + fw * at) / vp.width, y: (tx[5] - h) / vp.height, w: (fw * q.length) / vp.width, h: (h * 1.2) / vp.height });
        if (!snippet) { const a = Math.max(0, at - 30); snippet = (a ? '…' : '') + it.str.slice(a, at + q.length + 40); }
      }
      if (boxes.length) { this.hits.set(i, boxes); out.push({ page: i + 1, count: boxes.length, snippet }); this.drawHits(i); }
      onProgress?.(i + 1, this.n, out);
    }
    return out;
  }

  drawHits(i) {
    const p = this.pages[i]; p.querySelectorAll('.hit').forEach(h => h.remove());
    (this.hits.get(i) || []).forEach(b => {
      const d = document.createElement('i'); d.className = 'hit';
      Object.assign(d.style, { left: b.x * 100 + '%', top: b.y * 100 + '%', width: b.w * 100 + '%', height: b.h * 100 + '%' });
      p.append(d);
    });
  }

  clearHits() { this.hits.clear(); this.inner.querySelectorAll('.hit').forEach(h => h.remove()); }

  destroy() {
    this.dead = true; this.io?.disconnect(); this.ro?.disconnect();
    this.rendered.forEach(r => r.task?.cancel()); this.rendered.clear();
    this.inner.querySelectorAll('canvas').forEach(c => { c.width = c.height = 0; });
    this.sc.replaceChildren(); this.doc.destroy();
  }
}
