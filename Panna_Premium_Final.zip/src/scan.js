import { PDFDocument } from 'pdf-lib';
import Sortable from 'sortablejs';
import { L } from './i18n.js';
import { I } from './icons.js';
import { $, $$, esc, screen, toast, busy, tap, ask, choose, confirmBox } from './ui.js';
import { takePhoto, pickPhotos, blobToCanvas, canvasBytes, addToLibrary, saveToPhone, shareFile, copyText, shareText, pickPdfs } from './lib.js';
import { detectQuad, warp, rotate90, applyFilter } from './imgproc.js';
import { ocrCanvas, aadhaarBoxes } from './ocr.js';
import { loadPdf } from './pdf.js';
import { resultSheet } from './result.js';

const FILTERS = () => [['magic', L('मैजिक', 'Magic')], ['original', L('असली', 'Original')], ['gray', L('ग्रे', 'Gray')], ['bw', L('B&W', 'B&W')]];
const thumbOf = (c, max = 240) => { const k = max / Math.max(c.width, c.height); const t = document.createElement('canvas');
  t.width = c.width * k; t.height = c.height * k; t.getContext('2d').drawImage(c, 0, 0, t.width, t.height); return t.toDataURL('image/jpeg', .7); };

/* ---------- crop + filter editor ---------- */
export function cropEditor(srcCanvas, { filter = 'magic', quad, title, showFilters = true } = {}) {
  return new Promise(res => {
    let src = srcCanvas, q = quad || detectQuad(src).quad, stage = 'crop', warped = null, fil = filter;
    const s = screen(title || L('किनारे ठीक करें', 'Adjust corners'), { cls: 'dark', action: L('आगे', 'Next'), onClose: () => res(null) });
    s.body.innerHTML = `<div class="cropwrap"><div class="cropstage"><canvas class="cimg"></canvas>
      <svg class="cquad"><polygon/></svg>${[0, 1, 2, 3].map(i => `<i class="handle" data-h="${i}"></i>`).join('')}</div></div>
      <div class="ctools">
        <button class="pill" data-c="rot">${I.rotate}${L('घुमाएँ', 'Rotate')}</button>
        <button class="pill" data-c="full">${I.fit}${L('पूरा फ़ोटो', 'Full photo')}</button>
        <button class="pill" data-c="auto">${I.scan}${L('ऑटो', 'Auto')}</button>
      </div>
      <div class="fchips" hidden>${FILTERS().map(([k, l]) => `<button class="chip" data-f="${k}">${l}</button>`).join('')}</div>`;
    const stageEl = $('.cropstage', s), cv = $('.cimg', s), poly = $('polygon', s), svg = $('.cquad', s);
    let scale = 1;
    function draw() {
      const box = $('.cropwrap', s)?.getBoundingClientRect();
      const show = stage === 'crop' ? src : warped;
      if (!box || box.width < 60 || box.height < 60 || !show) return;
      scale = Math.min((box.width - 32) / show.width, (box.height - 32) / show.height);
      const pw = Math.round(show.width * scale), ph = Math.round(show.height * scale);
      const k = Math.min(2, devicePixelRatio || 1);
      cv.width = pw * k; cv.height = ph * k; cv.style.width = pw + 'px'; cv.style.height = ph + 'px';
      stageEl.style.width = pw + 'px'; stageEl.style.height = ph + 'px';
      cv.getContext('2d').drawImage(show, 0, 0, cv.width, cv.height);
      svg.setAttribute('viewBox', `0 0 ${pw} ${ph}`);
      const crop = stage === 'crop'; svg.style.display = crop ? '' : 'none';
      $$('.handle', s).forEach((hd, i) => { hd.style.display = crop ? '' : 'none'; hd.style.left = q[i].x * scale + 'px'; hd.style.top = q[i].y * scale + 'px'; });
      poly.setAttribute('points', q.map(p => `${p.x * scale},${p.y * scale}`).join(' '));
    }
    let drag = -1;
    stageEl.addEventListener('pointerdown', e => { const hd = e.target.closest('.handle'); if (!hd) return; drag = +hd.dataset.h; hd.setPointerCapture(e.pointerId); e.preventDefault(); });
    stageEl.addEventListener('pointermove', e => { if (drag < 0) return; const r = stageEl.getBoundingClientRect();
      q[drag] = { x: Math.max(0, Math.min(src.width, (e.clientX - r.left) / scale)), y: Math.max(0, Math.min(src.height, (e.clientY - r.top) / scale)) }; draw(); });
    stageEl.addEventListener('pointerup', () => { drag = -1; });
    async function preview() {
      const b = busy(L('ठीक कर रहे हैं…', 'Processing…')); await new Promise(r => setTimeout(r, 30));
      const flat = warp(src, q, 1400); warped = applyFilter(flat, fil); b.done();
      $$('.chip', s).forEach(c => c.setAttribute('aria-pressed', c.dataset.f === fil)); draw();
    }
    s.addEventListener('click', async e => {
      const c = e.target.closest('[data-c]')?.dataset.c, f = e.target.closest('[data-f]')?.dataset.f;
      if (c) tap();
      if (c === 'rot') { src = rotate90(src); q = detectQuad(src).quad; if (stage === 'filter') await preview(); draw(); }
      if (c === 'full') { q = [{ x: 0, y: 0 }, { x: src.width, y: 0 }, { x: src.width, y: src.height }, { x: 0, y: src.height }]; draw(); }
      if (c === 'auto') { q = detectQuad(src).quad; draw(); }
      if (f) { fil = f; tap(); await preview(); }
    });
    s.go.onclick = async () => {
      tap();
      if (stage === 'crop' && showFilters) {
        stage = 'filter'; $('.ctools', s).hidden = true; $('.fchips', s).hidden = false; s.go.textContent = L('पेज जोड़ें', 'Add page');
        $('.vtitle', s).textContent = L('रंग चुनें', 'Choose look'); await preview(); return;
      }
      const b = busy(L('पेज बना रहे हैं…', 'Making page…')); await new Promise(r => setTimeout(r, 30));
      const out = applyFilter(warp(src, q, 2600), showFilters ? fil : 'original'); b.done();
      res({ canvas: out, filter: fil }); s.close();
    };
    new ResizeObserver(draw).observe($('.cropwrap', s)); draw();
  });
}

/* ---------- ID card composition (A4 @ 200dpi) ---------- */
function composeId(front, back) {
  const dpi = 200, mm = dpi / 25.4, W = Math.round(210 * mm), H = Math.round(297 * mm);
  const c = document.createElement('canvas'); c.width = W; c.height = H; const ctx = c.getContext('2d');
  ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, W, H);
  const cw = 85.6 * mm, ch = 54 * mm, x = (W - cw) / 2;
  [front, back].filter(Boolean).forEach((img, i) => {
    let src = img; if (src.height > src.width) src = rotate90(src);
    const y = 30 * mm + i * (ch + 20 * mm);
    ctx.save(); roundRect(ctx, x, y, cw, ch, 3 * mm); ctx.clip(); ctx.drawImage(src, x, y, cw, ch); ctx.restore();
    ctx.strokeStyle = '#999'; ctx.lineWidth = 1; roundRect(ctx, x, y, cw, ch, 3 * mm); ctx.stroke();
  });
  return c;
}
function roundRect(ctx, x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }

async function maskAadhaar(c, onMsg) {
  onMsg?.(L('आधार नंबर ढूँढ रहे हैं…', 'Finding Aadhaar number…'));
  const r = await ocrCanvas(c); const boxes = aadhaarBoxes(r.words);
  const ctx = c.getContext('2d'); ctx.fillStyle = '#000';
  boxes.forEach(b => ctx.fillRect(b.x0 - 3, b.y0 - 3, b.x1 - b.x0 + 6, b.y1 - b.y0 + 6));
  return boxes.length;
}

/* ---------- PDF from page canvases (optionally searchable) ---------- */
export async function canvasesToPdf(canvases, { ocr = false, onMsg, pageWidthPt = 595.28, fixed } = {}) {
  const pdf = await PDFDocument.create();
  for (let i = 0; i < canvases.length; i++) {
    const c = canvases[i];
    onMsg?.(L(`पेज ${i + 1}/${canvases.length}`, `Page ${i + 1}/${canvases.length}`), i / canvases.length);
    const img = await pdf.embedJpg(await canvasBytes(c, 'image/jpeg', .86));
    const W = fixed ? fixed[0] : pageWidthPt, H = fixed ? fixed[1] : pageWidthPt * c.height / c.width;
    const page = pdf.addPage([W, H]); page.drawImage(img, { x: 0, y: 0, width: W, height: H });
    if (ocr) {
      onMsg?.(L(`OCR: पेज ${i + 1}/${canvases.length} पढ़ रहे हैं…`, `OCR: reading page ${i + 1}/${canvases.length}…`), i / canvases.length);
      const r = await ocrCanvas(c, { dpi: c.width / (W / 72), pdf: true });
      if (r.text && r.pdf) { const [emb] = await pdf.embedPdf(await PDFDocument.load(r.pdf), [0]); page.drawPage(emb, { x: 0, y: 0, width: W, height: H }); }
    }
  }
  return pdf.save();
}

/* ---------- scanner screen ---------- */
export function openScanner(mode = 'doc') {
  const pages = []; let pendingFront = null;
  let sortable;
  const s = screen(L('स्कैनर', 'Scanner'), { action: L('PDF बनाएँ', 'Make PDF'), onClose: () => { sortable?.destroy(); const released = new Set(); for (const p of pages) { for (const c of [p.canvas, ...(p.canvas?.cards || [])]) if (c && !released.has(c)) { released.add(c); c.width = 0; c.height = 0; } } if (pendingFront && !released.has(pendingFront)) { pendingFront.width = 0; pendingFront.height = 0; } } });
  s.body.innerHTML = `
    <div class="seg modes">${[['doc', L('डॉक्यूमेंट', 'Document')], ['id', L('ID कार्ड', 'ID card')], ['book', L('किताब', 'Book')]].map(([k, l]) =>
      `<button data-m="${k}">${l}</button>`).join('')}</div>
    <p class="hint"></p>
    <div class="capbtns"><button class="capbig" data-cap="cam">${I.scan}<b>${L('कैमरा', 'Camera')}</b></button>
      <button class="capbig alt" data-cap="gal">${I.image}<b>${L('गैलरी', 'Gallery')}</b></button></div>
    <div class="pgrid"></div>`;
  const grid = $('.pgrid', s);
  sortable = new Sortable(grid, { animation: 150, delay: 180, delayOnTouchOnly: true, onEnd: e => { const [m] = pages.splice(e.oldIndex, 1); pages.splice(e.newIndex, 0, m); renderGrid(); } });
  function setMode(m) {
    mode = m; pendingFront = null;
    $$('[data-m]', s).forEach(b => b.setAttribute('aria-pressed', b.dataset.m === m));
    $('.hint', s).textContent = { doc: L('काग़ज़ को सपाट रखें और ऊपर से फ़ोटो लें। किनारे ऐप ख़ुद पकड़ लेगा।', 'Lay the paper flat and shoot from above. The app finds the edges.'),
      id: L('पहले कार्ड के आगे का, फिर पीछे का फ़ोटो लें। दोनों A4 के एक पेज पर असली साइज़ में आएँगे।', 'Shoot the front, then the back. Both land on one A4 page at real size.'),
      book: L('खुली किताब के दोनों पेज एक साथ लें। ऐप बीच से दो पेज बना देगा।', 'Shoot both open pages together. The app splits them into two.') }[m];
  }
  function renderGrid() {
    grid.innerHTML = pages.map((p, i) => `<div class="ptile" data-i="${i}"><img src="${p.thumb}" alt=""><span>${i + 1}</span>
      <button class="tdel" data-del="${i}" aria-label="${L('हटाएँ', 'Delete')}">${I.close}</button></div>`).join('')
      + (pendingFront ? `<div class="ptile wait"><img src="${thumbOf(pendingFront)}" alt=""><span>${L('पीछे का फ़ोटो लें', 'Now the back')}</span></div>` : '');
    s.go.disabled = !pages.length;
  }
  async function addFrom(blobs) {
    for (const blob of blobs || []) {
      const b = busy(L('फ़ोटो खोल रहे हैं…', 'Loading photo…')); let c, r;
      try { c = await blobToCanvas(blob); } catch (e) { b.done(); toast(L('फ़ोटो नहीं खुली: ', 'Could not open photo: ') + (e?.message || ''), 4000); continue; }
      b.done();
      try { r = await cropEditor(c, { filter: mode === 'id' ? 'original' : 'magic', title: mode === 'id' ? (pendingFront ? L('कार्ड का पीछे', 'Card back') : L('कार्ड का आगे', 'Card front')) : undefined }); }
      finally { c.width = 0; c.height = 0; }
      if (!r) continue;
      if (mode === 'id') {
        if (!pendingFront) { pendingFront = r.canvas; renderGrid(); toast(L('अब कार्ड के पीछे का फ़ोटो लें', 'Now take the back side'), 3000); continue; }
        const page = composeId(pendingFront, r.canvas); page.cards = [pendingFront, r.canvas]; pendingFront = null;
        pages.push({ canvas: page, thumb: thumbOf(page), id: true });
      } else if (mode === 'book') {
        const c2 = r.canvas, half = Math.floor(c2.width / 2);
        for (const x of [0, half]) { const p = document.createElement('canvas'); p.width = half; p.height = c2.height; p.getContext('2d').drawImage(c2, -x, 0); pages.push({ canvas: p, thumb: thumbOf(p) }); }
        c2.width = 0; c2.height = 0;
      } else pages.push({ canvas: r.canvas, thumb: thumbOf(r.canvas) });
      renderGrid();
    }
  }
  s.addEventListener('click', async e => {
    const m = e.target.closest('[data-m]')?.dataset.m; if (m) { tap(); setMode(m); return; }
    const cap = e.target.closest('[data-cap]')?.dataset.cap;
    if (cap) { tap(); addFrom(cap === 'cam' ? await takePhoto() : await pickPhotos(mode !== 'id')); return; }
    const del = e.target.closest('[data-del]')?.dataset.del;
    if (del != null) { tap(); pages.splice(+del, 1); renderGrid(); }
  });
  s.go.onclick = () => finish();
  async function finish() {
    const hasId = pages.some(p => p.id);
    const name = (mode === 'id' ? 'ID card ' : 'Scan ') + new Date().toLocaleDateString('en-GB').replace(/\//g, '-');
    const opts = await new Promise(res => {
      const d = document.createElement('div'); d.className = 'scrim center in';
      d.innerHTML = `<form class="dialog"><h3>${L('PDF सेव करें', 'Save PDF')}</h3>
        <input id="sn" value="${esc(name)}">
        <label class="tog"><input type="checkbox" id="so" ${mode !== 'id' ? 'checked' : ''}><span>${L('OCR: टेक्स्ट खोजने और कॉपी करने लायक बनाएँ', 'OCR: make text searchable & copyable')}</span></label>
        ${hasId ? `<label class="tog"><input type="checkbox" id="sa"><span>${L('आधार के पहले 8 अंक छुपाएँ (Masked Aadhaar)', 'Hide first 8 Aadhaar digits (masked)')}</span></label>` : ''}
        <div class="dact"><button type="button" class="btn ghost" data-d>${L('रद्द करें', 'Cancel')}</button><button class="btn">${L('सेव करें', 'Save')}</button></div></form>`;
      document.body.append(d);
      d.querySelector('[data-d]').onclick = () => { d.remove(); res(null); };
      d.querySelector('form').onsubmit = ev => { ev.preventDefault(); const o = { name: $('#sn', d).value.trim() || name, ocr: $('#so', d).checked, mask: $('#sa', d)?.checked }; d.remove(); res(o); };
    });
    if (!opts) return;
    const b = busy(L('PDF बन रही है…', 'Making PDF…'));
    try {
      if (opts.mask) for (const p of pages) if (p.id) {
        let n = 0; for (const card of p.canvas.cards) n += await maskAadhaar(card, m => b.set(m));
        p.canvas = composeId(...p.canvas.cards); if (!n) toast(L('आधार नंबर नहीं मिला, बाद में "आधार मास्क" टूल से हाथ से छुपाएँ', 'Aadhaar number not found. Use the Aadhaar mask tool to hide it by hand.'), 5000);
      }
      const bytes = await canvasesToPdf(pages.map(p => p.canvas), { ocr: opts.ocr, onMsg: (m, f) => b.set(m, f), fixed: pages.every(p => p.id) ? [595.28, 841.89] : null });
      const meta = await addToLibrary(bytes, opts.name, { ocr: opts.ocr });
      b.done(); s.close(); resultSheet(meta);
    } catch (e) { b.done(); toast(L('PDF नहीं बन पाई: ', 'Could not make PDF: ') + (e?.message || e), 5000); }
  }
  setMode(mode); renderGrid();
  return s;
}

/* ---------- photo -> text ---------- */
export async function photoToText(fromCamera) {
  const blobs = fromCamera ? await takePhoto() : await pickPhotos(true);
  if (!blobs?.length) return;
  const b = busy(L('फ़ोटो पढ़ने की तैयारी…', 'Preparing photos…'));
  const pages = [];
  try {
    for (let i = 0; i < blobs.length; i++) {
      b.set(L(`फ़ोटो ${i + 1}/${blobs.length} तैयार करें…`, `Preparing photo ${i + 1}/${blobs.length}…`), i / blobs.length);
      const c0 = await blobToCanvas(blobs[i], 2600);
      let r;
      try {
        r = await cropEditor(c0, { filter: 'gray', title: L(`फ़ोटो ${i + 1}: पढ़ने का क्षेत्र चुनें`, `Photo ${i + 1}: select area to read`), showFilters: false });
        if (!r) {
          if (!pages.length) { b.done(); return; }
          break;
        }
        b.set(L(`फ़ोटो ${i + 1}/${blobs.length} पढ़ रहे हैं…`, `Reading photo ${i + 1}/${blobs.length}…`), (i + .15) / blobs.length);
        const res = await ocrCanvas(r.canvas, { dpi: 300, onProgress: m => {
          if (m.status === 'recognizing text') b.set(L(`फ़ोटो ${i + 1}/${blobs.length}: टेक्स्ट पहचान रहे हैं…`, `Photo ${i + 1}/${blobs.length}: recognizing text…`), (i + .15 + (m.progress || 0) * .8) / blobs.length);
        }});
        pages.push(res.text || '');
      } finally {
        c0.width = c0.height = 0;
        if (r?.canvas) r.canvas.width = r.canvas.height = 0;
      }
    }
    b.done();
    const combined = pages.map((t, i) => `${L('फ़ोटो', 'Photo')} ${i + 1}
${t || L('कोई टेक्स्ट नहीं मिला', 'No text recognized')}`).join('\n\n');
    textScreen(combined, L('फ़ोटो का टेक्स्ट', 'Photo text'));
  } catch (e) { b.done(); toast('OCR: ' + (e?.message || e), 5000); }
}

export function textScreen(text, title) {
  const s = screen(title);
  s.right.innerHTML = `<button class="ibtn" data-t="copy" aria-label="Copy">${I.copy}</button><button class="ibtn" data-t="share" aria-label="Share">${I.share}</button>`;
  s.body.innerHTML = text ? `<textarea class="ttext">${esc(text)}</textarea><div class="row2"><button class="btn" data-t="copy">${L('पूरा कॉपी करें', 'Copy all')}</button>
    <button class="btn ghost2" data-t="txt">${L('.txt फ़ाइल सेव करें', 'Save as .txt')}</button></div>`
    : `<div class="empty">${I.ocr}<b>${L('कोई टेक्स्ट नहीं मिला', 'No text found')}</b><span>${L('फ़ोटो साफ़ और सीधी लें, रोशनी अच्छी हो।', 'Use a clear, straight photo in good light.')}</span></div>`;
  s.addEventListener('click', e => {
    const a = e.target.closest('[data-t]')?.dataset.t; const v = $('.ttext', s)?.value || '';
    if (a === 'copy') copyText(v); if (a === 'share') shareText(v);
    if (a === 'txt') saveToPhone(new TextEncoder().encode(v), (title || 'text') + '.txt', 'text/plain');
  });
}

/* ---------- Aadhaar / manual masking tool ---------- */
export async function aadhaarTool() {
  const src = await choose(L('किसका आधार छुपाना है?', 'Mask Aadhaar from'), [
    ['cam', 'scan', L('कैमरा से फ़ोटो', 'Camera photo')], ['gal', 'image', L('गैलरी से फ़ोटो', 'Gallery photo')], ['pdf', 'doc', L('PDF से', 'From a PDF')]]);
  if (!src) return;
  let canvases = [];
  if (src === 'pdf') {
    const [f] = await pickPdfs({ title: L('आधार की PDF चुनें', 'Choose Aadhaar PDF') }); if (!f) return;
    const b = busy(L('PDF खोल रहे हैं…', 'Opening PDF…'));
    try { const doc = await loadPdf(f.bytes.slice(0)); for (let i = 1; i <= Math.min(doc.numPages, 4); i++) {
      const pg = await doc.getPage(i); const vp = pg.getViewport({ scale: 2.5 }); const c = document.createElement('canvas'); c.width = vp.width; c.height = vp.height;
      const ctx = c.getContext('2d'); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c.width, c.height); await pg.render({ canvasContext: ctx, viewport: vp }).promise; canvases.push(c); } doc.destroy(); }
    catch { b.done(); return toast(L('PDF नहीं खुली', 'PDF did not open')); } b.done();
  } else {
    const blobs = src === 'cam' ? await takePhoto() : await pickPhotos(false); if (!blobs.length) return;
    const r = await cropEditor(await blobToCanvas(blobs[0]), { showFilters: false, title: L('कार्ड के किनारे ठीक करें', 'Adjust card corners') }); if (!r) return;
    canvases = [r.canvas];
  }
  const b = busy(L('आधार नंबर ढूँढ रहे हैं…', 'Finding Aadhaar number…'));
  const boxesPer = [];
  try { for (const c of canvases) boxesPer.push(aadhaarBoxes((await ocrCanvas(c)).words).map(x => ({ x: x.x0 / c.width, y: x.y0 / c.height, w: (x.x1 - x.x0) / c.width, h: (x.y1 - x.y0) / c.height }))); }
  catch (e) { canvases.forEach(() => boxesPer.push([])); }
  b.done();
  maskEditor(canvases, boxesPer, L('आधार मास्क', 'Aadhaar mask'));
}

export function maskEditor(canvases, boxesPer, title) {
  const s = screen(title, { action: L('सेव करें', 'Save') });
  const found = boxesPer.flat().length;
  s.body.innerHTML = `<p class="hint">${found ? L('काले डिब्बे से नंबर छुपा दिया है। और जगह छुपानी हो तो उँगली से खींचें। किसी डिब्बे को हटाने के लिए उस पर टैप करें।', 'The number is hidden by the black box. Drag to hide more. Tap a box to remove it.')
    : L('नंबर अपने-आप नहीं मिला। जहाँ छुपाना है वहाँ उँगली से खींचकर काला डिब्बा बनाएँ।', 'Number not found automatically. Drag your finger over what to hide.')}</p>
    ${canvases.map((c, i) => `<div class="mpage" data-i="${i}"><img src="${c.toDataURL('image/jpeg', .85)}" alt="" draggable="false"></div>`).join('')}`;
  const draw = i => { const el = $(`.mpage[data-i="${i}"]`, s); $$('.mbox', el).forEach(x => x.remove());
    boxesPer[i].forEach((b, k) => el.insertAdjacentHTML('beforeend', `<i class="mbox" data-k="${k}" style="left:${b.x * 100}%;top:${b.y * 100}%;width:${b.w * 100}%;height:${b.h * 100}%"></i>`)); };
  canvases.forEach((_, i) => draw(i));
  $$('.mpage', s).forEach(el => {
    const i = +el.dataset.i; let st = null, tmp = null;
    el.addEventListener('pointerdown', e => { if (e.target.classList.contains('mbox')) { boxesPer[i].splice(+e.target.dataset.k, 1); draw(i); return; }
      const r = el.getBoundingClientRect(); st = { x: (e.clientX - r.left) / r.width, y: (e.clientY - r.top) / r.height }; el.setPointerCapture(e.pointerId);
      tmp = document.createElement('i'); tmp.className = 'mbox'; el.append(tmp); });
    el.addEventListener('pointermove', e => { if (!st) return; const r = el.getBoundingClientRect(); const x = (e.clientX - r.left) / r.width, y = (e.clientY - r.top) / r.height;
      Object.assign(tmp.style, { left: Math.min(x, st.x) * 100 + '%', top: Math.min(y, st.y) * 100 + '%', width: Math.abs(x - st.x) * 100 + '%', height: Math.abs(y - st.y) * 100 + '%' }); tmp.b = { x: Math.min(x, st.x), y: Math.min(y, st.y), w: Math.abs(x - st.x), h: Math.abs(y - st.y) }; });
    el.addEventListener('pointerup', () => { if (tmp?.b && tmp.b.w > .01 && tmp.b.h > .005) boxesPer[i].push(tmp.b); st = null; tmp?.remove(); tmp = null; draw(i); });
    el.style.touchAction = 'pan-y';
  });
  s.go.onclick = async () => {
    const out = canvases.map((c, i) => { const o = document.createElement('canvas'); o.width = c.width; o.height = c.height; const x = o.getContext('2d'); x.drawImage(c, 0, 0); x.fillStyle = '#000';
      boxesPer[i].forEach(b => x.fillRect(b.x * c.width, b.y * c.height, b.w * c.width, b.h * c.height)); return o; });
    const how = await choose(L('कैसे सेव करें?', 'Save as'), [['pdf', 'doc', 'PDF'], ['jpg', 'image', L('फ़ोटो (JPG)', 'Photo (JPG)')]]); if (!how) return;
    const name = 'Masked ' + new Date().toLocaleDateString('en-GB').replace(/\//g, '-');
    if (how === 'pdf') { const b = busy(); const bytes = await canvasesToPdf(out); const meta = await addToLibrary(bytes, name); b.done(); s.close(); resultSheet(meta); }
    else { for (let i = 0; i < out.length; i++) await saveToPhone(await canvasBytes(out[i], 'image/jpeg', .92), `${name}${out.length > 1 ? '-' + (i + 1) : ''}.jpg`, 'image/jpeg'); s.close(); }
  };
}
