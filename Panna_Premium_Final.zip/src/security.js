import createQpdf from '@neslinesli93/qpdf-wasm';
import { L } from './i18n.js';
import { I, GEM } from './icons.js';
import { $, $$, esc, toast, busy, dialog, native, baseName } from './ui.js';
import { addToLibrary } from './lib.js';
import { resultSheet } from './result.js';
import { NativeBiometric } from '@capgo/capacitor-native-biometric';
import { LocalNotifications } from '@capacitor/local-notifications';
import { updateMeta, listFiles } from './db.js';

async function qpdf(args, input) {
  const q = await createQpdf({ locateFile: () => new URL('./qpdf/qpdf.wasm', location.href).href, print: () => {}, printErr: () => {} });
  q.FS.writeFile('/in.pdf', input);
  const code = q.callMain([...args.map(a => a === '$IN' ? '/in.pdf' : a === '$OUT' ? '/out.pdf' : a)]);
  if (code !== 0 && code !== 3) throw new Error('qpdf ' + code);
  return q.FS.readFile('/out.pdf');
}
export const isEncrypted = bytes => { const s = new TextDecoder('latin1').decode(bytes.subarray(Math.max(0, bytes.length - 4096))); return /\/Encrypt\s/.test(s) || /\/Encrypt\s/.test(new TextDecoder('latin1').decode(bytes.subarray(0, Math.min(bytes.length, 200000)))); };

export function askPdfPassword(name, wrong) {
  return new Promise(res => {
    let v = null;
    const w = dialog(`<h3>${L('यह PDF पासवर्ड से बंद है', 'This PDF is password protected')}</h3><p class="muted">${esc(name)}</p>
      ${wrong ? `<p class="err">${L('पासवर्ड ग़लत है', 'Wrong password')}</p>` : ''}<input id="pw" type="password" autocomplete="off">`,
      L('खोलें', 'Open'), d => { v = $('#pw', d).value; res(v); return true; }, d => $('#pw', d).focus());
    w.oncancel = () => res(null);
  });
}

/** returns decrypted bytes for any tool (asks password if needed) or null */
export async function unlocked(file) {
  if (!file.meta?.locked && !isEncrypted(file.bytes)) return file.bytes;
  let wrong = false;
  for (;;) {
    const pw = await askPdfPassword(file.name, wrong); if (pw == null) return null;
    try { return await qpdf([`--password=${pw}`, '--decrypt', '$IN', '$OUT'], file.bytes); } catch { wrong = true; }
  }
}

export async function addPassword(file) {
  const bytes = await unlocked(file); if (!bytes) return;
  const pw = await new Promise(res => { const w = dialog(`<h3>${L('PDF पर पासवर्ड लगाएँ', 'Add a password')}</h3>
      <p class="muted">${L('यह पासवर्ड याद रखें। भूल गए तो फ़ाइल नहीं खुलेगी।', 'Remember it. If forgotten, the file cannot be opened.')}</p>
      <input id="p1" type="password" placeholder="${L('पासवर्ड', 'Password')}"><input id="p2" type="password" placeholder="${L('फिर से डालें', 'Type again')}"><p class="err" hidden></p>`,
    L('लगाएँ', 'Apply'), d => { const a = $('#p1', d).value, b = $('#p2', d).value; const er = $('.err', d);
      if (a.length < 4) { er.hidden = false; er.textContent = L('कम से कम 4 अक्षर', 'At least 4 characters'); return false; }
      if (a !== b) { er.hidden = false; er.textContent = L('दोनों पासवर्ड अलग हैं', 'Passwords do not match'); return false; } res(a); return true; }, d => $('#p1', d).focus());
    w.oncancel = () => res(null); });
  if (!pw) return;
  const b = busy(L('ताला लगा रहे हैं…', 'Locking…'));
  try { const out = await qpdf(['--encrypt', pw, pw, '256', '--', '$IN', '$OUT'], bytes);
    const meta = await addToLibrary(out, baseName(file.name) + L(' (लॉक)', ' (locked)'), { password: pw }); b.done(); resultSheet(meta); }
  catch (e) { b.done(); toast(L('पासवर्ड नहीं लग पाया', 'Could not add password'), 4000); }
}

export async function removePassword(file) {
  if (!file.meta?.locked && !isEncrypted(file.bytes)) return toast(L('इस PDF पर पासवर्ड नहीं है', 'This PDF has no password'));
  const bytes = await unlocked(file); if (!bytes) return;
  const meta = await addToLibrary(bytes, baseName(file.name) + L(' (बिना पासवर्ड)', ' (unlocked)')); resultSheet(meta);
}

/* ---------- app lock ---------- */
const sha = async s => [...new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode('panna:' + s)))].map(b => b.toString(16).padStart(2, '0')).join('');
export const lockOn = () => !!localStorage.getItem('panna.pin');
export const bioOn = () => localStorage.getItem('panna.bio') === '1';
export async function bioAvailable() { if (!native) return false; try { return (await NativeBiometric.isAvailable()).isAvailable; } catch { return false; } }

export function setPin() {
  return new Promise(res => { const w = dialog(`<h3>${L('ऐप लॉक PIN बनाएँ', 'Create app lock PIN')}</h3>
    <p class="muted">${L('4 से 6 अंक। PIN भूल गए तो ऐप दोबारा इंस्टॉल करना पड़ेगा और फ़ाइलें हट जाएँगी, इसलिए ध्यान से याद रखें।', '4 to 6 digits. If you forget it you must reinstall the app and files will be lost.')}</p>
    <input id="p1" type="password" inputmode="numeric" maxlength="6" placeholder="PIN"><input id="p2" type="password" inputmode="numeric" maxlength="6" placeholder="${L('फिर से', 'Again')}"><p class="err" hidden></p>`,
    L('लगाएँ', 'Set'), async d => { const a = $('#p1', d).value, b = $('#p2', d).value, er = $('.err', d);
      if (!/^\d{4,6}$/.test(a)) { er.hidden = false; er.textContent = L('4 से 6 अंक डालें', 'Enter 4 to 6 digits'); return false; }
      if (a !== b) { er.hidden = false; er.textContent = L('दोनों PIN अलग हैं', 'PINs do not match'); return false; }
      localStorage.setItem('panna.pin', await sha(a)); res(true); return true; }, d => $('#p1', d).focus());
    w.oncancel = () => res(false); });
}
export function clearPin() { localStorage.removeItem('panna.pin'); localStorage.removeItem('panna.bio'); }

let locked = false;
export async function showLock() {
  if (!lockOn() || locked) return; locked = true;
  const el = document.createElement('div'); el.className = 'lockscreen';
  el.innerHTML = `${GEM}<h2>${L('Panna लॉक है', 'Panna is locked')}</h2><div class="dots">${'<i></i>'.repeat(4)}</div><p class="err" hidden>${L('ग़लत PIN', 'Wrong PIN')}</p>
    <div class="keys">${[1, 2, 3, 4, 5, 6, 7, 8, 9, 'bio', 0, 'del'].map(k => `<button data-k="${k}" ${k === 'bio' && !bioOn() ? 'style="visibility:hidden"' : ''}>${k === 'bio' ? I.finger : k === 'del' ? I.back : k}</button>`).join('')}</div>
    <button class="okpin btn" hidden>OK</button>`;
  document.body.append(el); let pin = '';
  const upd = () => { const dots = $('.dots', el); const n = Math.max(4, pin.length); dots.innerHTML = Array.from({ length: n }, (_, i) => `<i class="${i < pin.length ? 'on' : ''}"></i>`).join(''); $('.okpin', el).hidden = pin.length < 4; };
  const unlock = () => { locked = false; el.classList.add('out'); setTimeout(() => el.remove(), 200); };
  const check = async () => { if (await sha(pin) === localStorage.getItem('panna.pin')) unlock(); else if (pin.length >= 6) { $('.err', el).hidden = false; pin = ''; upd(); } };
  const bio = async () => { try { await NativeBiometric.verifyIdentity({ reason: L('Panna खोलें', 'Unlock Panna'), title: 'Panna' }); unlock(); } catch {} };
  el.addEventListener('click', async e => { const k = e.target.closest('[data-k]')?.dataset.k;
    if (e.target.closest('.okpin')) { if (await sha(pin) === localStorage.getItem('panna.pin')) unlock(); else { $('.err', el).hidden = false; pin = ''; upd(); } return; }
    if (k == null) return; $('.err', el).hidden = true;
    if (k === 'bio') return bio(); if (k === 'del') pin = pin.slice(0, -1); else if (pin.length < 6) pin += k; upd(); if (pin.length >= 4) check(); });
  upd(); if (bioOn()) setTimeout(bio, 350);
}

/* ---------- expiry reminders ---------- */
export async function setReminder(meta) {
  const cur = meta.expiry || {};
  const r = await new Promise(res => { const w = dialog(`<h3>${L('खत्म होने की याद', 'Expiry reminder')}</h3>
    <p class="muted">${L('जैसे बीमा, PUC, लाइसेंस, किराया-नामा। तारीख़ से पहले फ़ोन याद दिलाएगा।', 'Like insurance, PUC, licence, rent agreement. Your phone will remind you before the date.')}</p>
    <label class="fl">${L('खत्म होने की तारीख़', 'Expiry date')}<input id="ed" type="date" value="${cur.date || ''}"></label>
    <label class="fl">${L('कितने दिन पहले याद दिलाएँ', 'Remind how many days before')}<select id="eb">${[3, 7, 15, 30].map(n => `<option ${n === (cur.before || 7) ? 'selected' : ''}>${n}</option>`).join('')}</select></label>
    ${cur.date ? `<button type="button" class="btn ghost2" data-rm>${L('याद हटाएँ', 'Remove reminder')}</button>` : ''}`,
    L('सेट करें', 'Set'), d => { const date = $('#ed', d).value; if (!date) return false; res({ date, before: +$('#eb', d).value }); return true; });
    w.addEventListener('click', e => { if (e.target.closest('[data-rm]')) { res('rm'); w.querySelector('[data-d]').click(); } });
    w.oncancel = () => res(null); });
  if (!r) return;
  const nid = meta.expiry?.nid || (Math.floor(Math.random() * 1e8) + 1);
  if (native) try { await LocalNotifications.cancel({ notifications: [{ id: nid }, { id: nid + 1 }] }); } catch {}
  if (r === 'rm') { await updateMeta(meta.id, { expiry: null }); toast(L('याद हटा दी', 'Reminder removed')); return; }
  const day = new Date(r.date + 'T10:00:00'), pre = new Date(day.getTime() - r.before * 864e5), name = baseName(meta.name);
  if (native) {
    try {
      const p = await LocalNotifications.requestPermissions();
      if (p.display !== 'granted') toast(L('नोटिफ़िकेशन की इजाज़त दें तभी याद आएगी', 'Allow notifications to get reminders'), 4000);
      const list = [];
      if (pre > new Date()) list.push({ id: nid, title: L('जल्द खत्म: ', 'Expiring soon: ') + name, body: L(`${r.before} दिन बाद खत्म हो रहा है`, `Expires in ${r.before} days`), schedule: { at: pre, allowWhileIdle: true }, extra: { id: meta.id } });
      if (day > new Date()) list.push({ id: nid + 1, title: L('आज खत्म: ', 'Expires today: ') + name, body: L('आज आख़िरी दिन है', 'Today is the last day'), schedule: { at: day, allowWhileIdle: true }, extra: { id: meta.id } });
      if (list.length) await LocalNotifications.schedule({ notifications: list });
    } catch (e) { toast(L('याद सेट नहीं हुई: ', 'Reminder failed: ') + (e?.message || ''), 4000); }
  }
  await updateMeta(meta.id, { expiry: { ...r, nid } });
  toast(L('याद सेट हो गई', 'Reminder set'));
}

export async function upcoming() {
  const now = Date.now();
  return (await listFiles()).filter(f => f.expiry?.date).map(f => ({ f, days: Math.ceil((new Date(f.expiry.date + 'T23:59:59') - now) / 864e5) }))
    .filter(x => x.days <= 45).sort((a, b) => a.days - b.days);
}
