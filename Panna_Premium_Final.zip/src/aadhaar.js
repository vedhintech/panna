/** Find Aadhaar-like numbers among OCR words and return a box covering the first 8 digits. */
export function aadhaarBoxes(words) {
  if (!Array.isArray(words) || words.length === 0) return [];
  const boxes = [];
  const norm = value => {
    const s = String(value ?? '');
    const digitCount = (s.match(/[0-9०-९]/g) || []).length;
    if (digitCount < 2) return '';
    return s.replace(/[०-९]/g, x => '०१२३४५६७८९'.indexOf(x))
      .replace(/[।|lIi!]/g, '1').replace(/[Oo]/g, '0').replace(/[^\d]/g, '');
  };
  const validBox = b => b && [b.x0, b.y0, b.x1, b.y1].every(Number.isFinite) && b.x1 > b.x0 && b.y1 > b.y0;

  for (let i = 0; i < words.length; i++) {
    const current = words[i];
    if (!validBox(current?.bbox)) continue;
    const a = norm(current.text);
    if (a.length === 12 && /^\d{12}$/.test(a)) {
      const b = current.bbox;
      boxes.push({ x0: b.x0, y0: b.y0, x1: b.x0 + (b.x1 - b.x0) * (8 / 12), y1: b.y1 });
      continue;
    }
    if (a.length !== 4 || i + 2 >= words.length) continue;

    const second = words[i + 1], third = words[i + 2];
    if (!validBox(second?.bbox) || !validBox(third?.bbox)) continue;
    if (norm(second.text).length !== 4 || norm(third.text).length !== 4) continue;

    const b1 = current.bbox, b2 = second.bbox, b3 = third.bbox;
    const heights = [b1.y1 - b1.y0, b2.y1 - b2.y0, b3.y1 - b3.y0];
    const lineHeight = Math.max(1, Math.min(...heights));
    const sameLine = Math.abs(b1.y0 - b2.y0) < lineHeight && Math.abs(b1.y0 - b3.y0) < lineHeight;
    const closeEnough = (left, right) => {
      const gap = right.x0 - left.x1;
      return gap >= -lineHeight * 0.25 && gap <= lineHeight * 2.5;
    };
    if (sameLine && closeEnough(b1, b2) && closeEnough(b2, b3)) {
      boxes.push({ x0: b1.x0, y0: Math.min(b1.y0, b2.y0, b3.y0), x1: b2.x1, y1: Math.max(b1.y1, b2.y1, b3.y1) });
      i += 2;
    }
  }
  return boxes;
}
