import { PDFDocument, rgb } from 'pdf-lib';
import fontkit from '@pdf-lib/fontkit';
import { L } from './i18n.js';
import { I } from './icons.js';
import { $, $$, esc, screen, toast, busy, dialog, choose } from './ui.js';
import { addToLibrary, textCanvas, canvasBytes } from './lib.js';
import { kvGet, kvSet } from './db.js';
import { pickSaved } from './editor.js';
import { resultSheet } from './result.js';

const ONES = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
const TENS = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
const two = n => n < 20 ? ONES[n] : TENS[Math.floor(n / 10)] + (n % 10 ? ' ' + ONES[n % 10] : '');
const three = n => (n >= 100 ? ONES[Math.floor(n / 100)] + ' Hundred' + (n % 100 ? ' ' : '') : '') + (n % 100 ? two(n % 100) : '');
export function inWords(amount) {
  let n = Math.floor(amount), p = Math.round((amount - n) * 100); if (!n && !p) return 'Zero Rupees Only';
  const parts = []; const cr = Math.floor(n / 1e7); n %= 1e7; const lk = Math.floor(n / 1e5); n %= 1e5; const th = Math.floor(n / 1e3); n %= 1e3;
  if (cr) parts.push(three(cr) + ' Crore'); if (lk) parts.push(two(lk) + ' Lakh'); if (th) parts.push(two(th) + ' Thousand'); if (n) parts.push(three(n));
  return 'Rupees ' + parts.join(' ') + (p ? ' and ' + two(p) + ' Paise' : '') + ' Only';
}
const money = v => '₹ ' + v.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const deva = s => /[\u0900-\u097F]/.test(s);

async function bizList() { return (await kvGet('biz')) || []; }

function bizDialog(b = {}) {
  return new Promise(res => {
    const f = (id, ph, v = '', tag = 'input') => tag === 'input' ? `<input id="${id}" placeholder="${ph}" value="${esc(v)}">` : `<textarea id="${id}" rows="2" placeholder="${ph}">${esc(v)}</textarea>`;
    const w = dialog(`<h3>${L('आपकी फ़र्म', 'Your business')}</h3><div class="dscroll">
      ${f('bn', L('फ़र्म का नाम *', 'Business name *'), b.name)}${f('ba', L('पता', 'Address'), b.addr, 'ta')}
      ${f('bp', L('फ़ोन', 'Phone'), b.phone)}${f('bg', 'GSTIN', b.gst)}${f('bs', L('राज्य (जैसे Rajasthan)', 'State (e.g. Rajasthan)'), b.state)}
      ${f('bk', L('बैंक: नाम, खाता नं., IFSC', 'Bank: name, A/c no., IFSC'), b.bank, 'ta')}${f('bt', L('नियम/शर्तें (बिल के नीचे)', 'Terms (bill footer)'), b.terms, 'ta')}</div>`,
      L('सेव करें', 'Save'), d => { const name = $('#bn', d).value.trim(); if (!name) return false;
        res({ ...b, id: b.id || Date.now().toString(36), name, addr: $('#ba', d).value.trim(), phone: $('#bp', d).value.trim(), gst: $('#bg', d).value.trim().toUpperCase(),
          state: $('#bs', d).value.trim(), bank: $('#bk', d).value.trim(), terms: $('#bt', d).value.trim(), next: b.next || 1 }); return true; }, d => $('#bn', d).focus());
    w.oncancel = () => res(null);
  });
}

export async function invoiceMaker() {
  let list = await bizList(), biz = list[0];
  if (!biz) { biz = await bizDialog(); if (!biz) return; list = [biz]; await kvSet('biz', list); }
  const items = [{ d: '', hsn: '', q: 1, unit: '', r: 0, g: 5 }];
  const s = screen(L('बिल / कोटेशन बनाएँ', 'Make bill / quotation'), { action: L('PDF बनाएँ', 'Make PDF') });
  const today = new Date().toISOString().slice(0, 10);
  s.body.innerHTML = `
    <div class="card"><div class="row between"><b class="bizname"></b><button class="link" data-b="switch">${L('बदलें', 'Change')}</button></div><small class="muted bizsub"></small></div>
    <div class="seg" id="ty"><button data-v="TAX INVOICE" aria-pressed="true">${L('GST बिल', 'Tax invoice')}</button><button data-v="BILL OF SUPPLY" aria-pressed="false">${L('बिना GST', 'No GST')}</button><button data-v="QUOTATION" aria-pressed="false">${L('कोटेशन', 'Quotation')}</button></div>
    <div class="grid2"><label class="fl">${L('बिल नं.', 'Bill no.')}<input id="in"></label><label class="fl">${L('तारीख़', 'Date')}<input id="id" type="date" value="${today}"></label></div>
    <h3 class="ghead">${L('ग्राहक', 'Customer')}</h3>
    <input id="cn" class="inp" placeholder="${L('ग्राहक का नाम *', 'Customer name *')}"><textarea id="ca" class="inp" rows="2" placeholder="${L('पता', 'Address')}"></textarea>
    <div class="grid2"><input id="cg" class="inp" placeholder="${L('ग्राहक GSTIN', 'Customer GSTIN')}"><input id="cp" class="inp" placeholder="${L('फ़ोन', 'Phone')}"></div>
    <label class="tog"><input type="checkbox" id="ig"><span>${L('दूसरे राज्य का ग्राहक (IGST लगेगा)', 'Other-state customer (IGST)')}</span></label>
    <h3 class="ghead">${L('सामान', 'Items')}</h3><div class="items"></div>
    <button class="btn ghost2 wide" data-b="add">${I.plus}${L('और सामान जोड़ें', 'Add item')}</button>
    <div class="card totals"></div>
    <label class="tog"><input type="checkbox" id="ss" checked><span>${L('साइन और मोहर लगाएँ', 'Add signature & stamp')}</span></label>`;
  const showBiz = () => { $('.bizname', s).textContent = biz.name; $('.bizsub', s).textContent = [biz.gst && 'GSTIN ' + biz.gst, biz.phone].filter(Boolean).join(', '); $('#in', s).value = String(biz.next || 1); };
  const calc = () => {
    const type = $('#ty [aria-pressed=true]', s).dataset.v, gst = type === 'TAX INVOICE' || type === 'QUOTATION';
    let sub = 0, tax = 0; items.forEach(it => { const a = (+it.q || 0) * (+it.r || 0); sub += a; if (gst) tax += a * (+it.g || 0) / 100; });
    const tot = sub + tax, round = Math.round(tot) - tot; return { type, gst, sub, tax, round, grand: Math.round(tot), igst: $('#ig', s).checked };
  };
  const renderItems = () => {
    $('.items', s).innerHTML = items.map((it, i) => `<div class="icard" data-i="${i}">
      <div class="row between"><b>${i + 1}.</b>${items.length > 1 ? `<button class="ibtn sm" data-del="${i}">${I.trash}</button>` : ''}</div>
      <input class="inp" data-k="d" placeholder="${L('सामान का नाम', 'Item description')}" value="${esc(it.d)}">
      <div class="grid3"><label class="fl">${L('मात्रा', 'Qty')}<input data-k="q" type="number" inputmode="decimal" value="${it.q}"></label>
      <label class="fl">${L('इकाई', 'Unit')}<input data-k="unit" placeholder="kg/bag" value="${esc(it.unit)}"></label>
      <label class="fl">${L('रेट ₹', 'Rate ₹')}<input data-k="r" type="number" inputmode="decimal" value="${it.r || ''}"></label>
      <label class="fl">HSN<input data-k="hsn" inputmode="numeric" value="${esc(it.hsn)}"></label>
      <label class="fl">GST %<select data-k="g">${[0, 5, 12, 18, 28].map(g => `<option ${+it.g === g ? 'selected' : ''}>${g}</option>`).join('')}</select></label>
      <label class="fl">${L('रक़म', 'Amount')}<output>${money((+it.q || 0) * (+it.r || 0))}</output></label></div></div>`).join('');
    renderTot();
  };
  const renderTot = () => { const c = calc(); $('.totals', s).innerHTML = `<div class="row between"><span>${L('कुल', 'Subtotal')}</span><b>${money(c.sub)}</b></div>
    ${c.gst && c.type !== 'BILL OF SUPPLY' ? `<div class="row between"><span>GST</span><b>${money(c.tax)}</b></div>` : ''}<div class="row between big"><span>${L('कुल देय', 'Grand total')}</span><b>${money(c.grand)}</b></div><small class="muted">${inWords(c.grand)}</small>`; };
  s.addEventListener('input', e => { const k = e.target.dataset.k; if (!k) return renderTot(); const i = +e.target.closest('.icard').dataset.i; items[i][k] = e.target.value;
    $('output', e.target.closest('.icard')).textContent = money((+items[i].q || 0) * (+items[i].r || 0)); renderTot(); });
  s.addEventListener('change', e => { if (e.target.dataset.k === 'g') { items[+e.target.closest('.icard').dataset.i].g = e.target.value; renderTot(); } if (e.target.id === 'ig') renderTot(); });
  s.addEventListener('click', async e => {
    const sg = e.target.closest('#ty button'); if (sg) { $$('#ty button', s).forEach(x => x.setAttribute('aria-pressed', x === sg)); renderTot(); }
    const dl = e.target.closest('[data-del]'); if (dl) { items.splice(+dl.dataset.del, 1); renderItems(); }
    const bb = e.target.closest('[data-b]')?.dataset.b;
    if (bb === 'add') { items.push({ d: '', hsn: items[items.length - 1].hsn, q: 1, unit: items[items.length - 1].unit, r: 0, g: items[items.length - 1].g }); renderItems(); }
    if (bb === 'switch') { list = await bizList(); const v = await choose(L('फ़र्म चुनें', 'Choose business'), [...list.map(b => [b.id, 'invoice', b.name, b.gst]), ['edit', 'edit', L('इस फ़र्म की जानकारी बदलें', 'Edit this business')], ['new', 'plus', L('नई फ़र्म जोड़ें', 'Add a business')]]);
      if (!v) return; if (v === 'new' || v === 'edit') { const nb = await bizDialog(v === 'edit' ? biz : {}); if (!nb) return; list = list.filter(b => b.id !== nb.id).concat(nb); await kvSet('biz', list); biz = nb; } else biz = list.find(b => b.id === v); showBiz(); }
  });
  s.go.onclick = async () => {
    const cust = { name: $('#cn', s).value.trim(), addr: $('#ca', s).value.trim(), gst: $('#cg', s).value.trim().toUpperCase(), phone: $('#cp', s).value.trim() };
    if (!cust.name) { $('#cn', s).focus(); return toast(L('ग्राहक का नाम डालें', 'Enter customer name')); }
    const rows = items.filter(it => it.d.trim() && +it.q && +it.r); if (!rows.length) return toast(L('कम से कम एक सामान पूरा भरें', 'Fill at least one item'));
    let sign = null, stamp = null;
    if ($('#ss', s).checked) { sign = await pickSaved('sign'); stamp = await pickSaved('stamp'); }
    const b = busy(L('बिल बन रहा है…', 'Making bill…'));
    try {
      const c = calc(); const no = $('#in', s).value.trim(), date = $('#id', s).value;
      const bytes = await buildPdf({ biz, cust, rows, c, no, date, sign, stamp });
      if (/^\d+$/.test(no)) { biz.next = +no + 1; list = (await bizList()).map(x => x.id === biz.id ? biz : x); await kvSet('biz', list); }
      const label = c.type === 'QUOTATION' ? 'Quotation' : 'Bill';
      const meta = await addToLibrary(bytes, `${label} ${no} ${cust.name}`, { folder: L('बिल', 'Bills') }); b.done(); s.close(); resultSheet(meta);
    } catch (err) { b.done(); toast(String(err?.message || err), 5000); }
  };
  showBiz(); renderItems();
}

async function buildPdf({ biz, cust, rows, c, no, date, sign, stamp }) {
  const pdf = await PDFDocument.create(); pdf.registerFontkit(fontkit);
  const fetchB = async u => new Uint8Array(await (await fetch(u)).arrayBuffer());
  const R = await pdf.embedFont(await fetchB('./fonts/MuktaLatin-Regular.ttf'), { subset: false }), B = await pdf.embedFont(await fetchB('./fonts/MuktaLatin-Bold.ttf'), { subset: false });
  const W = 595.28, H = 841.89, M = 36, ink = rgb(.08, .12, .1), grey = rgb(.42, .47, .45), line = rgb(.78, .82, .8), accent = rgb(.04, .48, .33);
  let page = pdf.addPage([W, H]);
  const imgCache = new Map();
  async function txt(s, x, y, { size = 10, font = R, color = ink, align = 'left', maxW } = {}) {
    s = String(s ?? ''); if (!s) return 0;
    if (deva(s)) { const key = s + size; let im = imgCache.get(key); if (!im) { const tc = textCanvas(s, { size: size * 4, color: '#14201b', weight: font === B ? 800 : 500 }); im = await pdf.embedPng(await canvasBytes(tc, 'image/png')); im.ar = tc.width / tc.height; imgCache.set(key, im); }
      let h = size * 1.32, w = h * im.ar; if (maxW && w > maxW) { w = maxW; h = w / im.ar; } const xx = align === 'right' ? x - w : align === 'center' ? x - w / 2 : x; page.drawImage(im, { x: xx, y: y - size * .32, width: w, height: h }); return w; }
    let w = font.widthOfTextAtSize(s, size); if (maxW && w > maxW) { while (s.length > 1 && font.widthOfTextAtSize(s + '…', size) > maxW) s = s.slice(0, -1); s += '…'; w = font.widthOfTextAtSize(s, size); }
    page.drawText(s, { x: align === 'right' ? x - w : align === 'center' ? x - w / 2 : x, y, size, font, color }); return w;
  }
  const wrapLines = (s, size, maxW, font = R) => { if (deva(s)) return String(s).split('\n'); const out = []; for (const para of String(s).split('\n')) { let cur = ''; for (const w of para.split(' ')) { const t = cur ? cur + ' ' + w : w; if (font.widthOfTextAtSize(t, size) > maxW && cur) { out.push(cur); cur = w; } else cur = t; } out.push(cur); } return out; };
  // header
  page.drawRectangle({ x: 0, y: H - 6, width: W, height: 6, color: accent });
  let y = H - M - 10;
  await txt(biz.name, M, y, { size: 18, font: B });
  await txt(c.type, W - M, y, { size: 14, font: B, color: accent, align: 'right' });
  y -= 16; let ly = y;
  for (const l of wrapLines(biz.addr || '', 9, 300)) { await txt(l, M, ly, { size: 9, color: grey }); ly -= 12; }
  const meta = [biz.phone && 'Ph: ' + biz.phone, biz.gst && 'GSTIN: ' + biz.gst, biz.state && 'State: ' + biz.state].filter(Boolean);
  for (const m of meta) { await txt(m, M, ly, { size: 9, color: grey }); ly -= 12; }
  await txt(`No. ${no}`, W - M, y, { size: 10, font: B, align: 'right' });
  const d = date ? new Date(date + 'T00:00').toLocaleDateString('en-GB') : '';
  await txt(`Date: ${d}`, W - M, y - 13, { size: 10, align: 'right' });
  y = Math.min(ly, y - 26) - 8;
  page.drawLine({ start: { x: M, y }, end: { x: W - M, y }, thickness: .8, color: line }); y -= 16;
  await txt(c.type === 'QUOTATION' ? 'Quotation for' : 'Bill to', M, y, { size: 9, color: grey }); y -= 14;
  await txt(cust.name, M, y, { size: 12, font: B }); y -= 13;
  for (const l of wrapLines(cust.addr, 9, 320)) { if (!l) continue; await txt(l, M, y, { size: 9, color: grey }); y -= 12; }
  const cm = [cust.phone && 'Ph: ' + cust.phone, cust.gst && 'GSTIN: ' + cust.gst].filter(Boolean).join('    '); if (cm) { await txt(cm, M, y, { size: 9, color: grey }); y -= 12; }
  y -= 10;
  // table
  const showGst = c.type !== 'BILL OF SUPPLY';
  const cols = showGst ? [['#', 20, 'left'], ['Description', 0, 'left'], ['HSN', 46, 'left'], ['Qty', 52, 'right'], ['Rate', 62, 'right'], ['GST', 34, 'right'], ['Amount', 76, 'right']]
    : [['#', 20, 'left'], ['Description', 0, 'left'], ['HSN', 50, 'left'], ['Qty', 60, 'right'], ['Rate', 70, 'right'], ['Amount', 84, 'right']];
  const fixed = cols.reduce((a, c2) => a + c2[1], 0); cols[1][1] = W - 2 * M - fixed;
  const head = async () => { page.drawRectangle({ x: M, y: y - 6, width: W - 2 * M, height: 20, color: rgb(.93, .96, .94) }); let x = M + 4;
    for (const [l, w, a] of cols) { await txt(l, a === 'right' ? x + w - 8 : x, y, { size: 9, font: B, align: a }); x += w; } y -= 22; };
  await head();
  for (const [i, it] of rows.entries()) {
    if (y < 220) { page = pdf.addPage([W, H]); y = H - M - 10; await head(); }
    const amt = (+it.q) * (+it.r); let x = M + 4;
    const vals = showGst ? [i + 1, it.d, it.hsn, `${+it.q} ${it.unit || ''}`.trim(), (+it.r).toLocaleString('en-IN', { minimumFractionDigits: 2 }), `${it.g}%`, amt.toLocaleString('en-IN', { minimumFractionDigits: 2 })]
      : [i + 1, it.d, it.hsn, `${+it.q} ${it.unit || ''}`.trim(), (+it.r).toLocaleString('en-IN', { minimumFractionDigits: 2 }), amt.toLocaleString('en-IN', { minimumFractionDigits: 2 })];
    for (const [k, [, w, a]] of cols.entries()) { await txt(vals[k], a === 'right' ? x + w - 8 : x, y, { size: 9.5, align: a, maxW: w - 10 }); x += w; }
    y -= 8; page.drawLine({ start: { x: M, y }, end: { x: W - M, y }, thickness: .5, color: line }); y -= 13;
  }
  // totals
  y -= 4; const tx = W - M - 210;
  const trow = async (l, v, bold) => { await txt(l, tx, y, { size: bold ? 11 : 10, font: bold ? B : R }); await txt(v, W - M - 4, y, { size: bold ? 11 : 10, font: bold ? B : R, align: 'right' }); y -= bold ? 18 : 15; };
  await trow('Taxable value', money(c.sub));
  if (showGst) { if (c.igst) await trow('IGST', money(c.tax)); else { await trow('CGST', money(c.tax / 2)); await trow('SGST', money(c.tax / 2)); } }
  if (Math.abs(c.round) > .001) await trow('Round off', (c.round > 0 ? '+' : '') + c.round.toFixed(2));
  y -= 6; page.drawRectangle({ x: tx - 6, y: y - 6, width: W - M - tx + 6, height: 22, color: rgb(.04, .48, .33) });
  await txt('Grand total', tx, y, { size: 11.5, font: B, color: rgb(1, 1, 1) }); await txt(money(c.grand), W - M - 4, y, { size: 11.5, font: B, color: rgb(1, 1, 1), align: 'right' }); y -= 28;
  await txt('Amount in words', M, y, { size: 9, color: grey }); y -= 13;
  for (const l of wrapLines(inWords(c.grand), 10, W - 2 * M, B)) { await txt(l, M, y, { size: 10, font: B }); y -= 13; }
  y -= 10;
  // bank + terms (left), sign (right)
  let by = y;
  if (biz.bank) { await txt('Bank details', M, by, { size: 9, color: grey }); by -= 12; for (const l of wrapLines(biz.bank, 9, 280)) { await txt(l, M, by, { size: 9 }); by -= 12; } by -= 6; }
  if (biz.terms) { await txt('Terms', M, by, { size: 9, color: grey }); by -= 12; for (const l of wrapLines(biz.terms, 8.5, 280)) { await txt(l, M, by, { size: 8.5, color: grey }); by -= 11; } }
  const sx = W - M - 170; let sy = y;
  await txt('For ' + biz.name, W - M, sy, { size: 9.5, font: B, align: 'right', maxW: 200 }); sy -= 70;
  const put = async (src, x, yy, maxW, maxH) => { if (!src) return; const im = await pdf.embedPng(new Uint8Array(await (await fetch(src)).arrayBuffer())); const k = Math.min(maxW / im.width, maxH / im.height); page.drawImage(im, { x, y: yy, width: im.width * k, height: im.height * k, opacity: .95 }); };
  await put(stamp, sx, sy, 100, 62); await put(sign, sx + 70, sy + 4, 100, 48);
  await txt('Authorised Signatory', W - M, sy - 12, { size: 9, color: grey, align: 'right' });
  // footer
  pdf.getPages().forEach(p => p.drawText('Made with Panna', { x: M, y: 18, size: 7, font: R, color: rgb(.7, .74, .72) }));
  return pdf.save();
}
