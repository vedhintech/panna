import { PDFDocument, degrees } from 'pdf-lib';
import { L } from './i18n.js';
import { I } from './icons.js';
import { $, $$, esc, screen, toast, busy, tap, choose, dialog, confirmBox, sheet, baseName } from './ui.js';
import { loadPdf } from './pdf.js';
import { addToLibrary, textCanvas, takePhoto, pickPhotos, blobToCanvas, uid } from './lib.js';
import { knockoutWhite, trim } from './imgproc.js';
import { kvGet, kvSet } from './db.js';
import { resultSheet } from './result.js';
import { ocrCanvas } from './ocr.js';

const COLORS = ['#111111', '#1446A0', '#C0221B', '#0B7A55'];
const MARKS = ['#F7D21E', '#7CE3A8', '#FF9EC3', '#8FD3FF'];
const SIZES = [[.018, 'S'], [.026, 'M'], [.036, 'L'], [.05, 'XL']];

/* draws a displayed-orientation overlay image onto a pdf-lib page */
export function placeOverlay(page, img, rot) {
  const { width, height } = page.getSize(); const box = page.getCropBox();
  const x0 = box.x, y0 = box.y, w = box.width ?? width, hgt = box.height ?? height;
  rot = ((rot % 360) + 360) % 360;
  if (rot === 0) page.drawImage(img, { x: x0, y: y0, width: w, height: hgt });
  if (rot === 90) page.drawImage(img, { x: x0 + w, y: y0, width: hgt, height: w, rotate: degrees(90) });
  if (rot === 180) page.drawImage(img, { x: x0 + w, y: y0 + hgt, width: w, height: hgt, rotate: degrees(180) });
  if (rot === 270) page.drawImage(img, { x: x0, y: y0 + hgt, width: hgt, height: w, rotate: degrees(270) });
}

const imgCache = new Map();
const loadImg = src => imgCache.get(src) || (imgCache.set(src, new Promise(r => { const i = new Image(); i.onload = () => r(i); i.src = src; })), imgCache.get(src));

export async function renderOverlay(objs, W, H, images) {
  const c = document.createElement('canvas'); c.width = Math.round(W); c.height = Math.round(H);
  const x = c.getContext('2d');
  for (const o of objs) {
    if (o.type === 'white' || o.type === 'redact') { x.fillStyle = o.type === 'white' ? (o.fill || '#fff') : '#000'; x.fillRect(o.x * W, o.y * H, o.w * W, o.h * H); }
    else if (o.type === 'ink') {
      x.save(); x.globalAlpha = o.alpha || 1; x.strokeStyle = o.color; x.lineWidth = o.lw * W; x.lineCap = 'round'; x.lineJoin = 'round';
      if (o.alpha < 1) x.globalCompositeOperation = 'multiply';
      x.beginPath(); o.pts.forEach(([px, py], i) => i ? x.lineTo(px * W, py * H) : x.moveTo(px * W, py * H)); x.stroke(); x.restore();
    } else if (o.type === 'img') {
      const im = await loadImg(images[o.img]);
      const cx = (o.x + o.w / 2) * W, cy = (o.y + o.h / 2) * H;
      x.save(); x.translate(cx, cy); x.rotate((o.rotation || 0) * Math.PI / 180);
      x.drawImage(im, -o.w * W / 2, -o.h * H / 2, o.w * W, o.h * H); x.restore();
    }
    else if (o.type === 'text') {
      const tc = textCanvas(o.text, { size: o.fs * W, color: o.color, weight: o.bold ? 800 : 500 });
      x.drawImage(tc, o.x * W, o.y * H);
    }
  }
  return c;
}

/* ---------- signature & stamp library ---------- */
async function signPad() {
  return new Promise(res => {
    const s = screen(L('अपना साइन करें', 'Draw your signature'), { action: L('सेव करें', 'Save'), onClose: () => res(null) });
    s.body.innerHTML = `<p class="hint">${L('नीचे सफ़ेद जगह पर उँगली से साइन करें।', 'Sign with your finger in the white area.')}</p>
      <canvas class="pad"></canvas><div class="row2"><div class="swatches">${COLORS.slice(0, 3).map((c, i) => `<button class="sw" data-c="${c}" style="--c:${c}" aria-pressed="${i === 1}"></button>`).join('')}</div>
      <button class="btn ghost2" data-clear>${L('मिटाएँ', 'Clear')}</button></div>`;
    const cv = $('.pad', s); let color = COLORS[1], drawing = false, any = false;
    const fit = () => { const w = cv.clientWidth; cv.width = w * 2; cv.height = w * 2 * .55; cv.style.height = w * .55 + 'px'; }; fit();
    const ctx = cv.getContext('2d');
    const pt = e => { const r = cv.getBoundingClientRect(); return [(e.clientX - r.left) * 2, (e.clientY - r.top) * 2]; };
    cv.addEventListener('pointerdown', e => { drawing = true; any = true; cv.setPointerCapture(e.pointerId); ctx.strokeStyle = color; ctx.lineWidth = 6; ctx.lineCap = ctx.lineJoin = 'round'; ctx.beginPath(); ctx.moveTo(...pt(e)); });
    cv.addEventListener('pointermove', e => { if (!drawing) return; for (const ev of e.getCoalescedEvents?.() || [e]) ctx.lineTo(...pt(ev)); ctx.stroke(); });
    cv.addEventListener('pointerup', () => drawing = false);
    s.addEventListener('click', e => { const c = e.target.closest('[data-c]'); if (c) { color = c.dataset.c; $$('.sw', s).forEach(b => b.setAttribute('aria-pressed', b === c)); }
      if (e.target.closest('[data-clear]')) { ctx.clearRect(0, 0, cv.width, cv.height); any = false; } });
    s.go.onclick = () => { if (!any) return toast(L('पहले साइन करें', 'Sign first')); const out = trim(cv, 8).toDataURL('image/png'); res(out); s.close(); };
  });
}

async function textStamp() {
  return new Promise(res => {
    const w = dialog(`<h3>${L('मोहर बनाएँ', 'Make a stamp')}</h3>
      <input id="s1" placeholder="${L('फ़र्म का नाम, जैसे Shree Narayan Charcoal', 'Firm name')}">
      <input id="s2" placeholder="${L('नीचे की लाइन, जैसे Proprietor', 'Second line, e.g. Proprietor')}">
      <div class="swatches">${['#1446A0', '#6B2FA0', '#C0221B'].map((c, i) => `<button type="button" class="sw" data-c="${c}" style="--c:${c}" aria-pressed="${!i}"></button>`).join('')}</div>`,
      L('बनाएँ', 'Create'), d => {
        const a = $('#s1', d).value.trim(), b = $('#s2', d).value.trim(); if (!a) return false;
        const col = $('.sw[aria-pressed=true]', d).dataset.c;
        const t1 = textCanvas(a, { size: 64, color: col, weight: 800 }), t2 = b ? textCanvas(b, { size: 44, color: col, weight: 600 }) : null;
        const W = Math.max(t1.width, t2?.width || 0) + 80, H = t1.height + (t2 ? t2.height + 10 : 0) + 60;
        const c = document.createElement('canvas'); c.width = W; c.height = H; const x = c.getContext('2d');
        x.strokeStyle = col; x.lineWidth = 6; x.strokeRect(6, 6, W - 12, H - 12); x.lineWidth = 2; x.strokeRect(16, 16, W - 32, H - 32);
        x.drawImage(t1, (W - t1.width) / 2, 30); if (t2) x.drawImage(t2, (W - t2.width) / 2, 30 + t1.height + 6);
        res(c.toDataURL('image/png')); return true;
      });
    w.addEventListener('click', e => { const c = e.target.closest('.sw'); if (c) $$('.sw', w).forEach(b => b.setAttribute('aria-pressed', b === c)); });
    w.oncancel = () => res(null);
  });
}

async function fromPhoto(tint) {
  const src = await choose(L('फ़ोटो कहाँ से?', 'Photo from'), [['cam', 'scan', L('कैमरा', 'Camera')], ['gal', 'image', L('गैलरी', 'Gallery')]]); if (!src) return null;
  const blobs = src === 'cam' ? await takePhoto() : await pickPhotos(false); if (!blobs.length) return null;
  const c = await blobToCanvas(blobs[0], 1400); return knockoutWhite(c, tint).toDataURL('image/png');
}

export async function pickSaved(kind) {
  const key = kind === 'sign' ? 'signs' : 'stamps'; const list = (await kvGet(key)) || [];
  return new Promise(res => {
    const p = sheet(`<p class="shead">${kind === 'sign' ? L('साइन चुनें', 'Choose signature') : L('मोहर चुनें', 'Choose stamp')}</p>
      <div class="savedgrid">${list.map((src, i) => `<div class="saved" data-s="use:${i}" data-keep="1"><img src="${src}" alt=""><button class="tdel" data-s="del:${i}" data-keep="1">${I.close}</button></div>`).join('')}</div>
      ${kind === 'sign' ? `<button class="sitem" data-s="new">${I.sign}<span>${L('नया साइन बनाएँ', 'Draw a new signature')}</span></button>
        <button class="sitem" data-s="photo">${I.image}<span>${L('काग़ज़ पर किए साइन की फ़ोटो से', 'From a photo of your signature')}</span></button>`
      : `<button class="sitem" data-s="new">${I.stamp}<span>${L('नाम लिखकर मोहर बनाएँ', 'Make a stamp from text')}</span></button>
        <button class="sitem" data-s="photo">${I.image}<span>${L('असली मोहर की फ़ोटो से', 'From a photo of your rubber stamp')}</span></button>`}`, async v => {
        if (v.startsWith('use:')) { p.close(); res(list[+v.slice(4)]); return; }
        if (v.startsWith('del:')) { if (!await confirmBox(L('हटाएँ?', 'Delete?'), '', L('हटाएँ', 'Delete'), true)) return; list.splice(+v.slice(4), 1); await kvSet(key, list); p.close(); res(await pickSaved(kind)); return; }
        let src = null;
        if (v === 'new') src = kind === 'sign' ? await signPad() : await textStamp();
        if (v === 'photo') src = await fromPhoto(kind === 'sign' ? '#1446A0' : null);
        if (src) { list.unshift(src); await kvSet(key, list.slice(0, 12)); }
        res(src);
      });
    p.oncancel = () => res(null);
  });
}

function textDialog(o = {}) {
  return new Promise(res => {
    const w = dialog(`<h3>${o.text ? L('टेक्स्ट बदलें', 'Edit text') : L('टेक्स्ट लिखें', 'Add text')}</h3>
      <textarea id="tx" rows="3" placeholder="${L('हिंदी या English में लिखें', 'Type in Hindi or English')}">${esc(o.text || '')}</textarea>
      <div class="swatches">${COLORS.map(c => `<button type="button" class="sw" data-c="${c}" style="--c:${c}" aria-pressed="${(o.color || COLORS[0]) === c}"></button>`).join('')}</div>
      <div class="seg small">${SIZES.map(([v, l]) => `<button type="button" data-z="${v}" aria-pressed="${(o.fs || SIZES[1][0]) === v}">${l}</button>`).join('')}</div>
      <label class="tog"><input type="checkbox" id="tb" ${o.bold ? 'checked' : ''}><span>${L('मोटे अक्षर', 'Bold')}</span></label>`,
      L('लगाएँ', 'Place'), d => { const text = $('#tx', d).value.replace(/\s+$/, ''); if (!text) return false;
        res({ text, color: $('.sw[aria-pressed=true]', d).dataset.c, fs: +$('[data-z][aria-pressed=true]', d).dataset.z, bold: $('#tb', d).checked }); return true; },
      d => $('#tx', d).focus());
    w.addEventListener('click', e => { const c = e.target.closest('.sw'); if (c) $$('.sw', w).forEach(b => b.setAttribute('aria-pressed', b === c));
      const z = e.target.closest('[data-z]'); if (z) $$('[data-z]', w).forEach(b => b.setAttribute('aria-pressed', b === z)); });
    w.oncancel = () => res(null);
  });
}

/* ---------- editor screen ---------- */
export async function openEditor(file, { tool = 'hand' } = {}) {
  const b = busy(L('एडिटर खोल रहे हैं…', 'Opening editor…'));
  let doc; try { doc = await loadPdf(file.bytes.slice(0)); } catch { b.done(); return toast(L('यह PDF एडिट नहीं हो सकती', 'This PDF cannot be edited')); }
  b.done();
  let objs = [], images = {}, hist = [], fut = [], sel = null, mode = tool, color = COLORS[0], mark = MARKS[0], dirty = false;
  const ocrCache = new Map(); let disposed = false, io = null; const renderTasks = new Set();
  const s = screen(L('एडिट: ', 'Edit: ') + baseName(file.name), { cls: 'editor', onClose: () => { disposed = true; io?.disconnect(); for (const task of renderTasks) task.cancel?.(); renderTasks.clear(); for (const task of ocrCache.values()) task.then(v => { v.canvas.width = 0; v.canvas.height = 0; }).catch(() => {}); doc.destroy(); } });
  s.right.innerHTML = `<button class="ibtn" data-e="undo" aria-label="Undo">${I.undo}</button><button class="ibtn" data-e="redo" aria-label="Redo">${I.redo}</button>
    <button class="btn small" data-e="save">${L('सेव', 'Save')}</button>`;
  const tools = [['hand', 'hand', L('चलाएँ', 'Move')], ['text', 'type', L('टेक्स्ट', 'Text')], ['sign', 'sign', L('साइन', 'Sign')], ['stamp', 'stamp', L('मोहर', 'Stamp')],
    ['image', 'image', L('फ़ोटो', 'Photo')], ['ocrEdit', 'ocr', L('OCR एडिट', 'OCR Edit')], ['pen', 'pen', L('पेन', 'Pen')], ['marker', 'marker', L('हाइलाइट', 'Highlight')], ['white', 'box', L('मिटाएँ', 'Whiteout')], ['redact', 'redact', L('छुपाएँ', 'Redact')]];
  s.body.innerHTML = `<div class="epages"></div>`;
  s.insertAdjacentHTML('beforeend', `<div class="etray">
    <div class="eopts" hidden></div>
    <div class="etools">${tools.map(([k, ic, l]) => `<button data-tool="${k}">${I[ic]}<span>${l}</span></button>`).join('')}</div></div>`);
  const wrap = $('.epages', s), N = doc.numPages, sizes = [];
  for (let i = 1; i <= N; i++) { const v = (await doc.getPage(i)).getViewport({ scale: 1 }); sizes.push([v.width, v.height]); }
  wrap.innerHTML = sizes.map(([w, h], i) => `<div class="epage" data-p="${i}" style="aspect-ratio:${w}/${h}"><canvas></canvas><svg class="eink" viewBox="0 0 1000 ${1000 * h / w}" preserveAspectRatio="none"></svg><div class="eobjs"></div><span class="pnum">${i + 1}</span></div>`).join('');
  const rendered = new Set();
  io = new IntersectionObserver(es => es.forEach(async e => {
    const i = +e.target.dataset.p; if (!e.isIntersecting || rendered.has(i) || disposed) return; rendered.add(i);
    let pg, c, task;
    try {
      pg = await doc.getPage(i + 1); if (disposed) return;
      const cw = e.target.clientWidth * Math.min(2, devicePixelRatio || 1);
      const vp = pg.getViewport({ scale: cw / sizes[i][0] }); c = $('canvas', e.target); c.width = vp.width; c.height = vp.height;
      task = pg.render({ canvasContext: c.getContext('2d', { alpha: false }), viewport: vp }); renderTasks.add(task);
      await task.promise; if (!disposed) e.target.classList.add('done');
    } catch (err) { if (!disposed && err?.name !== 'RenderingCancelledException') { rendered.delete(i); toast(L('पेज रेंडर नहीं हुआ: ', 'Page render failed: ') + (err?.message || ''), 3500); } }
    finally { if (task) renderTasks.delete(task); pg?.cleanup?.(); if (disposed && c) { c.width = 0; c.height = 0; } }
  }), { root: s.body, rootMargin: '100% 0px' });
  $$('.epage', s).forEach(p => io.observe(p));

  const snap = () => { hist.push(JSON.stringify(objs)); if (hist.length > 60) hist.shift(); fut = []; dirty = true; };
  function draw(pageIdx) {
    const pages = pageIdx == null ? [...Array(N).keys()] : [pageIdx];
    for (const i of pages) {
      const el = $(`.epage[data-p="${i}"]`, s); const ar = sizes[i][1] / sizes[i][0];
      $('.eink', el).innerHTML = objs.filter(o => o.page === i && o.type === 'ink').map(o =>
        `<polyline points="${o.pts.map(([x, y]) => `${x * 1000},${y * 1000 * ar}`).join(' ')}" fill="none" stroke="${o.color}" stroke-width="${o.lw * 1000}" stroke-linecap="round" stroke-linejoin="round" ${o.alpha < 1 ? `opacity="${o.alpha}" style="mix-blend-mode:multiply"` : ''}/>`).join('');
      const pw = el.clientWidth;
      $('.eobjs', el).innerHTML = objs.filter(o => o.page === i && o.type !== 'ink').map(o => {
        const st = `left:${o.x * 100}%;top:${o.y * 100}%;${o.w ? `width:${o.w * 100}%;` : ''}${o.h && o.type !== 'text' ? `height:${o.h * 100}%;` : ''}`;
        const selc = sel === o.id ? ' sel' : '';
        const ctl = sel === o.id ? `<b class="odel" data-od>${I.close}</b>${o.type === 'text' ? `<b class="oedit" data-oe>${I.edit}</b>` : ''}<b class="ores" data-or></b>${o.type === 'img' ? '<b class="orot" data-rot title="Rotate">↻</b>' : ''}` : '';
        if (o.type === 'text') return `<div class="obj otext${selc}" data-o="${o.id}" style="${st}font-size:${o.fs * pw}px;color:${o.color};font-weight:${o.bold ? 800 : 500}">${esc(o.text)}${ctl}</div>`;
        if (o.type === 'img') return `<div class="obj${selc}" data-o="${o.id}" style="${st}transform:rotate(${o.rotation || 0}deg)"><img src="${images[o.img]}" alt="" draggable="false">${ctl}</div>`;
        return `<div class="obj orect ${o.type}${selc}" data-o="${o.id}" style="${st}${o.type === 'white' && o.fill ? `background:${o.fill};` : ''}">${ctl}</div>`;
      }).join('');
    }
  }
  function setMode(m) {
    mode = m; sel = null; draw();
    $$('[data-tool]', s).forEach(b => b.setAttribute('aria-pressed', b.dataset.tool === m));
    s.dataset.mode = m;
    const opts = $('.eopts', s);
    if (m === 'pen' || m === 'text') { opts.hidden = false; opts.innerHTML = `<div class="swatches">${COLORS.map(c => `<button class="sw" data-col="${c}" style="--c:${c}" aria-pressed="${c === color}"></button>`).join('')}</div><span class="muted">${m === 'pen' ? L('उँगली से लिखें', 'Draw with your finger') : L('पेज पर जहाँ लिखना है वहाँ टैप करें', 'Tap where the text should go')}</span>`; }
    else if (m === 'marker') { opts.hidden = false; opts.innerHTML = `<div class="swatches">${MARKS.map(c => `<button class="sw" data-mk="${c}" style="--c:${c}" aria-pressed="${c === mark}"></button>`).join('')}</div><span class="muted">${L('शब्दों पर उँगली फेरें', 'Swipe over the words')}</span>`; }
    else if (m === 'ocrEdit') { opts.hidden = false; opts.innerHTML = `<span class="muted">${L('पहले पेज पर OCR होगा। फिर जिस शब्द को बदलना है उस पर टैप करें।', 'The page will be OCR-scanned. Tap a recognized word to replace it.')}</span>`; }
    else if (m === 'white' || m === 'redact') { opts.hidden = false; opts.innerHTML = `<span class="muted">${m === 'white' ? L('जो मिटाना है उस पर उँगली से डिब्बा खींचें। फिर ऊपर नया टेक्स्ट लिख सकते हैं।', 'Drag a box over what to erase. You can write new text on top.') : L('जो छुपाना है उस पर डिब्बा खींचें। सेव करने पर वह पेज फ़ोटो बन जाएगा ताकि नीचे का टेक्स्ट सच में हट जाए।', 'Drag over what to hide. On save that page becomes an image so the text is truly removed.')}</span>`; }
    else opts.hidden = true;
  }
  async function addImg(src, i) {
    if (!src) return; const im = await loadImg(src); const key = uid(); images[key] = src;
    const [pw, ph] = sizes[i]; const w = .32, h = w * pw / ph * im.height / im.width;
    snap(); const o = { id: uid(), type: 'img', page: i, img: key, x: .5 - w / 2, y: Math.max(.02, .5 - h / 2), w, h };
    objs.push(o); sel = o.id; mode = 'hand'; setMode('hand'); sel = o.id; draw(i);
    toast(L('खींचें: जगह बदलें · कोना: आकार बदलें · ऊपर ↻: घुमाएँ', 'Drag to move · corner to resize · top ↻ to rotate'));
  }
  const visiblePage = () => { const top = s.body.scrollTop + s.body.clientHeight / 2; let best = 0; $$('.epage', s).forEach((el, i) => { if (el.offsetTop <= top) best = i; }); return best; };

  // pointer interactions
  let act = null;
  wrap.addEventListener('pointerdown', async e => {
    const pageEl = e.target.closest('.epage'); if (!pageEl) return;
    const i = +pageEl.dataset.p, r = pageEl.getBoundingClientRect();
    const fx = (e.clientX - r.left) / r.width, fy = (e.clientY - r.top) / r.height;
    const objEl = e.target.closest('.obj');
    if (e.target.closest('[data-od]')) { snap(); objs = objs.filter(o => o.id !== sel); sel = null; draw(i); return; }
    if (e.target.closest('[data-oe]')) { const o = objs.find(x => x.id === sel); const v = await textDialog(o); if (v) { snap(); Object.assign(o, v); draw(i); } return; }
    if (e.target.closest('[data-rot]')) { const o = objs.find(x => x.id === sel); const cx = r.left + (o.x + o.w / 2) * r.width, cy = r.top + (o.y + o.h / 2) * r.height; act = { kind: 'rotate', o, r, cx, cy, start: Math.atan2(e.clientY - cy, e.clientX - cx), rotation0: o.rotation || 0, moved: false }; pageEl.setPointerCapture(e.pointerId); e.preventDefault(); return; }
    if (e.target.closest('[data-or]')) { const o = objs.find(x => x.id === sel); act = { kind: 'resize', o, r, sx: e.clientX, sy: e.clientY, w0: o.w || 0, h0: o.h || 0, fs0: o.fs, aspect: (o.w && o.h) ? o.h / o.w : 1, moved: false }; pageEl.setPointerCapture(e.pointerId); e.preventDefault(); return; }
    if (objEl && mode !== 'pen' && mode !== 'marker') {
      const o = objs.find(x => x.id === objEl.dataset.o); sel = o.id; draw(i);
      act = { kind: 'move', o, r, sx: e.clientX, sy: e.clientY, x0: o.x, y0: o.y, moved: false }; pageEl.setPointerCapture(e.pointerId); e.preventDefault(); return;
    }
    if (sel) { sel = null; draw(i); }
    if (mode === 'pen' || mode === 'marker') {
      const o = { id: uid(), type: 'ink', page: i, pts: [[fx, fy]], color: mode === 'pen' ? color : mark, lw: mode === 'pen' ? .004 : .022, alpha: mode === 'pen' ? 1 : .45 };
      snap(); objs.push(o); act = { kind: 'ink', o, r }; pageEl.setPointerCapture(e.pointerId); e.preventDefault();
    } else if (mode === 'white' || mode === 'redact') {
      const o = { id: uid(), type: mode, page: i, x: fx, y: fy, w: 0, h: 0 }; snap(); objs.push(o);
      act = { kind: 'rect', o, r, fx, fy }; pageEl.setPointerCapture(e.pointerId); e.preventDefault();
    } else if (mode === 'ocrEdit') {
      try {
        let task = ocrCache.get(i);
        if (!task) {
          task = (async () => {
            const pg = await doc.getPage(i + 1), scale = Math.min(2.5, 2200 / sizes[i][0]);
            const vp = pg.getViewport({ scale }); const c = document.createElement('canvas'); c.width = Math.ceil(vp.width); c.height = Math.ceil(vp.height);
            const cx = c.getContext('2d', { alpha: false }); cx.fillStyle = '#fff'; cx.fillRect(0, 0, c.width, c.height);
            await pg.render({ canvasContext: cx, viewport: vp }).promise;
            const found = await ocrCanvas(c, { dpi: scale * 72 });
            return { canvas: c, words: found.words.map(w => ({ ...w, x: w.bbox.x0 / c.width, y: w.bbox.y0 / c.height, w: (w.bbox.x1 - w.bbox.x0) / c.width, h: (w.bbox.y1 - w.bbox.y0) / c.height })) };
          })();
          ocrCache.set(i, task);
        }
        const result = await task;
        const word = result.words.filter(w => fx >= w.x - .006 && fx <= w.x + w.w + .006 && fy >= w.y - .006 && fy <= w.y + w.h + .006).sort((a, b) => (a.w * a.h) - (b.w * b.h))[0];
        if (!word) { toast(L('इस जगह कोई शब्द नहीं मिला। साफ़ पेज पर शब्द के ऊपर टैप करें।', 'No recognized word here. Tap directly on a clear word.')); return; }
        const rawSize = Math.max(.012, Math.min(.06, word.h * .9));
        const fs = SIZES.reduce((best, z) => Math.abs(z[0] - rawSize) < Math.abs(best[0] - rawSize) ? z : best, SIZES[1])[0];
        const v = await textDialog({ text: word.text, color: COLORS[0], fs }); if (!v) return;
        const padX = .004, padY = .002;
        const x = Math.max(0, word.x - padX), y = Math.max(0, word.y - padY);
        // Sample just outside the glyph, not its center (which is usually dark ink).
        const rc = result.canvas.getContext('2d');
        const samples = [[word.x - .003, word.y - .003], [word.x + word.w + .003, word.y - .003], [word.x - .003, word.y + word.h + .003], [word.x + word.w + .003, word.y + word.h + .003]]
          .map(([sx, sy]) => rc.getImageData(Math.max(0, Math.min(result.canvas.width - 1, Math.round(sx * result.canvas.width))), Math.max(0, Math.min(result.canvas.height - 1, Math.round(sy * result.canvas.height))), 1, 1).data)
          .sort((a, b) => (b[0] * .299 + b[1] * .587 + b[2] * .114) - (a[0] * .299 + a[1] * .587 + a[2] * .114));
        const px = samples[0];
        const fill = `rgb(${px[0]},${px[1]},${px[2]})`;
        const textImage = textCanvas(v.text, { size: v.fs * sizes[i][0], color: v.color, weight: v.bold ? 800 : 500 });
        const coverW = Math.min(1 - x, Math.max(word.w + padX * 2, textImage.width / (result.canvas.width / sizes[i][0]) + padX * 2));
        snap();
        objs.push({ id: uid(), type: 'white', page: i, x, y, w: coverW, h: Math.min(1 - y, word.h + padY * 2), fill });
        const o = { id: uid(), type: 'text', page: i, x, y: Math.max(0, y - .001), ...v };
        objs.push(o); sel = o.id; draw(i);
      } catch (err) { ocrCache.delete(i); toast(L('OCR नहीं चल पाया: ', 'OCR failed: ') + (err?.message || err), 5000); }
    } else if (mode === 'text') {
      const v = await textDialog({ color }); if (!v) return; color = v.color;
      snap(); const o = { id: uid(), type: 'text', page: i, x: Math.min(fx, .85), y: Math.min(fy, .95), ...v }; objs.push(o); sel = o.id; draw(i);
    }
  });
  wrap.addEventListener('pointermove', e => {
    if (!act) return; const { r, o } = act; const fx = (e.clientX - r.left) / r.width, fy = (e.clientY - r.top) / r.height; act.moved = true;
    if (act.kind === 'ink') { for (const ev of e.getCoalescedEvents?.() || [e]) o.pts.push([(ev.clientX - r.left) / r.width, (ev.clientY - r.top) / r.height]); draw(o.page); }
    if (act.kind === 'rect') { o.x = Math.min(fx, act.fx); o.y = Math.min(fy, act.fy); o.w = Math.abs(fx - act.fx); o.h = Math.abs(fy - act.fy); draw(o.page); }
    if (act.kind === 'rotate') { if (!act.snapped) { snap(); act.snapped = true; } const angle = Math.atan2(e.clientY - act.cy, e.clientX - act.cx); o.rotation = Math.round((act.rotation0 + (angle - act.start) * 180 / Math.PI) * 10) / 10; draw(o.page); }
    if (act.kind === 'move') { if (!act.snapped) { snap(); act.snapped = true; } o.x = Math.max(0, Math.min(1 - (o.w || .08), act.x0 + (e.clientX - act.sx) / r.width)); o.y = Math.max(0, Math.min(1 - (o.h || .04), act.y0 + (e.clientY - act.sy) / r.height)); draw(o.page); }
    if (act.kind === 'resize') { if (!act.snapped) { snap(); act.snapped = true; }
      const dx = (e.clientX - act.sx) / r.width, dy = (e.clientY - act.sy) / r.height;
      if (o.type === 'text') { const k = Math.max(.15, 1 + dx / Math.max(.05, act.w0 || .2)); o.fs = Math.max(.008, Math.min(.12, act.fs0 * k)); }
      else if (o.type === 'img') {
        // Resize from the corner using both pointer axes and preserve the signature/photo aspect ratio.
        const baseW = Math.max(.025, act.w0 || .2);
        const delta = Math.abs(dx) >= Math.abs(dy / Math.max(.2, act.aspect)) ? dx : dy / Math.max(.2, act.aspect);
        const nw = Math.max(.035, Math.min(1 - o.x, baseW + delta));
        o.w = nw; o.h = Math.min(1 - o.y, nw * act.aspect);
      } else { o.w = Math.max(.01, Math.min(1 - o.x, act.w0 + dx)); o.h = Math.max(.005, Math.min(1 - o.y, act.h0 + dy)); }
      draw(o.page); }
  });
  const end = () => { if (act?.kind === 'rect' && (act.o.w < .008 || act.o.h < .004)) { objs = objs.filter(x => x !== act.o); hist.pop(); draw(act.o.page); }
    if (act?.kind === 'ink' && act.o.pts.length < 2) act.o.pts.push([act.o.pts[0][0] + .001, act.o.pts[0][1]]);
    act = null; };
  wrap.addEventListener('pointerup', end); wrap.addEventListener('pointercancel', end); wrap.addEventListener('lostpointercapture', end);

  s.addEventListener('click', async e => {
    const tl = e.target.closest('[data-tool]')?.dataset.tool;
    if (tl) { tap();
      if (tl === 'sign' || tl === 'stamp') return addImg(await pickSaved(tl), visiblePage());
      if (tl === 'image') { const src = await choose(L('फ़ोटो', 'Photo'), [['cam', 'scan', L('कैमरा', 'Camera')], ['gal', 'image', L('गैलरी', 'Gallery')]]); if (!src) return;
        const bl = src === 'cam' ? await takePhoto() : await pickPhotos(false); if (!bl.length) return; return addImg((await blobToCanvas(bl[0], 1600)).toDataURL('image/jpeg', .9), visiblePage()); }
      setMode(tl); return; }
    const c = e.target.closest('[data-col]'); if (c) { color = c.dataset.col; $$('[data-col]', s).forEach(b => b.setAttribute('aria-pressed', b === c)); }
    const mk = e.target.closest('[data-mk]'); if (mk) { mark = mk.dataset.mk; $$('[data-mk]', s).forEach(b => b.setAttribute('aria-pressed', b === mk)); }
    const a = e.target.closest('[data-e]')?.dataset.e; if (!a) return; tap();
    if (a === 'undo' && hist.length) { fut.push(JSON.stringify(objs)); objs = JSON.parse(hist.pop()); sel = null; draw(); }
    if (a === 'redo' && fut.length) { hist.push(JSON.stringify(objs)); objs = JSON.parse(fut.pop()); sel = null; draw(); }
    if (a === 'save') save();
  });
  const origClose = s.close;
  s.close = async () => { if (dirty && objs.length && !await confirmBox(L('बिना सेव किए बाहर जाएँ?', 'Leave without saving?'), L('आपके बदलाव हट जाएँगे।', 'Your changes will be lost.'), L('बाहर जाएँ', 'Leave'), true)) return; origClose(); };
  $('[data-x]', s).onclick = () => s.close();

  async function save() {
    if (!objs.length) return toast(L('अभी कोई बदलाव नहीं किया', 'No changes yet'));
    const bz = busy(L('सेव हो रहा है…', 'Saving…'));
    try {
      const out = await PDFDocument.load(file.bytes, { ignoreEncryption: true });
      for (let i = 0; i < N; i++) {
        const po = objs.filter(o => o.page === i); if (!po.length) continue;
        bz.set(L(`पेज ${i + 1} सेव हो रहा है…`, `Saving page ${i + 1}…`), i / N);
        const [pw, ph] = sizes[i];
        if (po.some(o => o.type === 'redact')) {
          const pg = await doc.getPage(i + 1); const sc = 200 / 72; const vp = pg.getViewport({ scale: sc });
          const c = document.createElement('canvas'); c.width = vp.width; c.height = vp.height; const x = c.getContext('2d', { alpha: false });
          x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); await pg.render({ canvasContext: x, viewport: vp }).promise;
          x.drawImage(await renderOverlay(po, c.width, c.height, images), 0, 0);
          const img = await out.embedJpg(new Uint8Array(await (await new Promise(r => c.toBlob(r, 'image/jpeg', .9))).arrayBuffer()));
          const np = out.insertPage(i, [pw, ph]); np.drawImage(img, { x: 0, y: 0, width: pw, height: ph }); out.removePage(i + 1);
        } else {
          const sc = 2.6; const ov = await renderOverlay(po, pw * sc, ph * sc, images);
          const img = await out.embedPng(new Uint8Array(await (await new Promise(r => ov.toBlob(r, 'image/png'))).arrayBuffer()));
          const page = out.getPage(i); placeOverlay(page, img, page.getRotation().angle);
        }
      }
      const bytes = await out.save();
      const meta = await addToLibrary(bytes, baseName(file.name) + L(' (एडिट)', ' (edited)'));
      bz.done(); dirty = false; origClose(); resultSheet(meta, L('असली फ़ाइल वैसी ही रखी है, यह नई कॉपी है', 'Original kept, this is a new copy'));
    } catch (err) { bz.done(); toast(L('सेव नहीं हो पाया: ', 'Could not save: ') + (err?.message || err), 5000); }
  }
  setMode(tool);
  if (tool === 'sign' || tool === 'stamp') setTimeout(async () => addImg(await pickSaved(tool), 0), 300);
}
