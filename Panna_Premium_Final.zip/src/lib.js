import * as db from './db.js';
import { loadPdf, makeThumb } from './pdf.js';
import { t } from './i18n.js';
import { I } from './icons.js';
import { native, sheet, esc, toast, $, $$, baseName } from './ui.js';
import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
import { Camera, CameraResultType, CameraSource } from '@capacitor/camera';

export const uid = () => crypto.randomUUID?.() || Date.now().toString(36) + Math.random().toString(36).slice(2);

export async function getBytes(id) { const b = await db.getBlob(id); return b ? new Uint8Array(await b.arrayBuffer()) : null; }

/* add a PDF to the library. returns meta */
export async function addToLibrary(bytes, name, extra = {}) {
  if (!/\.pdf$/i.test(name)) name += '.pdf';
  const blob = new Blob([bytes], { type: 'application/pdf' });
  const doc = await loadPdf(bytes.slice(0), extra.password);
  const meta = { id: uid(), name: await uniqueName(name), size: blob.size, pages: doc.numPages, added: Date.now(), opened: Date.now(),
    lastPage: 1, locked: !!extra.password, folder: extra.folder || '', ocr: !!extra.ocr };
  try { meta.thumb = await makeThumb(doc); } catch {}
  await db.putFile(meta, blob);
  indexText(meta.id, doc).finally(() => doc.destroy());
  return meta;
}

async function uniqueName(name) {
  const names = new Set((await db.allMeta()).filter(f => !f.deletedAt).map(f => f.name.toLowerCase()));
  if (!names.has(name.toLowerCase())) return name;
  const b = baseName(name); let i = 2; while (names.has(`${b} (${i}).pdf`.toLowerCase())) i++;
  return `${b} (${i}).pdf`;
}

export async function indexText(id, doc) {
  try {
    const pages = [];
    for (let i = 1; i <= doc.numPages; i++) {
      const page = await doc.getPage(i);
      try {
        const tc = await page.getTextContent();
        pages.push(tc.items.map(x => x.str).join(' ').replace(/\s+/g, ' ').trim());
      } finally { page.cleanup?.(); }
    }
    await db.setText(id, pages);
  } catch {}
}

/* ---------- pickers ---------- */
const phoneInput = (accept, multiple) => new Promise(res => {
  const i = document.createElement('input'); i.type = 'file'; i.accept = accept; i.multiple = !!multiple;
  i.onchange = () => res([...i.files]); i.oncancel = () => res([]);
  window.addEventListener('focus', () => setTimeout(() => { if (!i.files?.length) res([]); }, 1500), { once: true });
  i.click();
});

/** choose PDFs from library or phone -> [{id?, name, bytes}] */
export function pickPdfs({ multiple = false, title } = {}) {
  return new Promise(async res => {
    const files = await db.listFiles(); const sel = new Set();
    const p = sheet(`<p class="shead">${esc(title || t('choosePdf'))}</p>
      <button class="sitem" data-s="phone" data-keep="1">${I.files}<span>${t('fromPhone')}</span></button>
      ${files.length ? `<p class="shead small">${t('fromPanna')}</p>` : ''}
      <div class="plist">${files.map(f => `<button class="sitem prow" data-s="f:${f.id}" data-keep="1">
        <span class="pthumb">${f.thumb ? `<img src="${f.thumb}" alt="">` : I.doc}</span>
        <span>${esc(baseName(f.name))}<small>${f.pages} ${t('pages')}</small></span>${multiple ? '<i class="tick"></i>' : ''}</button>`).join('')}</div>
      ${multiple ? `<button class="btn big wide" data-s="done" data-keep="1" disabled>${t('next')}</button>` : ''}`, async (v, el) => {
        if (v === 'phone') {
          const fs = await phoneInput('application/pdf,.pdf', multiple); if (!fs.length) return;
          p.close(); res(await Promise.all(fs.map(async f => ({ name: f.name, bytes: new Uint8Array(await f.arrayBuffer()) }))));
        } else if (v.startsWith('f:')) {
          const id = v.slice(2);
          if (!multiple) { p.close(); const m = files.find(f => f.id === id); res([{ id, name: m.name, bytes: await getBytes(id), meta: m }]); return; }
          sel.has(id) ? sel.delete(id) : sel.add(id); el.classList.toggle('on', sel.has(id));
          $('[data-s=done]', p).disabled = !sel.size; $('[data-s=done]', p).textContent = `${t('next')} (${sel.size})`;
        } else if (v === 'done') {
          p.close(); const order = [...sel];
          res(await Promise.all(order.map(async id => { const m = files.find(f => f.id === id); return { id, name: m.name, bytes: await getBytes(id), meta: m }; })));
        }
      });
    p.oncancel = () => res([]);
  });
}

/** photos: from camera (one at a time) or gallery (many) -> Blob[] */
export async function takePhoto() {
  if (native) {
    try {
      const ph = await Camera.getPhoto({ source: CameraSource.Camera, resultType: CameraResultType.Uri, quality: 92, width: 2600, correctOrientation: true, saveToGallery: false });
      return [await (await fetch(ph.webPath)).blob()];
    } catch (e) { if (!/cancel/i.test(e?.message || '')) toast(t('camErr')); return []; }
  }
  return phoneInput('image/*', false);
}
export async function pickPhotos(multiple = true) {
  if (native) {
    try {
      const r = await Camera.pickImages({ quality: 92, width: 2600, correctOrientation: true, limit: multiple ? 0 : 1 });
      return Promise.all(r.photos.map(async ph => (await fetch(ph.webPath)).blob()));
    } catch { return []; }
  }
  return phoneInput('image/*', multiple);
}
export function pickAny(accept) { return phoneInput(accept, false).then(f => f[0]); }

/* ---------- output ---------- */
function toB64(bytes) {
  let s = ''; const CH = 0x8000;
  for (let i = 0; i < bytes.length; i += CH) s += String.fromCharCode.apply(null, bytes.subarray(i, i + CH));
  return btoa(s);
}
async function asBytes(x) { return x instanceof Uint8Array ? x : new Uint8Array(await x.arrayBuffer()); }
const safe = n => n.replace(/[\\/:*?"<>|]+/g, '_');

export async function saveToPhone(data, name, mime = 'application/pdf') {
  name = safe(name);
  if (!native) { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([data], { type: mime })); a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 4000); toast(t('savedTo', { p: 'Downloads' })); return; }
  try {
    const bytes = await asBytes(data instanceof Blob ? data : new Blob([data]));
    try { await Filesystem.requestPermissions(); } catch {}
    await Filesystem.writeFile({ path: 'Panna/' + name, data: toB64(bytes), directory: Directory.Documents, recursive: true });
    toast(t('savedTo', { p: 'Documents/Panna' }), 3500);
  } catch (e) { toast(t('saveErr') + ' ' + (e?.message || ''), 4000); }
}

export async function shareFile(data, name, mime = 'application/pdf') {
  name = safe(name);
  if (!native) {
    const f = new File([data], name, { type: mime });
    if (navigator.canShare?.({ files: [f] })) return navigator.share({ files: [f] }).catch(() => {});
    return saveToPhone(data, name, mime);
  }
  const bytes = await asBytes(data instanceof Blob ? data : new Blob([data]));
  const w = await Filesystem.writeFile({ path: 'share/' + name, data: toB64(bytes), directory: Directory.Cache, recursive: true });
  await Share.share({ files: [w.uri], dialogTitle: name }).catch(() => {});
}

export async function shareText(text) {
  if (native) return Share.share({ text }).catch(() => {});
  if (navigator.share) return navigator.share({ text }).catch(() => {});
  await navigator.clipboard?.writeText(text); toast(t('copied'));
}

export async function copyText(text) {
  try { await navigator.clipboard.writeText(text); }
  catch { const ta = document.createElement('textarea'); ta.value = text; document.body.append(ta); ta.select(); document.execCommand('copy'); ta.remove(); }
  toast(t('copied'));
}

/* ---------- image helpers ---------- */
export async function blobToCanvas(blob, maxSide = 2600) {
  const bmp = await createImageBitmap(blob);
  const k = Math.min(1, maxSide / Math.max(bmp.width, bmp.height));
  const c = document.createElement('canvas'); c.width = Math.round(bmp.width * k); c.height = Math.round(bmp.height * k);
  c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height); bmp.close?.();
  return c;
}
export const canvasBlob = (c, type = 'image/jpeg', q = 0.9) => new Promise(r => c.toBlob(r, type, q));
export async function canvasBytes(c, type = 'image/jpeg', q = 0.9) { return new Uint8Array(await (await canvasBlob(c, type, q)).arrayBuffer()); }

/** render text (any script incl. Hindi) to a transparent PNG canvas */
export function textCanvas(text, { size = 48, color = '#111', weight = 600, maxWidth = 0, align = 'left', lineHeight = 1.3 } = {}) {
  const c = document.createElement('canvas'); const ctx = c.getContext('2d');
  const font = `${weight} ${size}px Mukta, sans-serif`; ctx.font = font;
  let lines = String(text).split('\n');
  if (maxWidth) lines = lines.flatMap(l => { const words = l.split(' '); const out = []; let cur = '';
    for (const w of words) { const tst = cur ? cur + ' ' + w : w; if (ctx.measureText(tst).width > maxWidth && cur) { out.push(cur); cur = w; } else cur = tst; }
    out.push(cur); return out; });
  const w = Math.ceil(Math.max(1, ...lines.map(l => ctx.measureText(l).width))) + 4;
  const lh = size * lineHeight; c.width = w; c.height = Math.ceil(lh * lines.length + size * 0.2);
  ctx.font = font; ctx.fillStyle = color; ctx.textBaseline = 'top'; ctx.textAlign = align;
  lines.forEach((l, i) => ctx.fillText(l, align === 'center' ? w / 2 : align === 'right' ? w - 2 : 2, i * lh + size * 0.08));
  return c;
}
