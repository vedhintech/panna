/* lightweight document image processing (no OpenCV) */

export function detectQuad(src) {
  const S = 360, k = Math.min(1, S / Math.max(src.width, src.height));
  const w = Math.max(8, Math.round(src.width * k)), h = Math.max(8, Math.round(src.height * k));
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const ctx = c.getContext('2d', { willReadFrequently: true }); ctx.drawImage(src, 0, 0, w, h);
  const d = ctx.getImageData(0, 0, w, h).data;
  let g = new Float32Array(w * h);
  for (let i = 0; i < w * h; i++) g[i] = d[i * 4] * .299 + d[i * 4 + 1] * .587 + d[i * 4 + 2] * .114;
  g = boxBlur(boxBlur(g, w, h, 2), w, h, 2);
  // Otsu
  const hist = new Array(256).fill(0); g.forEach(v => hist[v | 0]++);
  let sum = 0; for (let i = 0; i < 256; i++) sum += i * hist[i];
  let sB = 0, wB = 0, best = 0, th = 128;
  for (let i = 0; i < 256; i++) { wB += hist[i]; if (!wB) continue; const wF = w * h - wB; if (!wF) break; sB += i * hist[i];
    const mB = sB / wB, mF = (sum - sB) / wF, v = wB * wF * (mB - mF) ** 2; if (v > best) { best = v; th = i; } }
  const bin = new Uint8Array(w * h); for (let i = 0; i < w * h; i++) bin[i] = g[i] > th ? 1 : 0;
  // largest bright component, prefer one covering center
  const lab = new Int32Array(w * h); let n = 0, bestC = null; const stack = [];
  for (let s = 0; s < w * h; s++) {
    if (!bin[s] || lab[s]) continue; n++;
    let cnt = 0, minX = w, maxX = 0, minY = h, maxY = 0, center = false;
    stack.push(s); lab[s] = n;
    const pts = { tl: [0, 0, 1e9], br: [0, 0, -1e9], tr: [0, 0, -1e9], bl: [0, 0, 1e9] };
    while (stack.length) {
      const p = stack.pop(), x = p % w, y = (p / w) | 0; cnt++;
      if (x < minX) minX = x; if (x > maxX) maxX = x; if (y < minY) minY = y; if (y > maxY) maxY = y;
      if (Math.abs(x - w / 2) < w * .1 && Math.abs(y - h / 2) < h * .1) center = true;
      const s1 = x + y, s2 = x - y;
      if (s1 < pts.tl[2]) pts.tl = [x, y, s1]; if (s1 > pts.br[2]) pts.br = [x, y, s1];
      if (s2 > pts.tr[2]) pts.tr = [x, y, s2]; if (s2 < pts.bl[2]) pts.bl = [x, y, s2];
      for (const q of [p - 1, p + 1, p - w, p + w]) {
        if (q < 0 || q >= w * h || lab[q] || !bin[q]) continue;
        if ((q === p - 1 && x === 0) || (q === p + 1 && x === w - 1)) continue;
        lab[q] = n; stack.push(q);
      }
    }
    const score = cnt * (center ? 2 : 1);
    if (!bestC || score > bestC.score) bestC = { score, cnt, pts, box: [minX, minY, maxX, maxY] };
  }
  const inset = [[.06, .06], [.94, .06], [.94, .94], [.06, .94]].map(([x, y]) => ({ x: x * src.width, y: y * src.height }));
  if (!bestC || bestC.cnt < w * h * .12 || bestC.cnt > w * h * .97) return { quad: inset, found: false };
  const { tl, tr, br, bl } = bestC.pts;
  const quad = [tl, tr, br, bl].map(([x, y]) => ({ x: x / k, y: y / k }));
  if (polyArea(quad) < src.width * src.height * .1) return { quad: inset, found: false };
  return { quad, found: true };
}

function polyArea(q) { let a = 0; for (let i = 0; i < 4; i++) { const p = q[i], r = q[(i + 1) % 4]; a += p.x * r.y - r.x * p.y; } return Math.abs(a / 2); }

function boxBlur(src, w, h, r) {
  const out = new Float32Array(w * h), tmp = new Float32Array(w * h);
  for (let y = 0; y < h; y++) { let acc = 0; const row = y * w;
    for (let x = -r; x <= r; x++) acc += src[row + Math.min(w - 1, Math.max(0, x))];
    for (let x = 0; x < w; x++) { tmp[row + x] = acc / (2 * r + 1);
      acc += src[row + Math.min(w - 1, x + r + 1)] - src[row + Math.max(0, x - r)]; } }
  for (let x = 0; x < w; x++) { let acc = 0;
    for (let y = -r; y <= r; y++) acc += tmp[Math.min(h - 1, Math.max(0, y)) * w + x];
    for (let y = 0; y < h; y++) { out[y * w + x] = acc / (2 * r + 1);
      acc += tmp[Math.min(h - 1, y + r + 1) * w + x] - tmp[Math.max(0, y - r) * w + x]; } }
  return out;
}

/* homography from 4 src points -> unit rect */
function solveH(from, to) {
  const A = [], b = [];
  for (let i = 0; i < 4; i++) {
    const { x, y } = from[i], { x: u, y: v } = to[i];
    A.push([x, y, 1, 0, 0, 0, -u * x, -u * y]); b.push(u);
    A.push([0, 0, 0, x, y, 1, -v * x, -v * y]); b.push(v);
  }
  for (let i = 0; i < 8; i++) {
    let m = i; for (let r = i + 1; r < 8; r++) if (Math.abs(A[r][i]) > Math.abs(A[m][i])) m = r;
    [A[i], A[m]] = [A[m], A[i]]; [b[i], b[m]] = [b[m], b[i]];
    for (let r = 0; r < 8; r++) { if (r === i) continue; const f = A[r][i] / A[i][i];
      for (let c = i; c < 8; c++) A[r][c] -= f * A[i][c]; b[r] -= f * b[i]; }
  }
  return b.map((v, i) => v / A[i][i]).concat(1);
}

const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);

export function warp(src, quad, maxSide = 2600) {
  let W = Math.max(dist(quad[0], quad[1]), dist(quad[3], quad[2]));
  let H = Math.max(dist(quad[0], quad[3]), dist(quad[1], quad[2]));
  const k = Math.min(1.4, maxSide / Math.max(W, H)); W = Math.round(W * k); H = Math.round(H * k);
  const dst = [{ x: 0, y: 0 }, { x: W, y: 0 }, { x: W, y: H }, { x: 0, y: H }];
  const M = solveH(dst, quad); // maps dst -> src
  const sctx = src.getContext('2d', { willReadFrequently: true });
  const sd = sctx.getImageData(0, 0, src.width, src.height).data, sw = src.width, sh = src.height;
  const out = document.createElement('canvas'); out.width = W; out.height = H;
  const octx = out.getContext('2d'); const od = octx.createImageData(W, H); const o = od.data;
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const z = M[6] * x + M[7] * y + 1, sx = (M[0] * x + M[1] * y + M[2]) / z, sy = (M[3] * x + M[4] * y + M[5]) / z;
      const x0 = Math.max(0, Math.min(sw - 2, sx | 0)), y0 = Math.max(0, Math.min(sh - 2, sy | 0));
      const fx = Math.min(1, Math.max(0, sx - x0)), fy = Math.min(1, Math.max(0, sy - y0));
      const i00 = (y0 * sw + x0) * 4, i10 = i00 + 4, i01 = i00 + sw * 4, i11 = i01 + 4, oi = (y * W + x) * 4;
      for (let c = 0; c < 3; c++)
        o[oi + c] = (sd[i00 + c] * (1 - fx) + sd[i10 + c] * fx) * (1 - fy) + (sd[i01 + c] * (1 - fx) + sd[i11 + c] * fx) * fy;
      o[oi + 3] = 255;
    }
  }
  octx.putImageData(od, 0, 0);
  return out;
}

export function rotate90(src, dir = 1) {
  const c = document.createElement('canvas'); c.width = src.height; c.height = src.width;
  const ctx = c.getContext('2d'); ctx.translate(c.width / 2, c.height / 2); ctx.rotate(dir * Math.PI / 2);
  ctx.drawImage(src, -src.width / 2, -src.height / 2); return c;
}

export function applyFilter(src, kind) {
  const c = document.createElement('canvas'); c.width = src.width; c.height = src.height;
  const ctx = c.getContext('2d', { willReadFrequently: true }); ctx.drawImage(src, 0, 0);
  if (kind === 'original') return c;
  const img = ctx.getImageData(0, 0, c.width, c.height), d = img.data, n = c.width * c.height;
  if (kind === 'gray' || kind === 'magic') {
    const hist = new Uint32Array(256);
    for (let i = 0; i < n; i++) hist[(d[i * 4] * .299 + d[i * 4 + 1] * .587 + d[i * 4 + 2] * .114) | 0]++;
    let lo = 0, hi = 255, acc = 0; for (; lo < 255; lo++) { acc += hist[lo]; if (acc > n * .01) break; }
    acc = 0; for (; hi > 0; hi--) { acc += hist[hi]; if (acc > n * .06) break; }
    const sc = 255 / Math.max(30, hi - lo);
    for (let i = 0; i < n; i++) {
      const p = i * 4;
      if (kind === 'gray') { const y = (d[p] * .299 + d[p + 1] * .587 + d[p + 2] * .114 - lo) * sc; d[p] = d[p + 1] = d[p + 2] = y; }
      else for (let k = 0; k < 3; k++) { let v = (d[p + k] - lo) * sc; v = v > 255 ? 255 : v; d[p + k] = 255 * Math.pow(Math.max(0, v) / 255, 1.25); }
    }
  } else if (kind === 'bw') {
    const W = c.width, H = c.height, gray = new Float32Array(n);
    for (let i = 0; i < n; i++) gray[i] = d[i * 4] * .299 + d[i * 4 + 1] * .587 + d[i * 4 + 2] * .114;
    const ii = new Float64Array((W + 1) * (H + 1));
    for (let y = 0; y < H; y++) { let row = 0; for (let x = 0; x < W; x++) { row += gray[y * W + x]; ii[(y + 1) * (W + 1) + x + 1] = ii[y * (W + 1) + x + 1] + row; } }
    const r = Math.max(8, Math.round(Math.min(W, H) / 28));
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
      const x0 = Math.max(0, x - r), y0 = Math.max(0, y - r), x1 = Math.min(W, x + r + 1), y1 = Math.min(H, y + r + 1);
      const s = ii[y1 * (W + 1) + x1] - ii[y0 * (W + 1) + x1] - ii[y1 * (W + 1) + x0] + ii[y0 * (W + 1) + x0];
      const mean = s / ((x1 - x0) * (y1 - y0)), v = gray[y * W + x] < mean * .88 ? 0 : 255, p = (y * W + x) * 4;
      d[p] = d[p + 1] = d[p + 2] = v;
    }
  }
  ctx.putImageData(img, 0, 0); return c;
}

/* remove near-white background (for stamps / signatures from photos) */
export function knockoutWhite(src, tint) {
  const c = document.createElement('canvas'); c.width = src.width; c.height = src.height;
  const ctx = c.getContext('2d', { willReadFrequently: true }); ctx.drawImage(src, 0, 0);
  const img = ctx.getImageData(0, 0, c.width, c.height), d = img.data;
  const tc = tint && [parseInt(tint.slice(1, 3), 16), parseInt(tint.slice(3, 5), 16), parseInt(tint.slice(5, 7), 16)];
  for (let p = 0; p < d.length; p += 4) {
    const y = d[p] * .299 + d[p + 1] * .587 + d[p + 2] * .114;
    const a = Math.max(0, Math.min(255, (205 - y) * 3));
    d[p + 3] = a; if (tc) { d[p] = tc[0]; d[p + 1] = tc[1]; d[p + 2] = tc[2]; }
  }
  ctx.putImageData(img, 0, 0); return trim(c);
}

export function trim(c, pad = 6) {
  const ctx = c.getContext('2d', { willReadFrequently: true }); const d = ctx.getImageData(0, 0, c.width, c.height).data;
  let x0 = c.width, y0 = c.height, x1 = -1, y1 = -1;
  for (let y = 0; y < c.height; y++) for (let x = 0; x < c.width; x++) if (d[(y * c.width + x) * 4 + 3] > 20) {
    if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
  if (x1 < 0) return c;
  x0 = Math.max(0, x0 - pad); y0 = Math.max(0, y0 - pad); x1 = Math.min(c.width - 1, x1 + pad); y1 = Math.min(c.height - 1, y1 + pad);
  const o = document.createElement('canvas'); o.width = x1 - x0 + 1; o.height = y1 - y0 + 1;
  o.getContext('2d').drawImage(c, -x0, -y0); return o;
}

export function scaleCanvas(src, w, h) {
  const c = document.createElement('canvas'); c.width = Math.round(w); c.height = Math.round(h);
  const ctx = c.getContext('2d'); ctx.imageSmoothingQuality = 'high'; ctx.drawImage(src, 0, 0, c.width, c.height); return c;
}
