import { L } from './i18n.js';
import { I } from './icons.js';
import { sheet, esc, fmtSize, baseName } from './ui.js';
import { getBytes, shareFile, saveToPhone } from './lib.js';

export const openFile = (id, page) => window.dispatchEvent(new CustomEvent('panna:open', { detail: { id, page } }));
export const refresh = () => window.dispatchEvent(new Event('panna:refresh'));

export function resultSheet(meta, note) {
  refresh();
  sheet(`<div class="rhead"><span class="rthumb">${meta.thumb ? `<img src="${meta.thumb}" alt="">` : I.doc}</span>
    <div><b>${esc(baseName(meta.name))}</b><small>${meta.pages} ${L('पेज', 'pages')}, ${fmtSize(meta.size)}</small>${note ? `<small class="ok">${esc(note)}</small>` : ''}</div>
    <span class="okbadge">${I.check}</span></div>
    <button class="sitem" data-s="open">${I.doc}<span>${L('खोलें', 'Open')}</span></button>
    <button class="sitem" data-s="share">${I.share}<span>${L('शेयर करें (WhatsApp आदि)', 'Share (WhatsApp etc.)')}</span></button>
    <button class="sitem" data-s="save">${I.download}<span>${L('फ़ोन में सेव करें', 'Save to phone')}</span></button>`, async v => {
      if (v === 'open') openFile(meta.id);
      if (v === 'share') shareFile(await getBytes(meta.id), meta.name);
      if (v === 'save') saveToPhone(await getBytes(meta.id), meta.name);
    });
}
