import * as pdfjs from 'pdfjs-dist/legacy/build/pdf.mjs';
import workerUrl from 'pdfjs-dist/legacy/build/pdf.worker.mjs?url';
pdfjs.GlobalWorkerOptions.workerSrc = workerUrl;
export { pdfjs };

export function loadPdf(data, password) {
  return pdfjs.getDocument({
    data, password, isEvalSupported: false,
    cMapUrl: './cmaps/', cMapPacked: true, standardFontDataUrl: './standard_fonts/',
  }).promise;
}

export async function makeThumb(doc) {
  const page = await doc.getPage(1);
  const vp0 = page.getViewport({ scale: 1 });
  const scale = 220 / vp0.width;
  const vp = page.getViewport({ scale });
  const c = document.createElement('canvas');
  c.width = Math.round(vp.width); c.height = Math.round(vp.height);
  await page.render({ canvasContext: c.getContext('2d'), viewport: vp }).promise;
  const url = c.toDataURL('image/jpeg', 0.72);
  page.cleanup(); c.width = c.height = 0;
  return url;
}
