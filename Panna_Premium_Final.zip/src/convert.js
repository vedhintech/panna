import { PDFDocument } from 'pdf-lib';
import Sortable from 'sortablejs';
import { L } from './i18n.js';
import { I } from './icons.js';
import { $, $$, esc, screen, toast, busy, tap, dialog, choose, baseName, fmtSize } from './ui.js';
import { loadPdf } from './pdf.js';
import { addToLibrary, pickPhotos, takePhoto, blobToCanvas, canvasBytes, canvasBlob, saveToPhone, shareFile, pickAny } from './lib.js';
import { resultSheet } from './result.js';
import { textScreen, canvasesToPdf, cropEditor } from './scan.js';
import { ocrPdf } from './ocr.js';
import { getText, setText } from './db.js';

const A4 = [595.28, 841.89];
const today = () => new Date().toLocaleDateString('en-GB').replace(/\//g, '-');

/* ---------- photos -> PDF ---------- */
export async function imagesToPdf() {
  const blobs = await pickPhotos(true); if (!blobs.length) return;
  const b = busy(L('फ़ोटो खोल रहे हैं…', 'Loading photos…'));
  const items = []; for (const bl of blobs) { const c = await blobToCanvas(bl, 2400); items.push({ c, url: c.toDataURL('image/jpeg', .5) }); } b.done();
  const s = screen(L('फ़ोटो से PDF', 'Photos to PDF'), { action: L('PDF बनाएँ', 'Make PDF') });
  s.body.innerHTML = `<div class="seg" id="sz"><button data-v="a4" aria-pressed="true">A4</button><button data-v="fit" aria-pressed="false">${L('फ़ोटो जितना', 'Photo size')}</button></div>
    <div class="seg" id="mg"><button data-v="0" aria-pressed="false">${L('बिना किनारा', 'No margin')}</button><button data-v="24" aria-pressed="true">${L('किनारा', 'Margin')}</button></div>
    <p class="hint">${L('क्रम बदलने के लिए दबाकर खींचें।', 'Press and drag to reorder.')}</p><div class="pgrid"></div>`;
  const grid = $('.pgrid', s);
  const render = () => grid.innerHTML = items.map((it, i) => `<div class="ptile"><img src="${it.url}" alt=""><span>${i + 1}</span><button class="tdel" data-del="${i}">${I.close}</button></div>`).join('');
  new Sortable(grid, { animation: 150, delay: 180, delayOnTouchOnly: true, onEnd: e => { const [m] = items.splice(e.oldIndex, 1); items.splice(e.newIndex, 0, m); render(); } });
  s.addEventListener('click', e => { const sg = e.target.closest('.seg button'); if (sg) $$('button', sg.parentNode).forEach(x => x.setAttribute('aria-pressed', x === sg));
    const d = e.target.closest('[data-del]'); if (d) { items.splice(+d.dataset.del, 1); render(); } });
  s.go.onclick = async () => {
    if (!items.length) return; const a4 = $('#sz [aria-pressed=true]', s).dataset.v === 'a4', m = +$('#mg [aria-pressed=true]', s).dataset.v;
    const bz = busy(); const out = await PDFDocument.create();
    for (const [i, { c }] of items.entries()) { bz.set(L(`पेज ${i + 1}`, `Page ${i + 1}`), i / items.length);
      const img = await out.embedJpg(await canvasBytes(c, 'image/jpeg', .88)); const land = c.width > c.height;
      const [W, H] = a4 ? (land ? [A4[1], A4[0]] : A4) : [595.28, 595.28 * c.height / c.width];
      const k = Math.min((W - 2 * m) / c.width, (H - 2 * m) / c.height); const w = c.width * k, h = c.height * k;
      out.addPage([W, H]).drawImage(img, { x: (W - w) / 2, y: (H - h) / 2, width: w, height: h }); }
    const meta = await addToLibrary(await out.save(), L('फ़ोटो PDF ', 'Photos ') + today()); bz.done(); s.close(); resultSheet(meta);
  };
  render();
}

/* ---------- PDF -> photos ---------- */
export async function pdfToImages(file) {
  const q = await choose(L('फ़ोटो की क्वालिटी', 'Image quality'), [['150', 'image', L('सामान्य (WhatsApp के लिए)', 'Normal (for WhatsApp)')], ['220', 'image', L('ऊँची (प्रिंट के लिए)', 'High (for print)')]]); if (!q) return;
  const b = busy(); const doc = await loadPdf(file.bytes.slice(0)); const files = [];
  for (let i = 1; i <= doc.numPages; i++) { b.set(L(`पेज ${i}/${doc.numPages}`, `Page ${i}/${doc.numPages}`), i / doc.numPages);
    const pg = await doc.getPage(i); const vp = pg.getViewport({ scale: +q / 72 }); const c = document.createElement('canvas'); c.width = vp.width; c.height = vp.height;
    const x = c.getContext('2d', { alpha: false }); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); await pg.render({ canvasContext: x, viewport: vp }).promise;
    files.push({ name: `${baseName(file.name)}-${i}.jpg`, bytes: await canvasBytes(c, 'image/jpeg', .9) }); c.width = 0; }
  doc.destroy(); b.done();
  const act = await choose(L(`${files.length} फ़ोटो तैयार`, `${files.length} images ready`), [['save', 'download', L('फ़ोन में सेव करें', 'Save to phone')], ['share', 'share', L('शेयर करें', 'Share')]]);
  if (act === 'save') for (const f of files) await saveToPhone(f.bytes, f.name, 'image/jpeg');
  if (act === 'share') for (const f of files.slice(0, 10)) await shareFile(f.bytes, f.name, 'image/jpeg');
}

/* ---------- PDF -> text (OCR if needed) ---------- */
export async function pdfToText(file) {
  let pages = file.id ? await getText(file.id) : null;
  if (!pages) { const doc = await loadPdf(file.bytes.slice(0)); pages = []; for (let i = 1; i <= doc.numPages; i++) pages.push((await (await doc.getPage(i)).getTextContent()).items.map(x => x.str).join(' ')); doc.destroy(); }
  let text = pages.map((t, i) => `--- ${L('पेज', 'Page')} ${i + 1} ---\n${t}`).join('\n\n');
  if (pages.join('').trim().length < 20) {
    if (!await new Promise(r => { const w = dialog(`<h3>${L('इसमें टेक्स्ट नहीं है', 'No text inside')}</h3><p>${L('यह स्कैन की हुई PDF लगती है। OCR से पढ़ें? (हिंदी + English)', 'Looks scanned. Read it with OCR? (Hindi + English)')}</p>`, L('OCR करें', 'Run OCR'), () => { r(true); return true; }); w.oncancel = () => r(false); })) return;
    const b = busy(L('OCR चल रहा है…', 'Running OCR…'));
    try { const res = await ocrPdf(file.bytes, { onPage: (i, n) => b.set(L(`पेज ${i}/${n} पढ़ रहे हैं…`, `Reading page ${i}/${n}…`), (i - 1) / n) });
      pages = res.texts; if (file.id) await setText(file.id, pages); text = pages.map((t, i) => `--- ${L('पेज', 'Page')} ${i + 1} ---\n${t}`).join('\n\n'); }
    finally { b.done(); }
  }
  textScreen(text, baseName(file.name));
}

/* ---------- make searchable ---------- */
export async function makeSearchable(file) {
  const b = busy(L('OCR शुरू हो रहा है…', 'Starting OCR…'));
  try { const r = await ocrPdf(file.bytes, { onPage: (i, n) => b.set(L(`पेज ${i}/${n} पढ़ रहे हैं…`, `Reading page ${i}/${n}…`), (i - 1) / n) });
    const meta = await addToLibrary(r.bytes, baseName(file.name) + ' (OCR)', { ocr: true }); await setText(meta.id, r.texts); b.done();
    resultSheet(meta, L('अब इसमें खोज सकते हैं और टेक्स्ट कॉपी कर सकते हैं', 'Now searchable and copyable')); }
  catch (e) { b.done(); toast('OCR: ' + (e?.message || e), 5000); }
}

/* ---------- Word / Excel -> PDF ---------- */
async function htmlToPdf(html, name, landscape) {
  const { default: html2canvas } = await import('html2canvas');
  const W = landscape ? 1123 : 794, H = landscape ? 794 : 1123, pad = 56;
  const host = document.createElement('div'); host.className = 'docrender'; host.style.width = W + 'px'; host.style.padding = pad + 'px';
  host.innerHTML = html; document.body.append(host);
  await new Promise(r => setTimeout(r, 120));
  const full = await html2canvas(host, { scale: 2, backgroundColor: '#fff', logging: false });
  host.remove();
  const pageH = H * 2, pages = [];
  for (let y = 0; y < full.height; y += pageH - 40) { const c = document.createElement('canvas'); c.width = full.width; c.height = pageH; const x = c.getContext('2d');
    x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.drawImage(full, 0, -y); pages.push(c); if (pages.length > 200) break; }
  const bytes = await canvasesToPdf(pages, { fixed: landscape ? [A4[1], A4[0]] : A4 });
  return addToLibrary(bytes, name);
}
export async function wordToPdf() {
  const f = await pickAny('.docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document'); if (!f) return;
  const b = busy(L('Word फ़ाइल पढ़ रहे हैं…', 'Reading Word file…'));
  try { const mammoth = (await import('mammoth/mammoth.browser.js')).default || window.mammoth;
    const r = await mammoth.convertToHtml({ arrayBuffer: await f.arrayBuffer() });
    const meta = await htmlToPdf(r.value, baseName(f.name)); b.done(); resultSheet(meta, L('लेआउट थोड़ा अलग हो सकता है', 'Layout may differ slightly')); }
  catch (e) { b.done(); toast(L('यह Word फ़ाइल नहीं खुली (.docx चाहिए)', 'Could not read this Word file (.docx needed)'), 5000); }
}
export async function excelToPdf() {
  const f = await pickAny('.xlsx,.xls,.csv'); if (!f) return;
  const b = busy(L('Excel फ़ाइल पढ़ रहे हैं…', 'Reading Excel file…'));
  try { const XLSX = await import('xlsx'); const wb = XLSX.read(await f.arrayBuffer());
    const html = wb.SheetNames.map(n => `<h2>${esc(n)}</h2>` + XLSX.utils.sheet_to_html(wb.Sheets[n], { header: '', footer: '' })).join('<div style="height:24px"></div>');
    const meta = await htmlToPdf(html, baseName(f.name), true); b.done(); resultSheet(meta); }
  catch (e) { b.done(); toast(L('यह Excel फ़ाइल नहीं खुली', 'Could not read this Excel file'), 5000); }
}

/* ---------- photo / signature resizer for govt forms ---------- */
const PRESETS = () => [
  { k: 'photo', l: L('फ़ॉर्म फ़ोटो (20–50 KB)', 'Form photo (20–50 KB)'), w: 200, h: 230, min: 20, max: 50 },
  { k: 'sign', l: L('फ़ॉर्म साइन (10–20 KB)', 'Form signature (10–20 KB)'), w: 140, h: 60, min: 10, max: 20 },
  { k: 'pass', l: L('पासपोर्ट फ़ोटो 600×600', 'Passport photo 600×600'), w: 600, h: 600, min: 10, max: 240 },
  { k: 'c', l: L('अपने हिसाब से', 'Custom'), w: 0, h: 0, min: 0, max: 100 }];
export async function resizer() {
  const blobs = await pickPhotos(false); if (!blobs.length) return;
  const src = await blobToCanvas(blobs[0], 3000);
  const s = screen(L('फ़ोटो/साइन साइज़ बदलें', 'Resize photo/signature'), { action: L('बनाएँ', 'Create') });
  s.body.innerHTML = `<div class="rprev"><img alt=""></div>
    <div class="chips wrap">${PRESETS().map((p, i) => `<button class="chip" data-p="${i}" aria-pressed="${!i}">${p.l}</button>`).join('')}</div>
    <div class="grid2"><label class="fl">${L('चौड़ाई (px)', 'Width (px)')}<input id="rw" type="number" inputmode="numeric"></label><label class="fl">${L('ऊँचाई (px)', 'Height (px)')}<input id="rh" type="number" inputmode="numeric"></label>
    <label class="fl">${L('कम से कम KB', 'Min KB')}<input id="rmin" type="number" inputmode="numeric"></label><label class="fl">${L('ज़्यादा से ज़्यादा KB', 'Max KB')}<input id="rmax" type="number" inputmode="numeric"></label></div>
    <p class="hint">${L('फ़ॉर्म में जो साइज़ लिखा है वही डालें। ख़ाली छोड़ा तो फ़ोटो का असली साइज़ रहेगा।', 'Enter what the form asks. Leave blank to keep the original size.')}</p>
    <button class="btn ghost2" data-crop>${I.crop}${L('पहले काटें (crop)', 'Crop first')}</button><p class="rout muted"></p>`;
  let img = src; const prev = () => $('.rprev img', s).src = img.toDataURL('image/jpeg', .7); prev();
  const setP = p => { $('#rw', s).value = p.w || ''; $('#rh', s).value = p.h || ''; $('#rmin', s).value = p.min || ''; $('#rmax', s).value = p.max || ''; }; setP(PRESETS()[0]);
  s.addEventListener('click', async e => { const c = e.target.closest('[data-p]'); if (c) { $$('[data-p]', s).forEach(x => x.setAttribute('aria-pressed', x === c)); setP(PRESETS()[+c.dataset.p]); }
    if (e.target.closest('[data-crop]')) { const r = await cropEditor(img, { showFilters: false, quad: [{ x: 0, y: 0 }, { x: img.width, y: 0 }, { x: img.width, y: img.height }, { x: 0, y: img.height }] }); if (r) { img = r.canvas; prev(); } } });
  s.go.onclick = async () => {
    const w = +$('#rw', s).value || img.width, h = +$('#rh', s).value || Math.round(img.height * w / img.width), mn = (+$('#rmin', s).value || 0) * 1024, mx = (+$('#rmax', s).value || 99999) * 1024;
    const c = document.createElement('canvas'); c.width = w; c.height = h; const x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, w, h);
    const k = Math.max(w / img.width, h / img.height); x.imageSmoothingQuality = 'high'; x.drawImage(img, (w - img.width * k) / 2, (h - img.height * k) / 2, img.width * k, img.height * k);
    let lo = .05, hi = 1, best = null, bestQ = 0;
    for (let i = 0; i < 9; i++) { const q = (lo + hi) / 2; const bl = await canvasBlob(c, 'image/jpeg', q); if (bl.size <= mx) { best = bl; bestQ = q; lo = q; } else hi = q; }
    if (!best) best = await canvasBlob(c, 'image/jpeg', .05);
    let note = '';
    if (best.size < mn) { const bl = await canvasBlob(c, 'image/jpeg', 1); best = bl.size <= mx ? bl : best;
      if (best.size < mn) note = L(' (फ़ोटो छोटी है, कम से कम साइज़ तक नहीं पहुँची। चौड़ाई-ऊँचाई बढ़ाएँ।)', ' (Below minimum. Increase width/height.)'); }
    $('.rout', s).textContent = `${w}×${h}px, ${fmtSize(best.size)}${note}`;
    const act = await choose(`${w}×${h}px, ${fmtSize(best.size)}`, [['save', 'download', L('फ़ोन में सेव करें', 'Save to phone')], ['share', 'share', L('शेयर करें', 'Share')]]);
    const name = `photo-${w}x${h}-${Math.round(best.size / 1024)}kb.jpg`;
    if (act === 'save') saveToPhone(best, name, 'image/jpeg'); if (act === 'share') shareFile(best, name, 'image/jpeg');
  };
}

/* ---------- passport photo sheet ---------- */
export async function passportSheet() {
  const src = await choose(L('फ़ोटो', 'Photo'), [['cam', 'scan', L('कैमरा', 'Camera')], ['gal', 'image', L('गैलरी', 'Gallery')]]); if (!src) return;
  const blobs = src === 'cam' ? await takePhoto() : await pickPhotos(false); if (!blobs.length) return;
  const c0 = await blobToCanvas(blobs[0], 3000);
  const s = screen(L('पासपोर्ट फ़ोटो शीट', 'Passport photo sheet'), { action: L('शीट बनाएँ', 'Make sheet') });
  s.body.innerHTML = `<p class="hint">${L('चेहरा फ़्रेम के बीच में लाएँ।', 'Center the face in the frame.')}</p>
    <div class="ppframe"><canvas></canvas></div>
    <label class="fl">${L('ज़ूम', 'Zoom')}<input id="pz" type="range" min="100" max="300" value="120"></label>
    <label class="fl">${L('ऊपर-नीचे', 'Up / down')}<input id="py" type="range" min="0" max="100" value="40"></label>
    <label class="fl">${L('दाएँ-बाएँ', 'Left / right')}<input id="px" type="range" min="0" max="100" value="50"></label>
    <div class="grid2"><label class="fl">${L('साइज़', 'Size')}<select id="ps"><option value="35x45">3.5 × 4.5 cm (India)</option><option value="51x51">2 × 2 inch (US visa)</option><option value="25x30">2.5 × 3 cm (stamp)</option></select></label>
    <label class="fl">${L('काग़ज़', 'Paper')}<select id="pp"><option value="a4">A4</option><option value="46">4 × 6 inch</option></select></label></div>`;
  const cv = $('.ppframe canvas', s);
  const crop = () => { const [mw, mh] = $('#ps', s).value.split('x').map(Number); const ar = mw / mh; const z = +$('#pz', s).value / 100;
    let ch = c0.height / z, cw = ch * ar; if (cw > c0.width / z) { cw = c0.width / z; ch = cw / ar; }
    const x = (c0.width - cw) * +$('#px', s).value / 100, y = (c0.height - ch) * +$('#py', s).value / 100;
    const o = document.createElement('canvas'); o.height = 900; o.width = Math.round(900 * ar); o.getContext('2d').drawImage(c0, x, y, cw, ch, 0, 0, o.width, o.height); return { o, mw, mh }; };
  const draw = () => { const { o } = crop(); cv.width = o.width / 3; cv.height = o.height / 3; cv.getContext('2d').drawImage(o, 0, 0, cv.width, cv.height); };
  s.addEventListener('input', draw); draw();
  s.go.onclick = async () => {
    const { o, mw, mh } = crop(); const a4 = $('#pp', s).value === 'a4'; const dpi = 300, mm = dpi / 25.4;
    const PW = a4 ? 210 : 101.6, PH = a4 ? 297 : 152.4; const W = Math.round(PW * mm), H = Math.round(PH * mm);
    const c = document.createElement('canvas'); c.width = W; c.height = H; const x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, W, H);
    const gap = 3 * mm, pw = mw * mm, ph = mh * mm, cols = Math.floor((W - 2 * gap) / (pw + gap)), rows = Math.floor((H - 2 * gap) / (ph + gap));
    const ox = (W - (cols * pw + (cols - 1) * gap)) / 2, oy = a4 ? 12 * mm : (H - (rows * ph + (rows - 1) * gap)) / 2;
    const maxRows = a4 ? Math.min(rows, 4) : rows;
    for (let r = 0; r < maxRows; r++) for (let k = 0; k < cols; k++) { const px = ox + k * (pw + gap), py = oy + r * (ph + gap); x.drawImage(o, px, py, pw, ph); x.strokeStyle = '#bbb'; x.lineWidth = 1; x.strokeRect(px, py, pw, ph); }
    const n = maxRows * cols;
    const bytes = await canvasesToPdf([c], { fixed: [PW * 72 / 25.4, PH * 72 / 25.4] });
    const meta = await addToLibrary(bytes, L(`पासपोर्ट फ़ोटो (${n})`, `Passport photos (${n})`)); s.close();
    resultSheet(meta, L(`${n} फ़ोटो, प्रिंट करते समय "Actual size / 100%" चुनें`, `${n} photos. Print at "Actual size / 100%"`));
  };
}
