import '@fontsource/mukta/400.css';
import '@fontsource/mukta/500.css';
import '@fontsource/mukta/600.css';
import '@fontsource/mukta/800.css';
import './style.css';
import { I, GEM } from './icons.js';
import { t, L, getLang, setLang } from './i18n.js';
import * as db from './db.js';
import { loadPdf } from './pdf.js';
import { Viewer } from './viewer.js';
import { $, $$, esc, tap, native, overlays, popOverlay, sheet, dialog, ask, choose, confirmBox, toast, busy, idle, fmtSize, baseName } from './ui.js';
import { addToLibrary, pickPdfs, getBytes, shareFile, saveToPhone } from './lib.js';
import { resultSheet } from './result.js';
import { Capacitor, registerPlugin } from '@capacitor/core';
import { App as CapApp } from '@capacitor/app';
import { StatusBar, Style } from '@capacitor/status-bar';
import { LocalNotifications } from '@capacitor/local-notifications';
import { TextToSpeech } from '@capacitor-community/text-to-speech';
import { openScanner, photoToText, aadhaarTool } from './scan.js';
import { openEditor } from './editor.js';
import { organize, merge, split, pageNumbers, watermark, compress, cropMargins } from './pages.js';
import { imagesToPdf, pdfToImages, pdfToText, makeSearchable, wordToPdf, excelToPdf, resizer, passportSheet } from './convert.js';
import { invoiceMaker } from './invoice.js';
import { fillForm } from './forms.js';
import { unlocked, addPassword, removePassword, isEncrypted, askPdfPassword, lockOn, bioOn, bioAvailable, setPin, clearPin, showLock, setReminder, upcoming } from './security.js';

const Incoming = registerPlugin('Incoming');
let tab = 'home', viewer = null, viewerFile = null, filesQuery = '', folder = '';

/* ---------- theme ---------- */
const mq = matchMedia('(prefers-color-scheme: dark)');
function applyTheme() {
  const pref = localStorage.getItem('panna.theme') || 'system';
  const dark = pref === 'dark' || (pref === 'system' && mq.matches);
  document.documentElement.dataset.theme = dark ? 'dark' : 'light';
  if (native) { StatusBar.setStyle({ style: dark ? Style.Dark : Style.Light }).catch(() => {}); StatusBar.setBackgroundColor({ color: dark ? '#0C1512' : '#F4F7F5' }).catch(() => {}); }
}
mq.addEventListener('change', applyTheme);

/* ---------- tools catalogue ---------- */
const TOOLS = () => [
  { g: L('स्कैन और पढ़ना', 'Scan & read'), items: [
    ['scan', 'scan', L('कैमरा स्कैन', 'Camera scan'), () => openScanner('doc')],
    ['id', 'id', L('ID कार्ड स्कैन', 'ID card scan'), () => openScanner('id')],
    ['book', 'pages', L('किताब स्कैन', 'Book scan'), () => openScanner('book')],
    ['ocr', 'ocr', L('फ़ोटो से टेक्स्ट', 'Text from photo'), () => photoToTextAsk()],
    ['searchable', 'search', L('PDF को खोजने लायक बनाएँ (OCR)', 'Make PDF searchable (OCR)'), () => withPdf(makeSearchable)],
    ['text', 'txt', L('PDF से टेक्स्ट', 'PDF to text'), () => withPdf(pdfToText)]] },
  { g: L('एडिट और साइन', 'Edit & sign'), items: [
    ['edit', 'type', L('टेक्स्ट लिखें', 'Add text'), () => withPdf(f => openEditor(f, { tool: 'text' }))],
    ['sign', 'sign', L('साइन लगाएँ', 'Add signature'), () => withPdf(f => openEditor(f, { tool: 'sign' }))],
    ['stamp', 'stamp', L('मोहर लगाएँ', 'Add stamp'), () => withPdf(f => openEditor(f, { tool: 'stamp' }))],
    ['mark', 'marker', L('हाइलाइट और पेन', 'Highlight & pen'), () => withPdf(f => openEditor(f, { tool: 'marker' }))],
    ['form', 'form', L('फ़ॉर्म भरें', 'Fill a form'), () => withPdf(f => fillForm(f, () => openEditor(f, { tool: 'text' })))],
    ['redact', 'redact', L('जानकारी छुपाएँ', 'Hide information'), () => withPdf(f => openEditor(f, { tool: 'redact' }))],
    ['aadhaar', 'id', L('आधार मास्क', 'Aadhaar mask'), () => aadhaarTool()]] },
  { g: L('पेज टूल्स', 'Page tools'), items: [
    ['merge', 'merge', L('PDF जोड़ें', 'Merge PDFs'), async () => { const fs = await pickPdfs({ multiple: true, title: L('जोड़ने के लिए PDF चुनें', 'Choose PDFs to merge') }); const ok = []; for (const f of fs) { const b = await unlocked(f); if (b) ok.push({ ...f, bytes: b }); } if (ok.length) merge(ok); }],
    ['split', 'split', L('PDF अलग करें', 'Split PDF'), () => withPdf(split)],
    ['organize', 'pages', L('पेज घुमाएँ, हटाएँ, क्रम बदलें', 'Rotate, delete, reorder'), () => withPdf(organize)],
    ['compress', 'compress', L('साइज़ छोटा करें', 'Reduce size'), () => withPdf(compress)],
    ['numbers', 'numbers', L('पेज नंबर', 'Page numbers'), () => withPdf(pageNumbers)],
    ['water', 'water', L('वॉटरमार्क', 'Watermark'), () => withPdf(watermark)],
    ['crop', 'crop', L('किनारे काटें', 'Crop margins'), () => withPdf(cropMargins)]] },
  { g: L('बदलें और बनाएँ', 'Convert & create'), items: [
    ['img2pdf', 'image', L('फ़ोटो से PDF', 'Photos to PDF'), () => imagesToPdf()],
    ['pdf2img', 'image', L('PDF से फ़ोटो', 'PDF to photos'), () => withPdf(pdfToImages)],
    ['word', 'word', L('Word से PDF', 'Word to PDF'), () => wordToPdf()],
    ['excel', 'excel', L('Excel से PDF', 'Excel to PDF'), () => excelToPdf()],
    ['resize', 'resize', L('फ़ॉर्म के लिए फ़ोटो/साइन साइज़', 'Photo/sign size for forms'), () => resizer()],
    ['passport', 'person', L('पासपोर्ट फ़ोटो शीट', 'Passport photo sheet'), () => passportSheet()],
    ['bill', 'invoice', L('बिल / कोटेशन', 'Bill / quotation'), () => invoiceMaker()]] },
  { g: L('सुरक्षा', 'Security'), items: [
    ['lock', 'lock', L('PDF पर पासवर्ड लगाएँ', 'Add password to PDF'), () => withPdf(addPassword, { raw: true })],
    ['unlock', 'unlock', L('PDF से पासवर्ड हटाएँ', 'Remove PDF password'), () => withPdf(removePassword, { raw: true })]] },
];
const toolById = id => TOOLS().flatMap(g => g.items).find(x => x[0] === id);
async function photoToTextAsk() { const v = await choose(L('फ़ोटो से टेक्स्ट', 'Text from photo'), [['cam', 'scan', L('कैमरा', 'Camera')], ['gal', 'image', L('गैलरी', 'Gallery')]]); if (v) photoToText(v === 'cam'); }

/** run a tool on a PDF: from the viewer (current) or ask the user */
async function withPdf(fn, { raw } = {}) {
  let f;
  if (viewerFile) f = { ...viewerFile };
  else { [f] = await pickPdfs(); if (!f) return; }
  if (!raw) { const b = await unlocked(f); if (!b) return; f.bytes = b; }
  try { await fn(f); } catch (e) { idle(); toast(String(e?.message || e), 5000); }
}

/* ---------- shell ---------- */
const app = $('#app');
app.innerHTML = `
  <main id="screen" class="screen"></main>
  <nav class="tabbar" aria-label="Main">
    ${tabBtn('home')}${tabBtn('files')}
    <button class="scanbtn" data-act="scan" aria-label="${t('scan')}">${I.scan}</button>
    ${tabBtn('tools')}${tabBtn('settings')}
  </nav>
  <section id="viewer" class="viewer" hidden></section>
  <div id="toast" class="toast" role="status" aria-live="polite"></div>
  <input id="picker" type="file" accept="application/pdf,.pdf" hidden>`;
function tabBtn(k) { return `<button class="tab" data-tab="${k}">${I[k]}<span>${t(k)}</span></button>`; }
function relabel() { $$('.tab').forEach(b => b.querySelector('span').textContent = t(b.dataset.tab)); }

app.addEventListener('click', async e => {
  const el = e.target.closest('[data-tab],[data-act],[data-tool]'); if (!el || el.closest('#viewer')) return;
  tap();
  if (el.dataset.tab) return go(el.dataset.tab);
  if (el.dataset.tool) return toolById(el.dataset.tool)?.[3]();
  const a = el.dataset.act, id = el.dataset.id;
  if (a === 'open') $('#picker').click();
  if (a === 'scan') openScanner('doc');
  if (a === 'file') openStored(id, +el.dataset.page || 0);
  if (a === 'fileMenu') { e.stopPropagation(); fileMenu(id); }
  if (a === 'all') go('files');
  if (a === 'folder') { folder = el.dataset.v; render(); }
  if (a === 'restore') { await db.updateMeta(id, { deletedAt: null }); toast(L('फ़ाइल वापस आ गई', 'File restored')); render(); }
  if (a === 'purge') { if (await confirmBox(L('हमेशा के लिए हटाएँ?', 'Delete forever?'), L('यह वापस नहीं आएगी।', 'This cannot be undone.'), L('हटाएँ', 'Delete'), true)) { await db.removeFile(id); render(); } }
  if (a === 'emptyBin') { if (await confirmBox(L('रीसायकल बिन ख़ाली करें?', 'Empty recycle bin?'), L('सब फ़ाइलें हमेशा के लिए हट जाएँगी।', 'All files will be deleted forever.'), L('ख़ाली करें', 'Empty'), true)) { for (const f of await db.listFiles({ bin: true })) await db.removeFile(f.id); render(); } }
  if (a === 'theme') { localStorage.setItem('panna.theme', el.dataset.v); applyTheme(); render(); }
  if (a === 'lang') { setLang(el.dataset.v); relabel(); render(); }
  if (a === 'lock') { if (lockOn()) { clearPin(); toast(L('ऐप लॉक बंद', 'App lock off')); } else if (await setPin()) toast(L('ऐप लॉक चालू', 'App lock on')); render(); }
  if (a === 'bio') { localStorage.setItem('panna.bio', bioOn() ? '0' : '1'); render(); }
  if (a === 'backup') backupAll();
});
$('#picker').addEventListener('change', e => { const f = e.target.files[0]; e.target.value = ''; if (f) importFile(f); });

function go(k) { tab = k; render(); $('#screen').scrollTop = 0; }
async function render() {
  $$('.tab').forEach(b => b.setAttribute('aria-current', b.dataset.tab === tab ? 'page' : 'false'));
  const s = $('#screen');
  if (tab === 'home') s.innerHTML = await homeView();
  if (tab === 'files') { s.innerHTML = await filesView(); bindFilesSearch(); }
  if (tab === 'tools') s.innerHTML = toolsView();
  if (tab === 'settings') s.innerHTML = await settingsView();
}
window.addEventListener('panna:refresh', () => { if (tab === 'home' || tab === 'files') render(); });
window.addEventListener('panna:open', e => { const { id, page } = e.detail; if (viewer) popOverlay(); setTimeout(() => openStored(id, page), viewer ? 260 : 0); });

/* ---------- views ---------- */
function when(ts) {
  const d = new Date(ts), now = new Date(); const day = x => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
  const diff = (day(now) - day(d)) / 864e5, loc = getLang() === 'hi' ? 'hi-IN' : 'en-IN';
  if (diff === 0) return t('today') + ', ' + d.toLocaleTimeString(loc, { hour: 'numeric', minute: '2-digit' });
  if (diff === 1) return t('yesterday');
  return d.toLocaleDateString(loc, { day: 'numeric', month: 'short', year: d.getFullYear() === now.getFullYear() ? undefined : 'numeric' });
}
function fileRow(f, extra = '') {
  const pct = f.pages > 1 ? Math.round(((f.lastPage || 1) - 1) / (f.pages - 1) * 100) : 0;
  return `<li class="frow" data-act="file" data-id="${f.id}">
    <div class="thumb">${f.thumb ? `<img src="${f.thumb}" alt="">` : I.doc}${f.locked ? `<span class="lockb">${I.lock}</span>` : ''}</div>
    <div class="finfo"><b>${esc(baseName(f.name))}</b>
      <small>${f.pages} ${t('pages')}, ${fmtSize(f.size)}${f.folder ? `, ${esc(f.folder)}` : ''}<br>${when(f.opened)}${f.expiry?.date ? ` <span class="exp">${I.bell}${new Date(f.expiry.date).toLocaleDateString('en-GB')}</span>` : ''}</small>
      ${extra}${pct > 0 && !extra ? `<div class="prog" style="--p:${pct}%"></div>` : ''}</div>
    <button class="ibtn" data-act="fileMenu" data-id="${f.id}" aria-label="${L('विकल्प', 'Options')}">${I.more}</button></li>`;
}
const empty = () => `<div class="empty">${I.doc}<b>${t('emptyTitle')}</b><span>${t('emptySub')}</span></div>`;

async function homeView() {
  const files = await db.listFiles(); const exp = await upcoming();
  const quick = ['scan', 'id', 'ocr', 'sign', 'bill', 'compress', 'merge', 'aadhaar'].map(id => { const it = toolById(id); return `<button class="qbtn" data-tool="${id}">${I[it[1]]}<span>${esc(shortName(id, it[2]))}</span></button>`; }).join('');
  return `<header class="brand">${GEM}<div><h1>${getLang() === 'hi' ? 'पन्ना' : 'Panna'}</h1><p>${t('tagline')}</p></div></header>
  <button class="hero" data-act="open"><span class="hero-ic">${I.plus}</span><span><b>${t('openPdf')}</b><small>${t('openPdfSub')}</small></span></button>
  <div class="quick">${quick}</div>
  ${exp.length ? `<div class="expcard"><div class="row">${I.bell}<b>${L('जल्द खत्म होने वाले', 'Expiring soon')}</b></div>${exp.slice(0, 3).map(x => `<button class="exprow" data-act="file" data-id="${x.f.id}"><span>${esc(baseName(x.f.name))}</span><em class="${x.days <= 7 ? 'hot' : ''}">${x.days < 0 ? L('खत्म हो गया', 'Expired') : x.days === 0 ? L('आज', 'Today') : L(`${x.days} दिन`, `${x.days} days`)}</em></button>`).join('')}</div>` : ''}
  <div class="sechead"><h2>${t('recent')}</h2>${files.length > 4 ? `<button class="link" data-act="all">${t('seeAll')}</button>` : ''}</div>
  ${files.length ? `<ul class="flist">${files.slice(0, 4).map(f => fileRow(f)).join('')}</ul>` : empty()}
  <p class="privacy">${I.shield}${t('privacy')}</p>`;
}
const shortName = (id, full) => ({ scan: L('स्कैन', 'Scan'), id: L('ID कार्ड', 'ID card'), ocr: L('फ़ोटो से टेक्स्ट', 'Photo to text'), sign: L('साइन', 'Sign'), bill: L('बिल बनाएँ', 'Make bill'), compress: L('छोटा करें', 'Compress'), merge: L('जोड़ें', 'Merge'), aadhaar: L('आधार मास्क', 'Aadhaar mask') }[id] || full);

async function filesView() {
  const all = await db.listFiles(); const folders = [...new Set(all.map(f => f.folder).filter(Boolean))].sort();
  const bin = (await db.listFiles({ bin: true })).length;
  return `<header class="phead"><h1>${t('files')}</h1><button class="ibtn solid" data-act="open" aria-label="${t('openPdf')}">${I.plus}</button></header>
    <label class="searchbox">${I.search}<input id="fq" type="search" placeholder="${L('नाम या PDF के अंदर का शब्द खोजें', 'Search names or words inside PDFs')}" value="${esc(filesQuery)}"></label>
    <div class="chips">${[['', L('सब', 'All')], ...folders.map(f => [f, f])].map(([v, l]) => `<button class="chip" data-act="folder" data-v="${esc(v)}" aria-pressed="${folder === v}">${v ? I.folder : ''}${esc(l)}</button>`).join('')}
      <button class="chip" data-act="folder" data-v="__bin" aria-pressed="${folder === '__bin'}">${I.trash}${L('रीसायकल बिन', 'Recycle bin')}${bin ? ` (${bin})` : ''}</button></div>
    <div id="flist">${await filesList()}</div>`;
}
async function filesList() {
  if (folder === '__bin') {
    const bin = await db.listFiles({ bin: true });
    if (!bin.length) return `<p class="muted center">${L('रीसायकल बिन ख़ाली है। हटाई गई फ़ाइलें यहाँ 30 दिन रहती हैं।', 'Recycle bin is empty. Deleted files stay here for 30 days.')}</p>`;
    return `<p class="hint">${L('ये फ़ाइलें 30 दिन बाद अपने-आप हट जाएँगी।', 'These are removed automatically after 30 days.')}</p><ul class="flist">${bin.map(f => `<li class="frow"><div class="thumb">${f.thumb ? `<img src="${f.thumb}" alt="">` : I.doc}</div>
      <div class="finfo"><b>${esc(baseName(f.name))}</b><small>${L('हटाई', 'Deleted')} ${when(f.deletedAt)}</small></div>
      <button class="ibtn" data-act="restore" data-id="${f.id}" aria-label="${L('वापस लाएँ', 'Restore')}">${I.restore}</button><button class="ibtn" data-act="purge" data-id="${f.id}" aria-label="${L('हमेशा के लिए हटाएँ', 'Delete forever')}">${I.trash}</button></li>`).join('')}</ul>
      <button class="btn ghost2 wide" data-act="emptyBin">${L('बिन ख़ाली करें', 'Empty bin')}</button>`;
  }
  const q = filesQuery.trim().toLowerCase(); const all = (await db.listFiles()).filter(f => !folder || f.folder === folder);
  if (!all.length) return empty();
  const byName = all.filter(f => f.name.toLowerCase().includes(q));
  let html = byName.length ? `<ul class="flist">${byName.map(f => fileRow(f)).join('')}</ul>` : '';
  if (q.length >= 2) {
    const hits = [];
    for (const f of all) { const pages = await db.getText(f.id); if (!pages) continue; for (let i = 0; i < pages.length; i++) { const at = pages[i].toLowerCase().indexOf(q); if (at >= 0) { const a = Math.max(0, at - 30); hits.push({ f, page: i + 1, snip: (a ? '…' : '') + pages[i].slice(a, at + q.length + 40) + '…' }); break; } } }
    const extra = hits.filter(h => !byName.includes(h.f));
    if (extra.length) html += `<h3 class="ghead">${L('PDF के अंदर मिला', 'Found inside PDFs')}</h3><ul class="flist">${extra.map(h => fileRow(h.f, `<small class="snip">${L('पेज', 'Page')} ${h.page}: ${esc(h.snip)}</small>`).replace('data-act="file"', `data-act="file" data-page="${h.page}"`)).join('')}</ul>`;
  }
  return html || `<p class="muted center">${t('noMatch')}</p>`;
}
function bindFilesSearch() { let tm; $('#fq').addEventListener('input', e => { filesQuery = e.target.value; clearTimeout(tm); tm = setTimeout(async () => $('#flist').innerHTML = await filesList(), 200); }); }

function toolsView() {
  return `<header class="phead"><h1>${t('tools')}</h1></header>` + TOOLS().map(g => `<h2 class="ghead">${g.g}</h2><div class="tgrid">${g.items.map(([id, ic, l]) =>
    `<button class="tcard on" data-tool="${id}">${I[ic]}<span>${esc(l)}</span></button>`).join('')}</div>`).join('');
}

async function settingsView() {
  const th = localStorage.getItem('panna.theme') || 'system', l = getLang(), bio = await bioAvailable();
  const seg = (act, cur, opts) => `<div class="seg">${opts.map(([v, label]) => `<button data-act="${act}" data-v="${v}" aria-pressed="${cur === v}">${label}</button>`).join('')}</div>`;
  return `<header class="phead"><h1>${t('settings')}</h1></header>
  <div class="card"><div class="row">${I.sun}<b>${t('theme')}</b></div>${seg('theme', th, [['system', t('themeSys')], ['light', t('themeLight')], ['dark', t('themeDark')]])}</div>
  <div class="card"><div class="row">${I.globe}<b>${t('lang')}</b></div>${seg('lang', l, [['hi', 'हिंदी'], ['en', 'English']])}</div>
  <div class="card"><button class="srow" data-act="lock">${I.lock}<span><b>${L('ऐप लॉक (PIN)', 'App lock (PIN)')}</b><small>${L('ऐप खोलते समय PIN माँगे', 'Ask for PIN when opening')}</small></span><i class="switch" aria-checked="${lockOn()}"></i></button>
    ${lockOn() && bio ? `<button class="srow" data-act="bio">${I.finger}<span><b>${L('फ़िंगरप्रिंट से खोलें', 'Unlock with fingerprint')}</b></span><i class="switch" aria-checked="${bioOn()}"></i></button>` : ''}</div>
  <div class="card"><button class="srow" data-act="backup">${I.download}<span><b>${L('सब फ़ाइलों का बैकअप', 'Back up all files')}</b><small>${L('फ़ोन के Documents/Panna फ़ोल्डर में सेव करें', 'Save to Documents/Panna on your phone')}</small></span></button></div>
  <div class="card about">${GEM}<div><b>${t('about')}</b><small>${L('संस्करण 1.2.4। PDF और दस्तावेज़ टूल्स।', 'Version 1.2.4. PDF and document tools.')}</small></div></div>`;
}

async function backupAll() {
  const files = await db.listFiles(); if (!files.length) return toast(L('कोई फ़ाइल नहीं', 'No files'));
  const b = busy();
  for (const [i, f] of files.entries()) { b.set(`${i + 1}/${files.length}`, i / files.length); await saveToPhone(await getBytes(f.id), 'Backup/' + f.name); }
  b.done(); toast(L(`${files.length} फ़ाइलें Documents/Panna/Backup में सेव हुईं`, `${files.length} files saved to Documents/Panna/Backup`), 4000);
}

/* ---------- import & open ---------- */
async function importFile(file) {
  const dup = await db.findDuplicate(file.name, file.size); if (dup) return openStored(dup.id);
  const b = busy(t('opening'));
  try {
    const bytes = new Uint8Array(await file.arrayBuffer()); let password;
    if (isEncrypted(bytes)) { b.done(); password = await getPassword(bytes, file.name); if (password == null) return; }
    const meta = await addToLibrary(bytes, file.name, { password }); idle();
    openStored(meta.id, 0, password);
  } catch (e) { idle(); toast(t('badPdf'), 4000); }
}
async function getPassword(bytes, name) {
  let wrong = false;
  for (;;) { const pw = await askPdfPassword(name, wrong); if (pw == null) return null;
    try { (await loadPdf(bytes.slice(0), pw)).destroy(); return pw; } catch (e) { if (e?.name !== 'PasswordException') return pw; wrong = true; } }
}
async function openStored(id, page = 0, pw) {
  const meta = await db.getMeta(id); const bytes = await getBytes(id); if (!meta || !bytes) return toast(t('badPdf'));
  if (meta.deletedAt) return;
  let doc;
  try {
    if (meta.locked && pw == null) { pw = await getPassword(bytes, meta.name); if (pw == null) return; }
    busy(t('opening')); doc = await loadPdf(bytes.slice(0), pw);
  } catch { idle(); return toast(t('badPdf'), 4000); }
  openViewer(meta, doc, bytes, page);
}

/* ---------- viewer ---------- */
function openViewer(meta, doc, bytes, page) {
  const v = $('#viewer'); viewerFile = { id: meta.id, name: meta.name, bytes, meta };
  const night = localStorage.getItem('panna.night') === '1';
  v.innerHTML = `<header class="vbar">
      <button class="ibtn" data-v="close" aria-label="Back">${I.back}</button><h1 class="vtitle">${esc(baseName(meta.name))}</h1>
      <button class="ibtn" data-v="search" aria-label="${t('searchIn')}">${I.search}</button>
      <button class="ibtn" data-v="share" aria-label="${L('शेयर', 'Share')}">${I.share}</button>
      <button class="ibtn" data-v="more" aria-label="${L('टूल्स', 'Tools')}">${I.more}</button></header>
    <div class="vsearch" hidden><label class="searchbox">${I.search}<input id="vq" type="search" enterkeyhint="search" placeholder="${t('searchIn')}"></label>
      <button class="ibtn" data-v="sclose" aria-label="${t('cancel')}">${I.close}</button></div>
    <div class="vscroll ${night ? 'night' : ''}" id="vscroll"></div>
    <div class="vbottom"><button class="vtool" data-v="edit">${I.edit}<span>${L('एडिट', 'Edit')}</span></button>
      <button class="vtool" data-v="sign">${I.sign}<span>${L('साइन', 'Sign')}</span></button>
      <button class="pchip" data-v="goto"><span id="pcur">1</span> / ${doc.numPages}</button>
      <button class="vtool" data-v="read">${I.speaker}<span>${L('सुनें', 'Listen')}</span></button>
      <button class="vtool" data-v="night" aria-pressed="${night}">${I.moon}<span>${L('रात', 'Night')}</span></button></div>`;
  v.hidden = false; requestAnimationFrame(() => v.classList.add('in')); idle();
  const start = page || (meta.lastPage > 1 && meta.lastPage <= doc.numPages ? meta.lastPage : 1); let saveT;
  viewer = new Viewer($('#vscroll'), doc, { startPage: start, onPage: p => { $('#pcur').textContent = p; clearTimeout(saveT); saveT = setTimeout(() => db.updateMeta(meta.id, { lastPage: p }), 400); } });
  if (!page && start > 1) toast(t('resume', { n: start }));
  db.updateMeta(meta.id, { opened: Date.now() });
  overlays.push(closeViewer);
}
const viewerTools = () => [
  ['edit', 'edit', L('एडिट करें', 'Edit'), f => openEditor(f)],
  ['form', 'form', L('फ़ॉर्म भरें', 'Fill form'), f => fillForm(f, () => openEditor(f, { tool: 'text' }))],
  ['ocr', 'ocr', L('OCR: खोजने लायक बनाएँ', 'OCR: make searchable'), makeSearchable],
  ['text', 'txt', L('टेक्स्ट निकालें', 'Extract text'), pdfToText],
  ['organize', 'pages', L('पेज व्यवस्थित करें', 'Organize pages'), organize],
  ['compress', 'compress', L('साइज़ छोटा करें', 'Reduce size'), compress],
  ['split', 'split', L('अलग करें', 'Split'), split],
  ['numbers', 'numbers', L('पेज नंबर', 'Page numbers'), pageNumbers],
  ['water', 'water', L('वॉटरमार्क', 'Watermark'), watermark],
  ['img', 'image', L('फ़ोटो में बदलें', 'Save as photos'), pdfToImages],
  ['pw', 'lock', L('पासवर्ड लगाएँ', 'Add password'), addPassword, true],
  ['unpw', 'unlock', L('पासवर्ड हटाएँ', 'Remove password'), removePassword, true],
  ['remind', 'bell', L('खत्म होने की याद', 'Expiry reminder'), f => setReminder(f.meta)],
  ['save', 'download', L('फ़ोन में सेव करें', 'Save to phone'), f => saveToPhone(f.bytes, f.name), true],
  ['goto', 'hash', t('goTo'), () => gotoDialog()],
];
$('#viewer').addEventListener('click', async e => {
  const b = e.target.closest('[data-v]'); if (!b) return; tap(); const a = b.dataset.v;
  if (a === 'close') popOverlay();
  if (a === 'night') { const on = $('#vscroll').classList.toggle('night'); b.setAttribute('aria-pressed', on); localStorage.setItem('panna.night', on ? '1' : '0'); }
  if (a === 'search') { $('.vsearch').hidden = false; $('#vq').focus(); }
  if (a === 'sclose') { $('.vsearch').hidden = true; viewer.clearHits(); }
  if (a === 'goto') gotoDialog();
  if (a === 'share') shareFile(viewerFile.bytes, viewerFile.name);
  if (a === 'edit') withPdf(f => openEditor(f));
  if (a === 'sign') withPdf(f => openEditor(f, { tool: 'sign' }));
  if (a === 'read') readAloud(b);
  if (a === 'more') {
    const p = sheet(`<p class="shead">${esc(baseName(viewerFile.name))}</p><div class="tsgrid">${viewerTools().map(([k, ic, l]) => `<button data-s="${k}">${I[ic]}<span>${esc(l)}</span></button>`).join('')}</div>`, k => {
      const tl = viewerTools().find(x => x[0] === k); if (tl) withPdf(tl[3], { raw: tl[4] }); });
  }
});
$('#viewer').addEventListener('keydown', async e => {
  if (e.target.id !== 'vq' || e.key !== 'Enter') return; e.target.blur(); const q = e.target.value;
  const pane = sheet(`<p class="muted" id="sprog">${t('searching')}</p><div id="sres"></div>`);
  const res = await viewer.search(q, (i, n) => { const pr = $('#sprog', pane); if (pr) pr.textContent = `${t('searching')} ${i}/${n}`; });
  const total = res.reduce((s, r) => s + r.count, 0);
  $('#sprog', pane).textContent = total ? `${total} ${t('results')}` : t('noResults') + (viewerFile.meta.ocr ? '' : L('. स्कैन की हुई PDF हो तो पहले OCR करें।', '. If scanned, run OCR first.'));
  $('#sres', pane).innerHTML = res.map(r => `<button class="sitem hitrow" data-s="${r.page}"><span class="pg">${r.page}</span><span>${esc(r.snippet || '')}</span></button>`).join('');
  pane.onpick = p => viewer.goto(+p);
});
function closeViewer() {
  stopReading(); const v = $('#viewer'); v.classList.remove('in'); viewer?.destroy(); viewer = null; viewerFile = null;
  setTimeout(() => { v.hidden = true; v.innerHTML = ''; }, 220); if (tab === 'home' || tab === 'files') render();
}
function gotoDialog() {
  if (!viewer) return;
  dialog(`<h3>${t('goTo')}</h3><input id="gp" type="number" inputmode="numeric" min="1" max="${viewer.n}" placeholder="1 – ${viewer.n}">`, t('go'),
    d => { const n = +$('#gp', d).value; if (n >= 1 && n <= viewer.n) { viewer.goto(n); return true; } return false; }, d => $('#gp', d).focus());
}

/* ---------- read aloud ---------- */
let reading = false;
async function readAloud(btn) {
  if (reading) return stopReading();
  let pages = await db.getText(viewerFile.id);
  if (!pages) { const d = await loadPdf(viewerFile.bytes.slice(0)); pages = []; for (let i = 1; i <= d.numPages; i++) pages.push((await (await d.getPage(i)).getTextContent()).items.map(x => x.str).join(' ')); d.destroy(); }
  if (pages.join('').trim().length < 10) return toast(L('इसमें पढ़ने लायक टेक्स्ट नहीं है। पहले "OCR" करें।', 'No readable text. Run OCR first.'), 4000);
  if (!native && !window.speechSynthesis) return toast(L('यह फ़ोन पढ़कर नहीं सुना सकता', 'Read aloud not supported'));
  reading = true; btn.setAttribute('aria-pressed', 'true'); btn.querySelector('span').textContent = L('रोकें', 'Stop'); btn.firstElementChild.outerHTML = I.stop;
  for (let p = viewer.cur; p < pages.length && reading; p++) {
    viewer.goto(p + 1);
    const chunks = (pages[p].match(/[^।.!?]+[।.!?]*/g) || []).reduce((a, s) => { if (!a.length || (a[a.length - 1] + s).length > 1500) a.push(s); else a[a.length - 1] += s; return a; }, []);
    for (const c of chunks) { if (!reading) break; const lang = /[\u0900-\u097F]/.test(c) ? 'hi-IN' : 'en-IN';
      try { if (native) await TextToSpeech.speak({ text: c, lang, rate: 0.95 }); else await new Promise(r => { const u = new SpeechSynthesisUtterance(c); u.lang = lang; u.onend = r; u.onerror = r; speechSynthesis.speak(u); }); }
      catch { toast(L('आवाज़ नहीं चल पाई। फ़ोन की Settings में Text-to-speech देखें।', 'Speech failed. Check Text-to-speech in phone settings.'), 4500); reading = false; } }
  }
  stopReading();
}
function stopReading() {
  if (!reading) return; reading = false;
  if (native) TextToSpeech.stop().catch(() => {}); else window.speechSynthesis?.cancel();
  const b = $('[data-v=read]'); if (b) { b.setAttribute('aria-pressed', 'false'); b.querySelector('span').textContent = L('सुनें', 'Listen'); b.firstElementChild.outerHTML = I.speaker; }
}

/* ---------- file menu ---------- */
async function fileMenu(id) {
  const m = await db.getMeta(id);
  const v = await choose(m.name, [['open', 'doc', L('खोलें', 'Open')], ['share', 'share', L('शेयर करें', 'Share')], ['save', 'download', L('फ़ोन में सेव करें', 'Save to phone')],
    ['rename', 'pen', t('rename')], ['folder', 'folder', L('फ़ोल्डर में रखें', 'Move to folder')], ['remind', 'bell', L('खत्म होने की याद', 'Expiry reminder')], ['del', 'trash', t('del'), L('30 दिन तक रीसायकल बिन में रहेगी', 'Stays in recycle bin for 30 days'), 'danger']]);
  if (!v) return;
  if (v === 'open') openStored(id);
  if (v === 'share') shareFile(await getBytes(id), m.name);
  if (v === 'save') saveToPhone(await getBytes(id), m.name);
  if (v === 'rename') { const n = await ask(t('rename'), { value: baseName(m.name) }); if (n?.trim()) { await db.updateMeta(id, { name: n.trim() + '.pdf' }); toast(t('renamed')); render(); } }
  if (v === 'folder') { const fs = [...new Set((await db.listFiles()).map(f => f.folder).filter(Boolean))];
    const pick = await choose(L('फ़ोल्डर चुनें', 'Choose folder'), [...fs.map(f => [f, 'folder', f]), ['__new', 'plus', L('नया फ़ोल्डर', 'New folder')], ['__none', 'close', L('किसी फ़ोल्डर में नहीं', 'No folder')]]);
    if (!pick) return; let name = pick === '__none' ? '' : pick;
    if (pick === '__new') { name = (await ask(L('फ़ोल्डर का नाम', 'Folder name'), { placeholder: L('जैसे: बिल, ज़मीन, बीमा', 'e.g. Bills, Land, Insurance') }))?.trim(); if (!name) return; }
    await db.updateMeta(id, { folder: name }); toast(L('फ़ोल्डर बदल गया', 'Moved')); render(); }
  if (v === 'remind') { await setReminder(m); render(); }
  if (v === 'del') { await db.updateMeta(id, { deletedAt: Date.now() }); toast(L('रीसायकल बिन में भेजी गई', 'Moved to recycle bin')); render(); }
}

/* ---------- native hooks ---------- */
let bgAt = 0;
if (native) {
  CapApp.addListener('backButton', () => { if ($('.lockscreen')) return CapApp.exitApp(); if (overlays.length) popOverlay(); else if (tab !== 'home') go('home'); else CapApp.exitApp(); });
  CapApp.addListener('appStateChange', ({ isActive }) => { if (!isActive) bgAt = Date.now(); else if (bgAt && Date.now() - bgAt > 30000) showLock(); });
  LocalNotifications.addListener('localNotificationActionPerformed', e => { const id = e.notification?.extra?.id; if (id) openStored(id); }).catch?.(() => {});
  Incoming.addListener('file', async r => {
    if (!r?.path) { if (r?.error) toast(t('badPdf'), 4000); return; }
    try { const blob = await (await fetch(Capacitor.convertFileSrc(r.path))).blob(); if (viewer) popOverlay(); importFile(new File([blob], r.name, { type: 'application/pdf' })); }
    catch { toast(t('badPdf'), 4000); }
  });
}

setLang(getLang()); applyTheme(); render(); showLock(); db.purgeBin().catch(() => {});
