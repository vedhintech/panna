import { createWorker } from 'tesseract.js';
import { PDFDocument } from 'pdf-lib';
import { loadPdf } from './pdf.js';

let wp = null;
let progressCallback = null;
let ocrQueue = Promise.resolve();
export function getWorker(onProgress) {
  progressCallback = onProgress || null;
  if (!wp) wp = createWorker(['hin', 'eng'], 1, {
    workerPath: new URL('./tess/worker.min.js', location.href).href,
    corePath: new URL('./tess/', location.href).href,
    langPath: new URL('./tess/lang', location.href).href,
    gzip: true, workerBlobURL: false, cacheMethod: 'write',
    logger: m => progressCallback?.(m),
  }).catch(e => { wp = null; throw e; });
  return wp;
}
export async function stopOcr() {
  await ocrQueue.catch(() => {});
  if (wp) { const w = await wp.catch(() => null); wp = null; progressCallback = null; await w?.terminate(); }
}

/** OCR a canvas -> { text, words:[{text,bbox}], pdf?:Uint8Array (text-only page) } */
export function ocrCanvas(canvas, { dpi = 300, pdf = false, onProgress } = {}) {
  const run = async () => {
    const w = await getWorker(onProgress);
    await w.setParameters({ user_defined_dpi: String(Math.round(dpi)), preserve_interword_spaces: '1' });
    const { data } = await w.recognize(canvas, pdf ? { pdfTextOnly: true } : {}, { text: true, blocks: true, pdf });
    const words = [];
    // Tesseract may omit nested arrays for empty/low-confidence pages; guard every level.
    for (const block of data.blocks || []) for (const para of block.paragraphs || [])
      for (const line of para.lines || []) for (const wd of line.words || []) {
        if (wd?.bbox && wd.text) words.push({ text: wd.text, bbox: wd.bbox, conf: Number(wd.confidence) || 0 });
      }
    return { text: (data.text || '').trim(), words, pdf: data.pdf ? new Uint8Array(data.pdf) : null };
  };
  // A single Tesseract worker is stateful: serialize parameter changes and recognition
  // so two screens cannot overwrite each other's language/DPI/progress settings.
  const task = ocrQueue.then(run, run);
  ocrQueue = task.then(() => undefined, () => undefined);
  return task;
}

/** make any PDF searchable: original page + invisible OCR text layer */
export async function ocrPdf(bytes, { onPage, onProgress } = {}) {
  const src = await loadPdf(bytes.slice(0));
  let out;
  try {
    out = await PDFDocument.load(bytes, { ignoreEncryption: true });
    const texts = [];
    for (let i = 1; i <= src.numPages; i++) {
      onPage?.(i, src.numPages);
      const page = await src.getPage(i);
      let c;
      try {
        const v1 = page.getViewport({ scale: 1 });
        const scale = Math.min(300 / 72, Math.sqrt(9e6 / (v1.width * v1.height)));
        const vp = page.getViewport({ scale });
        c = document.createElement('canvas'); c.width = Math.floor(vp.width); c.height = Math.floor(vp.height);
        const ctx = c.getContext('2d', { alpha: false });
        if (!ctx) throw new Error('Canvas उपलब्ध नहीं है');
        ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c.width, c.height);
        await page.render({ canvasContext: ctx, viewport: vp }).promise;
        const r = await ocrCanvas(c, { dpi: scale * 72, pdf: true, onProgress });
        texts.push(r.text);
        if (!r.text || !r.pdf) continue;
        const layerDoc = await PDFDocument.load(r.pdf);
        const [emb] = await out.embedPdf(layerDoc, [0]);
        const target = out.getPage(i - 1);
        const { width, height } = target.getSize();
        const rot = ((target.getRotation().angle % 360) + 360) % 360;
        const box = target.getCropBox?.() || { x: 0, y: 0 };
        // pdf.js viewport is rotated; un-rotate text layer to page space
        if (rot === 0) target.drawPage(emb, { x: box.x, y: box.y, width, height });
        else {
          const W = (rot === 90 || rot === 270) ? height : width, H = (rot === 90 || rot === 270) ? width : height;
          const map = { 90: { x: box.x + width, y: box.y, deg: 90 }, 180: { x: box.x + width, y: box.y + height, deg: 180 }, 270: { x: box.x, y: box.y + height, deg: 270 } }[rot];
          if (map) target.drawPage(emb, { x: map.x, y: map.y, width: W, height: H, rotate: { type: 'degrees', angle: map.deg } });
          else target.drawPage(emb, { x: box.x, y: box.y, width, height });
        }
      } finally {
        if (c) { c.width = 0; c.height = 0; }
        page.cleanup?.();
      }
    }
    return { bytes: await out.save(), texts };
  } finally {
    src.destroy();
  }
}

export { aadhaarBoxes } from './aadhaar.js';
