import { PDFDocument, degrees } from 'pdf-lib';
import Sortable from 'sortablejs';
import { L } from './i18n.js';
import { I } from './icons.js';
import { $, $$, esc, screen, toast, busy, tap, dialog, choose, baseName, parseRanges, fmtSize } from './ui.js';
import { loadPdf } from './pdf.js';
import { addToLibrary, textCanvas, canvasBytes } from './lib.js';
import { placeOverlay } from './editor.js';
import { resultSheet } from './result.js';

async function thumbs(bytes, onEach) {
  const doc = await loadPdf(bytes.slice(0)); const out = [];
  for (let i = 1; i <= doc.numPages; i++) {
    const pg = await doc.getPage(i); const v = pg.getViewport({ scale: 1 }); const vp = pg.getViewport({ scale: 200 / Math.max(v.width, v.height) });
    const c = document.createElement('canvas'); c.width = vp.width; c.height = vp.height;
    const x = c.getContext('2d', { alpha: false }); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height);
    await pg.render({ canvasContext: x, viewport: vp }).promise; out.push(c.toDataURL('image/jpeg', .7)); onEach?.(i, doc.numPages);
  }
  doc.destroy(); return out;
}

/* ---------- organize pages ---------- */
export async function organize(file) {
  const b = busy(L('पेज तैयार हो रहे हैं…', 'Preparing pages…'));
  let src; try { src = await PDFDocument.load(file.bytes, { ignoreEncryption: true }); } catch { b.done(); return toast(L('यह PDF नहीं खुली', 'PDF did not open')); }
  const th = await thumbs(file.bytes, (i, n) => b.set(L(`पेज ${i}/${n}`, `Page ${i}/${n}`), i / n)); b.done();
  let items = th.map((t, i) => ({ src: i, rot: 0, thumb: t })); const sel = new Set();
  const s = screen(L('पेज व्यवस्थित करें', 'Organize pages'), { action: L('नई PDF सेव करें', 'Save new PDF') });
  s.body.innerHTML = `<p class="hint">${L('पेज चुनने के लिए टैप करें। जगह बदलने के लिए दबाकर खींचें।', 'Tap to select. Press and drag to reorder.')}</p><div class="ogrid"></div>
    <div class="obar">
      <button data-o="all">${I.check}<span>${L('सब', 'All')}</span></button>
      <button data-o="left">${I.undo}<span>${L('बाएँ', 'Left')}</span></button>
      <button data-o="right">${I.rotate}<span>${L('दाएँ', 'Right')}</span></button>
      <button data-o="blank">${I.plusbox}<span>${L('ख़ाली पेज', 'Blank')}</span></button>
      <button data-o="extract">${I.split}<span>${L('अलग PDF', 'Extract')}</span></button>
      <button data-o="del" class="danger">${I.trash}<span>${L('हटाएँ', 'Delete')}</span></button></div>`;
  const grid = $('.ogrid', s);
  const render = () => { grid.innerHTML = items.map((it, i) => `<div class="otile ${sel.has(it) ? 'on' : ''}" data-i="${i}">
    <div class="oimg">${it.src < 0 ? '' : `<img src="${it.thumb}" alt="" style="transform:rotate(${it.rot}deg)">`}</div><span>${i + 1}</span><i class="tick"></i></div>`).join(''); };
  new Sortable(grid, { animation: 150, delay: 200, delayOnTouchOnly: true, onEnd: e => { const [m] = items.splice(e.oldIndex, 1); items.splice(e.newIndex, 0, m); render(); } });
  grid.addEventListener('click', e => { const t = e.target.closest('.otile'); if (!t) return; tap(); const it = items[+t.dataset.i]; sel.has(it) ? sel.delete(it) : sel.add(it); render(); });
  s.addEventListener('click', async e => {
    const o = e.target.closest('[data-o]')?.dataset.o; if (!o) return; tap();
    const chosen = items.filter(it => sel.has(it));
    if (o === 'all') { if (sel.size === items.length) sel.clear(); else items.forEach(it => sel.add(it)); render(); return; }
    if (o === 'blank') { const at = chosen.length ? items.indexOf(chosen[chosen.length - 1]) + 1 : items.length; items.splice(at, 0, { src: -1, rot: 0 }); render(); return; }
    if (!chosen.length) return toast(L('पहले पेज चुनें', 'Select pages first'));
    if (o === 'left' || o === 'right') { chosen.forEach(it => it.rot = (it.rot + (o === 'left' ? 270 : 90)) % 360); render(); }
    if (o === 'del') { if (chosen.length === items.length) return toast(L('सारे पेज नहीं हटा सकते', 'Cannot delete every page')); items = items.filter(it => !sel.has(it)); sel.clear(); render(); }
    if (o === 'extract') { const bz = busy(); const bytes = await build(chosen); const meta = await addToLibrary(bytes, baseName(file.name) + L(' (कुछ पेज)', ' (pages)')); bz.done(); resultSheet(meta); }
  });
  async function build(list) {
    const out = await PDFDocument.create(); const idx = list.filter(it => it.src >= 0).map(it => it.src);
    const copied = await out.copyPages(src, idx); let k = 0;
    const firstSize = src.getPage(0).getSize();
    for (const it of list) {
      if (it.src < 0) { out.addPage([firstSize.width, firstSize.height]); continue; }
      const p = copied[k++]; p.setRotation(degrees((p.getRotation().angle + it.rot) % 360)); out.addPage(p);
    }
    return out.save();
  }
  s.go.onclick = async () => { const bz = busy(); try { const bytes = await build(items); const meta = await addToLibrary(bytes, baseName(file.name) + L(' (नया)', ' (organized)')); bz.done(); s.close(); resultSheet(meta); } catch (e) { bz.done(); toast(String(e?.message || e)); } };
  render();
}

/* ---------- merge ---------- */
export async function merge(files) {
  if (files.length < 2) return toast(L('कम से कम 2 PDF चुनें', 'Choose at least 2 PDFs'));
  const s = screen(L('PDF जोड़ें', 'Merge PDFs'), { action: L('जोड़ें', 'Merge') });
  s.body.innerHTML = `<p class="hint">${L('क्रम बदलने के लिए दबाकर खींचें।', 'Press and drag to change order.')}</p><ul class="mlist">${files.map((f, i) =>
    `<li data-i="${i}">${I.doc}<span>${esc(baseName(f.name))}</span><small>${fmtSize(f.bytes.length)}</small><b class="grip">⋮⋮</b></li>`).join('')}</ul>`;
  const list = $('.mlist', s); new Sortable(list, { animation: 150, handle: 'li' });
  s.go.onclick = async () => {
    const order = $$('li', list).map(li => files[+li.dataset.i]); const b = busy(L('जोड़ रहे हैं…', 'Merging…'));
    try { const out = await PDFDocument.create();
      for (const [i, f] of order.entries()) { b.set(L(`फ़ाइल ${i + 1}/${order.length}`, `File ${i + 1}/${order.length}`), i / order.length);
        const d = await PDFDocument.load(f.bytes, { ignoreEncryption: true }); (await out.copyPages(d, d.getPageIndices())).forEach(p => out.addPage(p)); }
      const meta = await addToLibrary(await out.save(), L('जोड़ी गई PDF', 'Merged') + ' ' + new Date().toLocaleDateString('en-GB').replace(/\//g, '-'));
      b.done(); s.close(); resultSheet(meta);
    } catch (e) { b.done(); toast(L('जोड़ नहीं पाए। कोई PDF पासवर्ड वाली तो नहीं?', 'Could not merge. Is one PDF password protected?'), 5000); }
  };
}

/* ---------- split ---------- */
export async function split(file) {
  const src = await PDFDocument.load(file.bytes, { ignoreEncryption: true }); const n = src.getPageCount();
  if (n < 2) return toast(L('इसमें एक ही पेज है', 'Only one page'));
  const how = await choose(L(`${n} पेज की PDF को कैसे अलग करें?`, `Split ${n} pages how?`), [
    ['each', 'pages', L('हर पेज अलग PDF', 'Every page as its own PDF')],
    ['every', 'split', L('हर N पेज पर', 'Every N pages')],
    ['ranges', 'hash', L('अपने हिसाब से (जैसे 1-3, 4-6)', 'Custom ranges (e.g. 1-3, 4-6)')]]);
  if (!how) return;
  let groups = [];
  if (how === 'each') groups = [...Array(n).keys()].map(i => [i + 1]);
  if (how === 'every') { const k = +(await askVal(L('कितने पेज पर?', 'How many pages each?'), '2')); if (!k) return; for (let i = 1; i <= n; i += k) groups.push([...Array(Math.min(k, n - i + 1)).keys()].map(j => i + j)); }
  if (how === 'ranges') { const r = await askVal(L('पेज लिखें, कॉमा से अलग', 'Page ranges, comma separated'), `1-${Math.ceil(n / 2)}, ${Math.ceil(n / 2) + 1}-${n}`, false); if (!r) return;
    groups = r.split(',').map(part => parseRanges(part, n)).filter(g => g.length); }
  if (!groups.length) return toast(L('सही पेज नंबर डालें', 'Enter valid pages'));
  
  const b = busy(); let last;
  for (const [i, g] of groups.entries()) { b.set(L(`फ़ाइल ${i + 1}/${groups.length}`, `File ${i + 1}/${groups.length}`), i / groups.length);
    const out = await PDFDocument.create(); (await out.copyPages(src, g.map(x => x - 1))).forEach(p => out.addPage(p));
    last = await addToLibrary(await out.save(), `${baseName(file.name)} ${g.length > 1 ? g[0] + '-' + g[g.length - 1] : g[0]}`); }
  b.done(); toast(L(`${groups.length} फ़ाइलें बन गईं, "फ़ाइलें" में देखें`, `${groups.length} files made, see Files`), 4000); if (groups.length === 1) resultSheet(last); else window.dispatchEvent(new Event('panna:refresh'));
}
function askVal(title, value, num = true) { return new Promise(res => { const w = dialog(`<h3>${esc(title)}</h3><input id="v" ${num ? 'type="number" inputmode="numeric"' : ''} value="${esc(value)}">`, L('ठीक', 'OK'), d => { res($('#v', d).value.trim()); return true; }, d => $('#v', d).select()); w.oncancel = () => res(null); }); }

/* ---------- page numbers & watermark ---------- */
export async function pageNumbers(file) {
  const r = await new Promise(res => { const w = dialog(`<h3>${L('पेज नंबर लगाएँ', 'Add page numbers')}</h3>
    <label class="fl">${L('जगह', 'Position')}<select id="pp"><option value="bc">${L('नीचे बीच में', 'Bottom center')}</option><option value="br">${L('नीचे दाएँ', 'Bottom right')}</option><option value="tr">${L('ऊपर दाएँ', 'Top right')}</option></select></label>
    <label class="fl">${L('लिखावट', 'Format')}<select id="pf"><option value="n">1, 2, 3</option><option value="of">1 / 10</option><option value="pe">Page 1</option><option value="hi">पेज 1</option></select></label>
    <label class="fl">${L('शुरुआती नंबर', 'Start at')}<input id="ps" type="number" value="1" inputmode="numeric"></label>`, L('लगाएँ', 'Apply'),
    d => { res({ pos: $('#pp', d).value, fmt: $('#pf', d).value, start: +$('#ps', d).value || 1 }); return true; }); w.oncancel = () => res(null); });
  if (!r) return;
  await stampPages(file, L(' (पेज नंबर)', ' (numbered)'), (i, n, W, H) => {
    const k = r.start + i, txt = { n: `${k}`, of: `${k} / ${n + r.start - 1}`, pe: `Page ${k}`, hi: `पेज ${k}` }[r.fmt];
    const c = textCanvas(txt, { size: 40, color: '#222', weight: 500 }); const h = Math.min(W, H) * .027, w = h * c.width / c.height, m = Math.min(W, H) * .04;
    const x = r.pos === 'bc' ? (W - w) / 2 : W - m - w, y = r.pos === 'tr' ? m : H - m - h;
    return { c, x, y, w, h };
  });
}

export async function watermark(file) {
  const r = await new Promise(res => { const w = dialog(`<h3>${L('वॉटरमार्क', 'Watermark')}</h3>
    <input id="wt" placeholder="${L('जैसे: सिर्फ़ बैंक के लिए / COPY', 'e.g. FOR BANK USE ONLY / COPY')}">
    <label class="fl">${L('स्टाइल', 'Style')}<select id="ws"><option value="d">${L('तिरछा बीच में', 'Diagonal center')}</option><option value="t">${L('पूरे पेज पर बार-बार', 'Tiled')}</option></select></label>
    <label class="fl">${L('हल्कापन', 'Opacity')}<input id="wo" type="range" min="8" max="60" value="30"></label>
    <div class="swatches">${['#888888', '#C0221B', '#1446A0'].map((c, i) => `<button type="button" class="sw" data-c="${c}" style="--c:${c}" aria-pressed="${!i}"></button>`).join('')}</div>`,
    L('लगाएँ', 'Apply'), d => { const t = $('#wt', d).value.trim(); if (!t) return false; res({ text: t, style: $('#ws', d).value, op: +$('#wo', d).value / 100, color: $('.sw[aria-pressed=true]', d).dataset.c }); return true; }, d => $('#wt', d).focus());
    w.addEventListener('click', e => { const c = e.target.closest('.sw'); if (c) $$('.sw', w).forEach(b => b.setAttribute('aria-pressed', b === c)); }); w.oncancel = () => res(null); });
  if (!r) return;
  await stampPages(file, L(' (वॉटरमार्क)', ' (watermark)'), (i, n, W, H) => {
    const c = document.createElement('canvas'); const sc = 3; c.width = W * sc; c.height = H * sc; const x = c.getContext('2d'); x.globalAlpha = r.op;
    const tc = textCanvas(r.text, { size: 120, color: r.color, weight: 800 });
    const draw = (cx, cy, w) => { const h = w * tc.height / tc.width; x.save(); x.translate(cx, cy); x.rotate(-Math.atan2(H, W)); x.drawImage(tc, -w / 2, -h / 2, w, h); x.restore(); };
    if (r.style === 'd') draw(c.width / 2, c.height / 2, Math.hypot(c.width, c.height) * .7);
    else for (let yy = 0; yy < 4; yy++) for (let xx = 0; xx < 3; xx++) draw(c.width * (xx + .5 + (yy % 2) * .25) / 3, c.height * (yy + .5) / 4, c.width * .38);
    return { c, x: 0, y: 0, w: W, h: H };
  });
}

async function stampPages(file, suffix, make) {
  const b = busy();
  try {
    const doc = await PDFDocument.load(file.bytes, { ignoreEncryption: true }); const pages = doc.getPages(); const cache = new Map();
    for (const [i, p] of pages.entries()) {
      b.set(L(`पेज ${i + 1}/${pages.length}`, `Page ${i + 1}/${pages.length}`), i / pages.length);
      const rot = p.getRotation().angle % 360; const { width, height } = p.getSize(); const W = rot % 180 ? height : width, H = rot % 180 ? width : height;
      const m = make(i, pages.length, W, H);
      const full = document.createElement('canvas'); const sc = 2.5; full.width = W * sc; full.height = H * sc;
      full.getContext('2d').drawImage(m.c, m.x * sc, m.y * sc, m.w * sc, m.h * sc);
      const key = full.toDataURL(); let img = cache.get(key);
      if (!img) { img = await doc.embedPng(await canvasBytes(full, 'image/png')); cache.set(key, img); }
      placeOverlay(p, img, rot);
    }
    const meta = await addToLibrary(await doc.save(), baseName(file.name) + suffix); b.done(); resultSheet(meta);
  } catch (e) { b.done(); toast(String(e?.message || e), 4000); }
}

/* ---------- crop margins ---------- */
export async function cropMargins(file) {
  const r = await new Promise(res => { const w = dialog(`<h3>${L('किनारे काटें', 'Crop margins')}</h3><p class="muted">${L('सभी पेज के किनारे से कितना प्रतिशत काटना है', 'How much to trim from every page edge (%)')}</p>
    ${[['t', L('ऊपर', 'Top')], ['b', L('नीचे', 'Bottom')], ['l', L('बाएँ', 'Left')], ['r', L('दाएँ', 'Right')]].map(([k, l]) => `<label class="fl">${l} <output id="o${k}">5</output>%<input id="c${k}" type="range" min="0" max="30" value="5" oninput="this.previousElementSibling.value=this.value"></label>`).join('')}`,
    L('काटें', 'Crop'), d => { res({ t: +$('#ct', d).value, b: +$('#cb', d).value, l: +$('#cl', d).value, r: +$('#cr', d).value }); return true; }); w.oncancel = () => res(null); });
  if (!r) return;
  const doc = await PDFDocument.load(file.bytes, { ignoreEncryption: true });
  for (const p of doc.getPages()) { const bx = p.getCropBox(); const w = bx.width, h = bx.height;
    p.setCropBox(bx.x + w * r.l / 100, bx.y + h * r.b / 100, w * (1 - (r.l + r.r) / 100), h * (1 - (r.t + r.b) / 100)); }
  const meta = await addToLibrary(await doc.save(), baseName(file.name) + L(' (कटी)', ' (cropped)')); resultSheet(meta);
}

/* ---------- compress ---------- */
export async function compress(file) {
  const orig = file.bytes.length;
  const how = await choose(L(`अभी साइज़: ${fmtSize(orig)}`, `Current size: ${fmtSize(orig)}`), [
    ['m', 'compress', L('अच्छी क्वालिटी (थोड़ा छोटा)', 'Good quality (a bit smaller)')],
    ['h', 'compress', L('ज़्यादा छोटा (क्वालिटी ठीक-ठाक)', 'Much smaller (okay quality)')],
    ['t', 'hash', L('तय साइज़ से कम (जैसे 200 KB)', 'Under a target size (e.g. 200 KB)')]]);
  if (!how) return;
  let target = 0;
  if (how === 't') { const v = await askVal(L('ज़्यादा से ज़्यादा कितने KB?', 'Maximum size in KB?'), '200'); if (!v) return; target = +v * 1024; }
  const b = busy(L('छोटा कर रहे हैं…', 'Compressing…'));
  try {
    const doc = await loadPdf(file.bytes.slice(0)); const n = doc.numPages;
    const renderAll = async (dpi) => { const cs = []; for (let i = 1; i <= n; i++) { const pg = await doc.getPage(i); const v1 = pg.getViewport({ scale: 1 });
      const vp = pg.getViewport({ scale: dpi / 72 }); const c = document.createElement('canvas'); c.width = vp.width; c.height = vp.height; const x = c.getContext('2d', { alpha: false });
      x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); await pg.render({ canvasContext: x, viewport: vp }).promise; cs.push({ c, w: v1.width, h: v1.height });
      b.set(L(`पेज ${i}/${n}`, `Page ${i}/${n}`), i / n); } return cs; };
    const build = async (cs, q) => { const out = await PDFDocument.create(); for (const { c, w, h } of cs) { const img = await out.embedJpg(await canvasBytes(c, 'image/jpeg', q)); out.addPage([w, h]).drawImage(img, { x: 0, y: 0, width: w, height: h }); } return out.save({ useObjectStreams: true }); };
    let bytes;
    if (how === 'm') bytes = await build(await renderAll(150), .72);
    else if (how === 'h') bytes = await build(await renderAll(110), .5);
    else {
      for (const dpi of [150, 120, 96, 72, 60]) { const cs = await renderAll(dpi); let lo = .2, hi = .85, best = null;
        for (let k = 0; k < 6; k++) { const q = (lo + hi) / 2; b.set(L(`साइज़ जाँच रहे हैं (${dpi} dpi)…`, `Trying size (${dpi} dpi)…`)); const tb = await build(cs, q); if (tb.length <= target) { best = tb; lo = q; } else hi = q; }
        cs.forEach(x => x.c.width = 0); if (best) { bytes = best; break; } }
      if (!bytes) { doc.destroy(); b.done(); return toast(L('इतना छोटा नहीं हो पाया। साइज़ थोड़ा बढ़ाकर कोशिश करें।', 'Could not get that small. Try a larger size.'), 5000); }
    }
    doc.destroy();
    if (bytes.length >= orig) { b.done(); return toast(L('यह PDF पहले से ही छोटी है, और छोटी नहीं हुई', 'Already small, could not shrink further'), 4000); }
    const meta = await addToLibrary(bytes, baseName(file.name) + L(' (छोटी)', ' (small)')); b.done();
    resultSheet(meta, L(`${fmtSize(orig)} से ${fmtSize(bytes.length)} हो गई`, `${fmtSize(orig)} → ${fmtSize(bytes.length)}`));
  } catch (e) { b.done(); toast(String(e?.message || e), 4000); }
}
