import { openDB } from 'idb';
const dbp = openDB('panna', 2, { upgrade(db, old) {
  if (old < 1) { db.createObjectStore('meta', { keyPath: 'id' }); db.createObjectStore('blobs'); }
  if (old < 2) { db.createObjectStore('text'); db.createObjectStore('kv'); }
}});
export async function allMeta() { return (await dbp).getAll('meta'); }
export async function listFiles({ bin = false } = {}) {
  const all = await allMeta();
  return all.filter(f => !!f.deletedAt === bin).sort((a, b) => (bin ? b.deletedAt - a.deletedAt : b.opened - a.opened));
}
export async function getMeta(id) { return (await dbp).get('meta', id); }
export async function getBlob(id) { return (await dbp).get('blobs', id); }
export async function putFile(meta, blob) {
  const db = await dbp; const tx = db.transaction(['meta', 'blobs'], 'readwrite');
  tx.objectStore('meta').put(meta); if (blob) tx.objectStore('blobs').put(blob, meta.id);
  await tx.done;
}
export async function updateMeta(id, patch) {
  const db = await dbp; const m = await db.get('meta', id); if (!m) return;
  Object.assign(m, patch); await db.put('meta', m); return m;
}
export async function removeFile(id) {
  const db = await dbp; const tx = db.transaction(['meta', 'blobs', 'text'], 'readwrite');
  tx.objectStore('meta').delete(id); tx.objectStore('blobs').delete(id); tx.objectStore('text').delete(id); await tx.done;
}
export async function findDuplicate(name, size) {
  return (await listFiles()).find(f => f.name === name && f.size === size);
}
export async function setText(id, pages) { return (await dbp).put('text', pages, id); }
export async function getText(id) { return (await dbp).get('text', id); }
export async function kvGet(k) { return (await dbp).get('kv', k); }
export async function kvSet(k, v) { return (await dbp).put('kv', v, k); }
export async function purgeBin(days = 30) {
  const lim = Date.now() - days * 864e5;
  for (const f of await listFiles({ bin: true })) if (f.deletedAt < lim) await removeFile(f.id);
}
