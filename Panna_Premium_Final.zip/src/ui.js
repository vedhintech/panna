import { t } from './i18n.js';
import { I, GEM } from './icons.js';
import { Capacitor } from '@capacitor/core';
import { Haptics, ImpactStyle } from '@capacitor/haptics';

export const native = Capacitor.isNativePlatform();
export const $ = (s, r = document) => r.querySelector(s);
export const $$ = (s, r = document) => [...r.querySelectorAll(s)];
export const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export const tap = () => native && Haptics.impact({ style: ImpactStyle.Light }).catch(() => {});
export const sleep = ms => new Promise(r => setTimeout(r, ms));
export const h = (html) => { const d = document.createElement('div'); d.innerHTML = html.trim(); return d.firstElementChild; };

/* overlay stack for Android back button */
export const overlays = [];
export function pushOverlay(close) { overlays.push(close); }
export function popOverlay() { const c = overlays.pop(); c?.(); }
function dropOverlay(close) { const i = overlays.lastIndexOf(close); if (i >= 0) overlays.splice(i, 1); }

export function sheet(html, onPick) {
  const w = document.createElement('div'); w.className = 'scrim';
  w.innerHTML = `<div class="sheet" role="dialog"><i class="grab"></i>${html}</div>`;
  document.body.append(w); requestAnimationFrame(() => w.classList.add('in'));
  const pane = $('.sheet', w); pane.onpick = onPick;
  const close = () => { w.classList.remove('in'); setTimeout(() => w.remove(), 200); };
  pane.close = () => { dropOverlay(close); close(); };
  w.addEventListener('click', e => {
    if (e.target === w) { pane.close(); pane.oncancel?.(); return; }
    const it = e.target.closest('[data-s]'); if (!it) return; tap();
    if (!it.dataset.keep) pane.close();
    pane.onpick?.(it.dataset.s, it);
  });
  pushOverlay(() => { close(); pane.oncancel?.(); }); return pane;
}

export function choose(title, items) {
  return new Promise(res => {
    const p = sheet(`${title ? `<p class="shead">${esc(title)}</p>` : ''}${items.map(([v, ic, label, sub, cls]) =>
      `<button class="sitem ${cls || ''}" data-s="${v}">${I[ic] || ''}<span>${esc(label)}${sub ? `<small>${esc(sub)}</small>` : ''}</span></button>`).join('')}`, v => res(v));
    p.oncancel = () => res(null);
  });
}

export function dialog(html, okLabel, onOk, onShow, danger) {
  const w = document.createElement('div'); w.className = 'scrim center';
  w.innerHTML = `<form class="dialog" method="dialog" novalidate>${html}<div class="dact">
    <button type="button" class="btn ghost" data-d="cancel">${t('cancel')}</button>
    <button class="btn ${danger ? 'danger' : ''}">${okLabel}</button></div></form>`;
  document.body.append(w); requestAnimationFrame(() => w.classList.add('in'));
  const close = () => { w.classList.remove('in'); setTimeout(() => w.remove(), 180); };
  const done = () => { dropOverlay(close); close(); };
  w.addEventListener('click', e => { if (e.target === w || e.target.dataset.d === 'cancel') { done(); w.oncancel?.(); } });
  $('form', w).addEventListener('submit', async e => { e.preventDefault(); if (await onOk(w)) done(); });
  pushOverlay(() => { close(); w.oncancel?.(); }); setTimeout(() => onShow?.(w), 60);
  return w;
}

export function ask(title, { value = '', placeholder = '', type = 'text', note = '', ok = t('save') } = {}) {
  return new Promise(res => {
    const w = dialog(`<h3>${esc(title)}</h3>${note ? `<p class="muted">${esc(note)}</p>` : ''}
      <input id="askv" type="${type}" value="${esc(value)}" placeholder="${esc(placeholder)}" ${type === 'number' ? 'inputmode="numeric"' : ''}>`,
      ok, d => { res($('#askv', d).value); return true; }, d => { const i = $('#askv', d); i.focus(); if (type === 'text') i.select(); });
    w.oncancel = () => res(null);
  });
}

export function confirmBox(title, body, ok, danger) {
  return new Promise(res => {
    const w = dialog(`<h3>${esc(title)}</h3><p>${esc(body)}</p>`, ok, () => { res(true); return true; }, null, danger);
    w.oncancel = () => res(false);
  });
}

let toastT;
export function toast(msg, ms = 2600) {
  const el = $('#toast'); el.textContent = msg; el.classList.add('in');
  clearTimeout(toastT); toastT = setTimeout(() => el.classList.remove('in'), ms);
}

export function busy(msg) {
  let d = $('.loading');
  if (!d) { d = document.createElement('div'); d.className = 'loading'; d.innerHTML = `<div class="spin">${GEM}</div><span class="lmsg"></span><div class="lbar" hidden><i></i></div>`; document.body.append(d); }
  $('.lmsg', d).textContent = msg || t('working');
  return {
    set(m, frac) { $('.lmsg', d).textContent = m; const b = $('.lbar', d); if (frac == null) b.hidden = true; else { b.hidden = false; b.firstChild.style.width = Math.round(frac * 100) + '%'; } },
    done() { d.remove(); }
  };
}
export const idle = () => $('.loading')?.remove();

/* full-screen tool pages */
export function screen(title, { body = '', action, onClose, cls = '' } = {}) {
  const s = document.createElement('section'); s.className = 'tscreen ' + cls;
  s.innerHTML = `<header class="vbar"><button class="ibtn" data-x aria-label="Back">${I.back}</button><h1 class="vtitle">${esc(title)}</h1><div class="vbar-r"></div></header>
    <div class="tbody">${body}</div>${action ? `<footer class="tfoot"><button class="btn big" data-go>${esc(action)}</button></footer>` : ''}`;
  document.body.append(s); requestAnimationFrame(() => s.classList.add('in'));
  const close = () => { s.classList.remove('in'); setTimeout(() => s.remove(), 220); onClose?.(); };
  s.close = () => { dropOverlay(close); close(); };
  $('[data-x]', s).onclick = () => { tap(); s.close(); };
  pushOverlay(close);
  s.body = $('.tbody', s); s.go = $('[data-go]', s); s.right = $('.vbar-r', s);
  return s;
}

export const fmtSize = b => b > 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(b / 1024)) + ' KB';
export const baseName = n => String(n || 'document').replace(/\.[^.]+$/, '');
export function parseRanges(str, max) {
  const out = [];
  for (const part of String(str).split(',')) {
    const m = part.trim().match(/^(\d+)\s*(?:-\s*(\d+))?$/); if (!m) continue;
    let a = +m[1], b = m[2] ? +m[2] : a; if (a > b) [a, b] = [b, a];
    for (let i = Math.max(1, a); i <= Math.min(max, b); i++) out.push(i);
  }
  return out;
}
