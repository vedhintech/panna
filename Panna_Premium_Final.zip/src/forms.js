import fontkit from '@pdf-lib/fontkit';
import { PDFDocument, PDFTextField, PDFCheckBox, PDFDropdown, PDFRadioGroup, PDFOptionList } from 'pdf-lib';
import { L } from './i18n.js';
import { $, $$, esc, screen, toast, busy, baseName } from './ui.js';
import { addToLibrary } from './lib.js';
import { resultSheet } from './result.js';

export async function fillForm(file, fallback) {
  let doc; try { doc = await PDFDocument.load(file.bytes, { ignoreEncryption: true }); } catch { return toast(L('PDF नहीं खुली', 'PDF did not open')); }
  const form = doc.getForm(); const fields = form.getFields();
  if (!fields.length) { toast(L('इस PDF में भरने वाले खाने नहीं हैं। "टेक्स्ट लिखें" से कहीं भी लिख सकते हैं।', 'No fillable fields. Use "Add text" to write anywhere.'), 4500); return fallback?.(); }
  const s = screen(L('फ़ॉर्म भरें', 'Fill form'), { action: L('भरी हुई PDF सेव करें', 'Save filled PDF') });
  s.body.innerHTML = `<p class="hint">${L(`${fields.length} खाने मिले।`, `${fields.length} fields found.`)}</p>` + fields.map((f, i) => {
    const name = esc(f.getName().replace(/[._\[\]0-9]+/g, ' ').trim() || `Field ${i + 1}`);
    if (f instanceof PDFTextField) return `<label class="fl">${name}<input data-i="${i}" value="${esc(f.getText() || '')}"></label>`;
    if (f instanceof PDFCheckBox) return `<label class="tog"><input type="checkbox" data-i="${i}" ${f.isChecked() ? 'checked' : ''}><span>${name}</span></label>`;
    if (f instanceof PDFDropdown || f instanceof PDFOptionList) return `<label class="fl">${name}<select data-i="${i}"><option></option>${f.getOptions().map(o => `<option ${f.getSelected().includes(o) ? 'selected' : ''}>${esc(o)}</option>`).join('')}</select></label>`;
    if (f instanceof PDFRadioGroup) return `<label class="fl">${name}<select data-i="${i}"><option></option>${f.getOptions().map(o => `<option ${f.getSelected() === o ? 'selected' : ''}>${esc(o)}</option>`).join('')}</select></label>`;
    return '';
  }).join('') + `<label class="tog"><input type="checkbox" id="flat"><span>${L('भरने के बाद लॉक कर दें (कोई बदल न सके)', 'Lock after filling (no further edits)')}</span></label>`;
  s.go.onclick = async () => {
    const b = busy();
    try {
      $$('[data-i]', s).forEach(el => { const f = fields[+el.dataset.i];
        if (f instanceof PDFTextField) f.setText(el.value);
        else if (f instanceof PDFCheckBox) el.checked ? f.check() : f.uncheck();
        else if (el.value && (f instanceof PDFDropdown || f instanceof PDFOptionList || f instanceof PDFRadioGroup)) f.select(el.value); });
      // Devanagari can't be shaped inside PDF form fields: blank the field, flatten, then draw the text as an image
      const { textCanvas, canvasBytes } = await import('./lib.js');
      const pages = doc.getPages(); const draws = [];
      for (const el of $$('input[data-i]', s)) {
        const f = fields[+el.dataset.i]; if (!(f instanceof PDFTextField) || !/[\u0900-\u097F]/.test(el.value)) continue;
        for (const w of f.acroField.getWidgets()) {
          const ref = doc.context.getObjectRef(w.dict);
          draws.push({ r: w.getRectangle(), page: pages.find(p => p.node.Annots()?.asArray().some(a => a === ref)) || pages[0], text: el.value });
        }
        f.setText('');
      }
      const allText = $$('input[data-i]', s).filter(x => !/[\u0900-\u097F]/.test(x.value)).map(x => x.value).join('');
      if (/[^\x00-\xFF]/.test(allText)) { doc.registerFontkit(fontkit); const f = await doc.embedFont(new Uint8Array(await (await fetch('./fonts/Mukta-Regular.ttf')).arrayBuffer()), { subset: false }); form.updateFieldAppearances(f); }
      if ($('#flat', s).checked || draws.length) form.flatten();
      for (const d of draws) {
        const tc = textCanvas(d.text, { size: 64, color: '#111', weight: 500 }); const img = await doc.embedPng(await canvasBytes(tc, 'image/png'));
        const hh = Math.min(d.r.height * .78, 14); let ww = hh * tc.width / tc.height; if (ww > d.r.width - 4) ww = d.r.width - 4;
        const h2 = ww * tc.height / tc.width; d.page.drawImage(img, { x: d.r.x + 3, y: d.r.y + (d.r.height - h2) / 2, width: ww, height: h2 });
      }
      if (draws.length && !$('#flat', s).checked) toast(L('हिंदी सही दिखाने के लिए फ़ॉर्म लॉक कर दिया गया है', 'Form was locked so Hindi displays correctly'), 4000);
      const meta = await addToLibrary(await doc.save(), baseName(file.name) + L(' (भरा)', ' (filled)')); b.done(); s.close(); resultSheet(meta);
    } catch (e) { b.done(); toast(String(e?.message || e), 5000); }
  };
}
