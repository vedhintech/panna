export default { base: './', build: { target: 'es2020', chunkSizeWarningLimit: 3000 } };
